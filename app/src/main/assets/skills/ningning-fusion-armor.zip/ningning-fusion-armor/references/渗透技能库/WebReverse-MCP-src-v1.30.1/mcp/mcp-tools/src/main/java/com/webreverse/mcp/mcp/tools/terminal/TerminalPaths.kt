package com.webreverse.mcp.mcp.tools.terminal

import android.content.Context
import java.io.File

/**
 * 终端相关路径管理。
 *
 * 所有工具均安装在应用私有目录下，无需申请存储权限：
 * - host_tools/prefix/  — Host Tools 安装前缀（镜像 Termux 的 usr/ 目录）
 * - host_tools/download/ — 下载临时目录
 * - home/              — 终端 HOME 目录（shell 默认工作目录）
 * - tmp/               — 临时目录（TMPDIR）
 */
object TerminalPaths {

    @Volatile
    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
        ensureDirectories()
    }

    private fun ctx(): Context =
        appContext ?: throw IllegalStateException("TerminalPaths 未初始化，请先调用 init(context)")

    /** Host Tools 安装根目录 */
    val hostToolsRootDir: File
        get() = File(ctx().filesDir, "host_tools")

    /** Host Tools prefix 目录（镜像 Termux 的 /data/data/com.termux/files/usr/） */
    val hostToolsPrefixDir: File
        get() = File(hostToolsRootDir, "prefix")

    /** Host Tools 下载临时文件目录 */
    val hostToolsDownloadDir: File
        get() = File(ctx().cacheDir, "host_tools_download")

    /** 终端 HOME 目录 */
    val homeDir: File
        get() = File(ctx().filesDir, "home")

    /** 临时目录 */
    val tmpDir: File
        get() = File(ctx().cacheDir, "tmp")

    /** 脚本目录（AI 生成的脚本默认存放处） */
    val scriptsDir: File
        get() = File(ctx().filesDir, "scripts")

    /** 日志目录 */
    val logDir: File
        get() = File(ctx().filesDir, "logs")

    fun ensureDirectories() {
        listOf(
            hostToolsRootDir, hostToolsPrefixDir, hostToolsDownloadDir,
            homeDir, tmpDir, scriptsDir, logDir,
        ).forEach {
            if (!it.exists() && !it.mkdirs()) {
                android.util.Log.w("TerminalPaths", "Failed to create directory: ${it.absolutePath}")
            }
        }
    }

    /** 计算文件或目录的可读大小描述 */
    fun formatSize(bytes: Long): String {
        val units = arrayOf("B", "KB", "MB", "GB")
        var size = bytes.toDouble()
        var unitIndex = 0
        while (size >= 1024 && unitIndex < units.lastIndex) {
            size /= 1024
            unitIndex++
        }
        return String.format("%.1f %s", size, units[unitIndex])
    }

    /** 递归删除目录 */
    fun deleteRecursively(file: File): Boolean = file.deleteRecursively()
}
