package com.webreverse.mcp.mcp.tools

import com.webreverse.mcp.core.mcp.McpTool
import com.webreverse.mcp.core.mcp.ToolRegistry

/**
 * MCP Tool 模块化注册入口。
 * 通过 registerAll 批量注册所有分类工具，避免手工把 100+ 工具写进一个文件。
 */
object ToolModule {

    /** 注册所有工具到注册表 */
    fun registerAll(deps: ToolDependencies, registry: ToolRegistry = deps.toolRegistry): ToolRegistry {
        // CDP WS 帧转发 EventBus（v1.13.1）：event.wait network.websocket 即时捕获
        com.webreverse.mcp.devtools.network.CdpNetworkMonitor.wsFrameSink =
            { tabId, url, direction, payload ->
                deps.eventBus.tryEmit(
                    com.webreverse.mcp.core.common.event.NetworkEvent.WebSocketFrame(tabId, url, direction, payload),
                )
            }
        registry.registerAll(BrowserTools.all(deps))
        registry.registerAll(TabTools.all(deps))
        registry.registerAll(DomTools.all(deps))
        registry.registerAll(JavaScriptTools.all(deps))
        registry.registerAll(DebuggerTools.all(deps))
        registry.registerAll(NetworkTools.all(deps))
        registry.registerAll(StorageTools.all(deps))
        registry.registerAll(HookTools.all(deps))
        registry.registerAll(PageTools.all(deps))
        registry.registerAll(ReverseEngineeringTools.all(deps))
        registry.registerAll(WasmTools.all(deps))
        // v1.7.0 新增：JSVMP 深度分析 / 静态画像 / 动态追踪
        registry.registerAll(VmpTools.all(deps))
        registry.registerAll(StaticTools.all(deps))
        registry.registerAll(DynamicTools.all(deps))
        registry.registerAll(FrameTools.all(deps))
        registry.registerAll(WorkerTools.all(deps))
        registry.registerAll(PerformanceTools.all(deps))
        registry.registerAll(EventTools.all(deps))
        registry.registerAll(WorkspaceTools.all(deps))
        // v1.14.0 核心：证据库 / 逆向图谱 / 分析流水线（把工具产出收敛为知识图谱）
        registry.registerAll(EvidenceTools.all(deps))
        // v1.17.0：逆向调查引擎（Investigation-first：investigation.start/next/status ...）
        registry.registerAll(InvestigationTools.all(deps))
        // v1.17.0：逆向能力发现 + 复合工具（reverse.capabilities/tools/toolbox + network.inspect）
        registry.registerAll(ReverseDiscoveryTools.all(deps))
        registry.registerAll(FileTools.all(deps))
        registry.registerAll(McpTools.all(deps))
        registry.registerAll(SystemTools.all(deps))
        // v1.19.0：内置终端 + Host Tools 管理（terminal.exec / run_python / install ...）
        registry.registerAll(com.webreverse.mcp.mcp.tools.terminal.TerminalTools.all(deps))
        // v1.20.0：用户脚本管理（user_script.create / list / get / update / delete / set_enabled）
        registry.registerAll(UserScriptTools.all(deps))
        return registry
    }

    /** 按分类列出工具 */
    fun listByCategory(registry: ToolRegistry): Map<String, List<String>> =
        registry.listMetadata().groupBy({ it.category.name }, { it.name })

    /** 统计各分类数量 */
    fun countByCategory(registry: ToolRegistry): Map<String, Int> =
        registry.listMetadata().groupingBy { it.category.name }.eachCount()
}
