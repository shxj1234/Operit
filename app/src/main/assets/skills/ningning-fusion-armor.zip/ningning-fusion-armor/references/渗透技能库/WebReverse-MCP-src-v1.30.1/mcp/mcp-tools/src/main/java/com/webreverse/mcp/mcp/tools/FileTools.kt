package com.webreverse.mcp.mcp.tools

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Base64
import com.webreverse.mcp.core.common.permission.PermissionScope
import com.webreverse.mcp.core.common.permission.RiskLevel
import com.webreverse.mcp.core.common.util.WorkDir
import com.webreverse.mcp.core.mcp.McpTool
import com.webreverse.mcp.core.mcp.McpToolResult
import com.webreverse.mcp.core.mcp.ToolCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * File Tools：本地文件系统操作。
 *
 * 设计目标（源自真实逆向工作流痛点）：
 * - AI 下载 JS/HAR 后无法离线阅读 → file.read / file.search
 * - AI 无法把逆向成果落盘为脚本 → file.write / file.append
 * - 无法把文件交给用户 → file.open / file.share
 *
 * 路径规则：绝对路径直接使用；相对路径相对于工作目录（WorkDir）。
 * 安全规则：拒绝访问 /proc /sys /dev /system 等系统保护目录。
 */
object FileTools {

    /** 单文件读取硬上限（防止把超大文件灌进上下文） */
    private const val HARD_READ_LIMIT_BYTES = 32L * 1024 * 1024
    private val BLOCKED_PREFIXES = listOf(
        "/proc", "/sys", "/dev", "/system", "/vendor", "/apex", "/system_ext", "/odm", "/sbin", "/root",
    )

    fun all(deps: ToolDependencies): List<McpTool> {
        val f = ToolFactory(deps)
        return listOf(
            // ---------- 工作目录 ----------
            f.tool(
                "file.workdir", "获取当前工作目录（下载与分析产物的默认存放位置）", ToolCategory.FILE,
                PermissionScope.READ_FILE, RiskLevel.LOW,
            ) { _ ->
                val ctx = contextOf(deps)
                McpToolResult.json(
                    buildJsonObject {
                        put("path", JsonPrimitive(WorkDir.get()))
                        put("writable", JsonPrimitive(WorkDir.isWritable()))
                        put("fallbackPath", JsonPrimitive(WorkDir.directory(ctx).absolutePath))
                        put("hint", JsonPrimitive("未授予所有文件权限时，实际可写位置为 fallbackPath"))
                    },
                )
            },
            f.tool(
                "file.set_workdir", "设置工作目录（需已授予所有文件权限）", ToolCategory.FILE,
                PermissionScope.WRITE_FILE, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "path" to Schemas.strSchema("新的工作目录绝对路径"),
                ),
            ) { args ->
                val path = ToolArgs.str(args, "path")
                if (path.isBlank()) return@tool McpToolResult.error("INVALID_ARGUMENTS", "path 不能为空")
                val ok = WorkDir.set(contextOf(deps), path)
                if (ok) McpToolResult.json(
                    buildJsonObject {
                        put("success", JsonPrimitive(true))
                        put("path", JsonPrimitive(WorkDir.get()))
                    },
                ) else McpToolResult.error("SET_WORKDIR_FAILED", "目录不可写或创建失败: $path")
            },

            // ---------- 读 ----------
            f.tool(
                "file.read", "读取文件内容：文本按行返回（支持行号分页），二进制返回 base64。逆向分析下载的 JS/HAR 等文件用这个工具离线阅读", ToolCategory.FILE,
                PermissionScope.READ_FILE, RiskLevel.LOW, timeoutMs = 60_000,
                inputSchema = Schemas.objectSchema(
                    "path" to Schemas.strSchema("文件路径（相对工作目录或绝对路径）"),
                    "offset" to Schemas.intSchema("起始行号（0 基，默认 0）"),
                    "limit" to Schemas.intSchema("读取行数（默认 200）"),
                    "maxBytes" to Schemas.intSchema("单次返回的最大字节数（默认 524288，最大 33554432）"),
                    "base64" to Schemas.boolSchema("返回原始字节的 base64（二进制文件使用）"),
                ),
            ) { args ->
                val file = resolveFile(deps, ToolArgs.str(args, "path"))
                guard(file)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                if (!file.exists()) return@tool McpToolResult.error("FILE_NOT_FOUND", "文件不存在: ${file.absolutePath}")
                if (file.isDirectory) return@tool McpToolResult.error("IS_DIRECTORY", "目标是目录，请用 file.list: ${file.absolutePath}")
                val maxBytes = ToolArgs.long(args, "maxBytes", 524_288L).coerceIn(1024L, HARD_READ_LIMIT_BYTES)
                val wantBase64 = ToolArgs.bool(args, "base64")
                withContext(Dispatchers.IO) {
                    if (file.length() > HARD_READ_LIMIT_BYTES) {
                        return@withContext McpToolResult.error(
                            "FILE_TOO_LARGE",
                            "文件 ${(file.length() / 1024 / 1024)}MB 超过 32MB 上限，请用 file.search 定位内容",
                        )
                    }
                    if (wantBase64) {
                        val bytes = file.readBytes()
                        return@withContext McpToolResult.json(
                            buildJsonObject {
                                put("path", JsonPrimitive(file.absolutePath))
                                put("sizeBytes", JsonPrimitive(file.length()))
                                put(
                                    "base64",
                                    JsonPrimitive(Base64.encodeToString(bytes, Base64.NO_WRAP)),
                                )
                                put("truncated", JsonPrimitive(bytes.size.toLong() > maxBytes))
                            },
                        )
                    }
                    // 文本模式：按行分页
                    val text = file.readText(Charsets.UTF_8)
                    if (text.contains('\u0000')) {
                        return@withContext McpToolResult.error(
                            "BINARY_FILE",
                            "文件疑似二进制，请改用 base64=true 模式: ${file.absolutePath}",
                        )
                    }
                    val allLines = text.split("\n")
                    val offset = ToolArgs.int(args, "offset", 0).coerceAtLeast(0)
                    val limit = ToolArgs.int(args, "limit", 200).coerceIn(1, 10_000)
                    val sliced = allLines.drop(offset).take(limit)
                    var truncated = offset + limit < allLines.size
                    var used = 0L
                    val lineArray = sliced.mapIndexed { i, line ->
                        var display = line
                        if (display.length > 4000) {
                            display = display.take(4000) + "…[本行超长已截断，用 file.search 定位]"
                        }
                        used += display.length
                        buildJsonObject {
                            put("line", JsonPrimitive(offset + i))
                            put("text", JsonPrimitive(display))
                        }
                    }
                    if (used > maxBytes) truncated = true
                    McpToolResult.json(
                        buildJsonObject {
                            put("path", JsonPrimitive(file.absolutePath))
                            put("sizeBytes", JsonPrimitive(file.length()))
                            put("totalLines", JsonPrimitive(allLines.size))
                            put("offset", JsonPrimitive(offset))
                            put("returned", JsonPrimitive(lineArray.size))
                            put("truncated", JsonPrimitive(truncated))
                            put("lines", JsonArray(lineArray))
                        },
                    )
                }
            },

            // ---------- 写 ----------
            f.tool(
                "file.write", "创建或覆盖写入文件（把逆向成果、Python/JS 脚本落盘用这个工具）。支持文本与 base64 二进制，自动创建父目录", ToolCategory.FILE,
                PermissionScope.WRITE_FILE, RiskLevel.MEDIUM, timeoutMs = 60_000,
                inputSchema = Schemas.objectSchema(
                    "path" to Schemas.strSchema("目标文件路径（相对工作目录或绝对路径）"),
                    "content" to Schemas.strSchema("文本内容（与 contentBase64 二选一）"),
                    "contentBase64" to Schemas.strSchema("base64 内容（二进制文件使用，与 content 二选一）"),
                    "overwrite" to Schemas.boolSchema("文件已存在时是否覆盖（默认 true）"),
                ),
            ) { args ->
                val file = resolveFile(deps, ToolArgs.str(args, "path"))
                guard(file)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                val content = ToolArgs.optStr(args, "content")
                val contentB64 = ToolArgs.optStr(args, "contentBase64")
                if (content == null && contentB64 == null) {
                    return@tool McpToolResult.error("INVALID_ARGUMENTS", "必须提供 content 或 contentBase64")
                }
                val overwrite = ToolArgs.bool(args, "overwrite", true)
                if (file.exists() && !overwrite) {
                    return@tool McpToolResult.error("FILE_EXISTS", "文件已存在且 overwrite=false: ${file.absolutePath}")
                }
                withContext(Dispatchers.IO) {
                    file.parentFile?.mkdirs()
                    val bytes = contentB64?.let {
                        runCatching { Base64.decode(it, Base64.NO_WRAP) }.getOrNull()
                            ?: return@withContext McpToolResult.error("INVALID_BASE64", "contentBase64 解码失败")
                    } ?: content!!.toByteArray(Charsets.UTF_8)
                    file.writeBytes(bytes)
                    McpToolResult.json(
                        buildJsonObject {
                            put("path", JsonPrimitive(file.absolutePath))
                            put("sizeBytes", JsonPrimitive(file.length()))
                            put("bytesWritten", JsonPrimitive(bytes.size))
                        },
                    )
                }
            },
            f.tool(
                "file.append", "向文件末尾追加内容（不存在则创建）。适合分批写出长脚本", ToolCategory.FILE,
                PermissionScope.WRITE_FILE, RiskLevel.MEDIUM, timeoutMs = 60_000,
                inputSchema = Schemas.objectSchema(
                    "path" to Schemas.strSchema("目标文件路径"),
                    "content" to Schemas.strSchema("追加的文本内容（与 contentBase64 二选一）"),
                    "contentBase64" to Schemas.strSchema("追加的 base64 内容（与 content 二选一）"),
                    "newline" to Schemas.boolSchema("追加后是否补换行符（默认 true）"),
                ),
            ) { args ->
                val file = resolveFile(deps, ToolArgs.str(args, "path"))
                guard(file)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                val content = ToolArgs.optStr(args, "content")
                val contentB64 = ToolArgs.optStr(args, "contentBase64")
                if (content == null && contentB64 == null) {
                    return@tool McpToolResult.error("INVALID_ARGUMENTS", "必须提供 content 或 contentBase64")
                }
                withContext(Dispatchers.IO) {
                    file.parentFile?.mkdirs()
                    val body = contentB64?.let {
                        runCatching { Base64.decode(it, Base64.NO_WRAP) }.getOrNull()
                            ?: return@withContext McpToolResult.error("INVALID_BASE64", "contentBase64 解码失败")
                    } ?: content!!.toByteArray(Charsets.UTF_8)
                    val extra = if (ToolArgs.bool(args, "newline", true) && content != null) "\n".toByteArray() else ByteArray(0)
                    java.io.FileOutputStream(file, true).use { it.write(body); it.write(extra) }
                    McpToolResult.json(
                        buildJsonObject {
                            put("path", JsonPrimitive(file.absolutePath))
                            put("sizeBytes", JsonPrimitive(file.length()))
                            put("bytesAppended", JsonPrimitive(body.size + extra.size))
                        },
                    )
                }
            },

            // ---------- 目录浏览 ----------
            f.tool(
                "file.list", "列出目录内容（文件名/大小/修改时间），支持通配符过滤与递归", ToolCategory.FILE,
                PermissionScope.READ_FILE, RiskLevel.LOW, timeoutMs = 60_000,
                inputSchema = Schemas.objectSchema(
                    "path" to Schemas.strSchema("目录路径（默认工作目录）"),
                    "pattern" to Schemas.strSchema("通配符过滤，如 *.js（默认全部）"),
                    "recursive" to Schemas.boolSchema("是否递归子目录（默认 false）"),
                    "limit" to Schemas.intSchema("最多返回条目数（默认 200）"),
                ),
            ) { args ->
                val dir = resolveFile(deps, ToolArgs.str(args, "path"))
                guard(dir)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                if (!dir.exists()) return@tool McpToolResult.error("DIR_NOT_FOUND", "目录不存在: ${dir.absolutePath}")
                if (!dir.isDirectory) return@tool McpToolResult.error("NOT_DIRECTORY", "目标是文件: ${dir.absolutePath}")
                val pattern = ToolArgs.optStr(args, "pattern")?.takeIf { it.isNotBlank() }
                val recursive = ToolArgs.bool(args, "recursive")
                val limit = ToolArgs.int(args, "limit", 200).coerceIn(1, 5000)
                withContext(Dispatchers.IO) {
                    val files = if (recursive) dir.walkTopDown().filter { it != dir }.toList()
                    else dir.listFiles()?.toList() ?: emptyList()
                    val filtered = pattern?.let { p -> files.filter { globMatches(it.name, p) } } ?: files
                    val sorted = filtered.sortedWith(compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() })
                    val entries = sorted.take(limit).map { file ->
                        buildJsonObject {
                            put("name", JsonPrimitive(file.name))
                            put("path", JsonPrimitive(file.absolutePath))
                            put("isDirectory", JsonPrimitive(file.isDirectory))
                            put("sizeBytes", JsonPrimitive(if (file.isFile) file.length() else -1))
                            put("lastModified", JsonPrimitive(formatTime(file.lastModified())))
                        }
                    }
                    McpToolResult.json(
                        buildJsonObject {
                            put("directory", JsonPrimitive(dir.absolutePath))
                            put("count", JsonPrimitive(entries.size))
                            put("totalMatched", JsonPrimitive(filtered.size))
                            put("truncated", JsonPrimitive(filtered.size > entries.size))
                            put("entries", JsonArray(entries))
                        },
                    )
                }
            },
            f.tool(
                "file.tree", "以树形结构展示目录（限制深度与条目数）", ToolCategory.FILE,
                PermissionScope.READ_FILE, RiskLevel.LOW, timeoutMs = 60_000,
                inputSchema = Schemas.objectSchema(
                    "path" to Schemas.strSchema("目录路径（默认工作目录）"),
                    "depth" to Schemas.intSchema("最大深度（默认 3）"),
                    "maxEntries" to Schemas.intSchema("最多条目数（默认 200）"),
                ),
            ) { args ->
                val dir = resolveFile(deps, ToolArgs.str(args, "path"))
                guard(dir)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                if (!dir.exists() || !dir.isDirectory) {
                    return@tool McpToolResult.error("DIR_NOT_FOUND", "目录不存在: ${dir.absolutePath}")
                }
                val maxDepth = ToolArgs.int(args, "depth", 3).coerceIn(1, 10)
                val maxEntries = ToolArgs.int(args, "maxEntries", 200).coerceIn(1, 2000)
                withContext(Dispatchers.IO) {
                    val counter = intArrayOf(0)
                    val tree = buildTree(dir, 0, maxDepth, maxEntries, counter)
                    McpToolResult.json(
                        buildJsonObject {
                            put("root", JsonPrimitive(dir.absolutePath))
                            put("entries", JsonPrimitive(counter[0]))
                            put("truncated", JsonPrimitive(counter[0] >= maxEntries))
                            put("tree", tree)
                        },
                    )
                }
            },

            // ---------- 元信息 ----------
            f.tool(
                "file.stat", "获取文件/目录元信息（大小、修改时间、可读写性、MIME 类型）", ToolCategory.FILE,
                PermissionScope.READ_FILE, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema("path" to Schemas.strSchema("文件或目录路径")),
            ) { args ->
                val file = resolveFile(deps, ToolArgs.str(args, "path"))
                guard(file)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                McpToolResult.json(
                    buildJsonObject {
                        put("exists", JsonPrimitive(file.exists()))
                        if (file.exists()) {
                            put("path", JsonPrimitive(file.absolutePath))
                            put("name", JsonPrimitive(file.name))
                            put("parent", JsonPrimitive(file.parent ?: ""))
                            put("isDirectory", JsonPrimitive(file.isDirectory))
                            put("isFile", JsonPrimitive(file.isFile))
                            put("sizeBytes", JsonPrimitive(file.length()))
                            put("lastModified", JsonPrimitive(formatTime(file.lastModified())))
                            put("canRead", JsonPrimitive(file.canRead()))
                            put("canWrite", JsonPrimitive(file.canWrite()))
                            put("extension", JsonPrimitive(file.extension))
                            put("mimeType", JsonPrimitive(mimeOf(file.name)))
                        }
                    },
                )
            },
            f.tool(
                "file.exists", "检查文件或目录是否存在", ToolCategory.FILE,
                PermissionScope.READ_FILE, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema("path" to Schemas.strSchema("文件或目录路径")),
            ) { args ->
                val file = resolveFile(deps, ToolArgs.str(args, "path"))
                McpToolResult.json(
                    buildJsonObject {
                        put("path", JsonPrimitive(file.absolutePath))
                        put("exists", JsonPrimitive(file.exists()))
                        put("isDirectory", JsonPrimitive(file.isDirectory))
                        put("isFile", JsonPrimitive(file.isFile))
                    },
                )
            },

            // ---------- 目录操作 ----------
            f.tool(
                "file.mkdir", "创建目录（支持多级）", ToolCategory.FILE,
                PermissionScope.WRITE_FILE, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema("path" to Schemas.strSchema("目录路径")),
            ) { args ->
                val dir = resolveFile(deps, ToolArgs.str(args, "path"))
                guard(dir)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                withContext(Dispatchers.IO) {
                    if (dir.exists()) {
                        McpToolResult.json(
                            buildJsonObject {
                                put("created", JsonPrimitive(false))
                                put("path", JsonPrimitive(dir.absolutePath))
                                put("reason", JsonPrimitive("目录已存在"))
                            },
                        )
                    } else {
                        val ok = dir.mkdirs()
                        if (ok) McpToolResult.json(
                            buildJsonObject {
                                put("created", JsonPrimitive(true))
                                put("path", JsonPrimitive(dir.absolutePath))
                            },
                        ) else McpToolResult.error("MKDIR_FAILED", "创建失败（权限不足？）: ${dir.absolutePath}")
                    }
                }
            },
            f.tool(
                "file.delete", "删除文件或目录（目录需 recursive=true 才能删除非空内容）", ToolCategory.FILE,
                PermissionScope.WRITE_FILE, RiskLevel.HIGH, timeoutMs = 60_000,
                inputSchema = Schemas.objectSchema(
                    "path" to Schemas.strSchema("目标路径"),
                    "recursive" to Schemas.boolSchema("目录递归删除（默认 false，非空目录会拒绝）"),
                ),
            ) { args ->
                val file = resolveFile(deps, ToolArgs.str(args, "path"))
                guard(file)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                if (!file.exists()) return@tool McpToolResult.error("FILE_NOT_FOUND", "路径不存在: ${file.absolutePath}")
                val recursive = ToolArgs.bool(args, "recursive")
                withContext(Dispatchers.IO) {
                    if (file.isDirectory && !recursive && file.listFiles()?.isNotEmpty() == true) {
                        return@withContext McpToolResult.error(
                            "DIR_NOT_EMPTY",
                            "目录非空，需 recursive=true: ${file.absolutePath}",
                        )
                    }
                    val ok = if (recursive) file.deleteRecursively() else file.delete()
                    if (ok) McpToolResult.json(
                        buildJsonObject {
                            put("deleted", JsonPrimitive(true))
                            put("path", JsonPrimitive(file.absolutePath))
                        },
                    ) else McpToolResult.error("DELETE_FAILED", "删除失败（权限不足？）: ${file.absolutePath}")
                }
            },

            // ---------- 复制/移动 ----------
            f.tool(
                "file.copy", "复制文件或目录（目录递归复制）", ToolCategory.FILE,
                PermissionScope.WRITE_FILE, RiskLevel.MEDIUM, timeoutMs = 120_000,
                inputSchema = Schemas.objectSchema(
                    "source" to Schemas.strSchema("源路径"),
                    "destination" to Schemas.strSchema("目标路径（目录则复制到其内）"),
                    "overwrite" to Schemas.boolSchema("目标存在时是否覆盖（默认 true）"),
                ),
            ) { args ->
                val src = resolveFile(deps, ToolArgs.str(args, "source"))
                guard(src)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                if (!src.exists()) return@tool McpToolResult.error("FILE_NOT_FOUND", "源不存在: ${src.absolutePath}")
                val dst = resolveFile(deps, ToolArgs.str(args, "destination"))
                guard(dst)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                val overwrite = ToolArgs.bool(args, "overwrite", true)
                withContext(Dispatchers.IO) {
                    val target = if (dst.isDirectory) File(dst, src.name) else dst
                    if (target.exists() && !overwrite) {
                        return@withContext McpToolResult.error("FILE_EXISTS", "目标已存在: ${target.absolutePath}")
                    }
                    val count = copyRecursive(src, target)
                    McpToolResult.json(
                        buildJsonObject {
                            put("copied", JsonPrimitive(true))
                            put("from", JsonPrimitive(src.absolutePath))
                            put("to", JsonPrimitive(target.absolutePath))
                            put("entries", JsonPrimitive(count))
                            put("sizeBytes", JsonPrimitive(target.length()))
                        },
                    )
                }
            },
            f.tool(
                "file.move", "移动或重命名文件/目录", ToolCategory.FILE,
                PermissionScope.WRITE_FILE, RiskLevel.MEDIUM, timeoutMs = 120_000,
                inputSchema = Schemas.objectSchema(
                    "source" to Schemas.strSchema("源路径"),
                    "destination" to Schemas.strSchema("目标路径（目录则移动到其内）"),
                ),
            ) { args ->
                val src = resolveFile(deps, ToolArgs.str(args, "source"))
                guard(src)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                if (!src.exists()) return@tool McpToolResult.error("FILE_NOT_FOUND", "源不存在: ${src.absolutePath}")
                val dst = resolveFile(deps, ToolArgs.str(args, "destination"))
                guard(dst)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                withContext(Dispatchers.IO) {
                    val target = if (dst.isDirectory) File(dst, src.name) else dst
                    target.parentFile?.mkdirs()
                    val ok = if (src.renameTo(target)) true else {
                        // 跨分区：复制后删源
                        copyRecursive(src, target) > 0 && src.deleteRecursively()
                    }
                    if (ok) McpToolResult.json(
                        buildJsonObject {
                            put("moved", JsonPrimitive(true))
                            put("from", JsonPrimitive(src.absolutePath))
                            put("to", JsonPrimitive(target.absolutePath))
                        },
                    ) else McpToolResult.error("MOVE_FAILED", "移动失败（目标存在或权限不足）")
                }
            },

            // ---------- 内容搜索（逆向核心） ----------
            f.tool(
                "file.search", "在文件或目录中搜索文本/正则（本地 grep）。逆向下载的 JS 大文件时用它定位 sign/md5/encrypt 等关键代码，压缩单行大文件会自动截取匹配点上下文窗口", ToolCategory.FILE,
                PermissionScope.READ_FILE, RiskLevel.LOW, timeoutMs = 120_000,
                inputSchema = Schemas.objectSchema(
                    "path" to Schemas.strSchema("文件或目录路径（目录默认递归）"),
                    "query" to Schemas.strSchema("搜索关键词或正则表达式"),
                    "isRegex" to Schemas.boolSchema("query 是否为正则表达式（默认 false）"),
                    "ignoreCase" to Schemas.boolSchema("忽略大小写（默认 false）"),
                    "filePattern" to Schemas.strSchema("文件名通配符，如 *.js（默认全部文本文件）"),
                    "recursive" to Schemas.boolSchema("目录递归（默认 true）"),
                    "maxResults" to Schemas.intSchema("最多返回匹配数（默认 50）"),
                    "contextChars" to Schemas.intSchema("超长行时匹配点前后展示的字符窗口（默认 120）"),
                ),
            ) { args ->
                val root = resolveFile(deps, ToolArgs.str(args, "path"))
                guard(root)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                if (!root.exists()) return@tool McpToolResult.error("FILE_NOT_FOUND", "路径不存在: ${root.absolutePath}")
                val query = ToolArgs.str(args, "query")
                if (query.isBlank()) return@tool McpToolResult.error("INVALID_ARGUMENTS", "query 不能为空")
                val isRegex = ToolArgs.bool(args, "isRegex")
                val ignoreCase = ToolArgs.bool(args, "ignoreCase")
                val filePattern = ToolArgs.optStr(args, "filePattern")?.takeIf { it.isNotBlank() }
                val recursive = ToolArgs.bool(args, "recursive", true)
                val maxResults = ToolArgs.int(args, "maxResults", 50).coerceIn(1, 500)
                val contextChars = ToolArgs.int(args, "contextChars", 120).coerceIn(20, 2000)
                val regex: Regex? = try {
                    if (isRegex) {
                        val opts: Set<RegexOption> = if (ignoreCase) setOf(RegexOption.IGNORE_CASE) else emptySet()
                        query.toRegex(opts)
                    } else {
                        null
                    }
                } catch (e: Exception) {
                    return@tool McpToolResult.error("INVALID_REGEX", "正则表达式无效: ${e.message}")
                }
                withContext(Dispatchers.IO) {
                    val files = if (root.isDirectory) {
                        (if (recursive) root.walkTopDown() else root.walkTopDown().maxDepth(1))
                            .filter { it.isFile }.toList()
                    } else listOf(root)
                    val candidates = files.filter { filePattern == null || globMatches(it.name, filePattern) }
                    val matches = ArrayList<kotlinx.serialization.json.JsonObject>()
                    var scanned = 0
                    var skippedBinary = 0
                    var truncated = false
                    outer@ for (file in candidates) {
                        if (file.length() > HARD_READ_LIMIT_BYTES) continue
                        val bytes = file.readBytes()
                        if (bytes.indexOf(0.toByte()) >= 0) { skippedBinary++; continue }
                        scanned++
                        val lines = String(bytes, Charsets.UTF_8).split("\n")
                        for ((idx, line) in lines.withIndex()) {
                            var col = -1
                            if (regex != null) {
                                val m = regex.find(line)
                                if (m != null) col = m.range.first
                            } else {
                                val hay = if (ignoreCase) line.lowercase() else line
                                val needle = if (ignoreCase) query.lowercase() else query
                                col = hay.indexOf(needle)
                            }
                            if (col >= 0) {
                                val context = if (line.length > 500) {
                                    val start = (col - contextChars).coerceAtLeast(0)
                                    val end = (col + contextChars).coerceAtMost(line.length)
                                    "…" + line.substring(start, end) + "…"
                                } else line.trim()
                                matches.add(
                                    buildJsonObject {
                                        put("file", JsonPrimitive(file.absolutePath))
                                        put("fileName", JsonPrimitive(file.name))
                                        put("line", JsonPrimitive(idx))
                                        put("column", JsonPrimitive(col))
                                        put("context", JsonPrimitive(context.take(600)))
                                    },
                                )
                                if (matches.size >= maxResults) { truncated = true; break@outer }
                            }
                        }
                    }
                    McpToolResult.json(
                        buildJsonObject {
                            put("root", JsonPrimitive(root.absolutePath))
                            put("query", JsonPrimitive(query))
                            put("count", JsonPrimitive(matches.size))
                            put("scannedFiles", JsonPrimitive(scanned))
                            put("skippedBinary", JsonPrimitive(skippedBinary))
                            put("truncated", JsonPrimitive(truncated))
                            put("matches", JsonArray(matches))
                        },
                    )
                }
            },

            // ---------- 打开/分享 ----------
            f.tool(
                "file.open", "用系统应用打开文件（如用浏览器打开 HTML、播放器播放音频，会在设备上唤起对应 App）", ToolCategory.FILE,
                PermissionScope.READ_FILE, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "path" to Schemas.strSchema("文件路径"),
                    "mimeType" to Schemas.strSchema("强制指定 MIME 类型（默认按扩展名推断）"),
                ),
            ) { args ->
                val file = resolveFile(deps, ToolArgs.str(args, "path"))
                guard(file)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                if (!file.exists()) return@tool McpToolResult.error("FILE_NOT_FOUND", "文件不存在: ${file.absolutePath}")
                if (file.isDirectory) return@tool McpToolResult.error("IS_DIRECTORY", "目标是目录: ${file.absolutePath}")
                val ctx = contextOf(deps)
                val mime = ToolArgs.optStr(args, "mimeType")?.takeIf { it.isNotBlank() } ?: mimeOf(file.name)
                val uri = contentUriFor(ctx, file)
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, mime)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    ctx.startActivity(intent)
                    McpToolResult.json(
                        buildJsonObject {
                            put("opened", JsonPrimitive(true))
                            put("path", JsonPrimitive(file.absolutePath))
                            put("mimeType", JsonPrimitive(mime))
                        },
                    )
                } catch (e: Exception) {
                    McpToolResult.error("NO_HANDLER", "设备上没有能打开 $mime 的应用: ${e.message}")
                }
            },
            f.tool(
                "file.share", "弹出系统分享面板分享文件（发送给微信/QQ/邮件等）", ToolCategory.FILE,
                PermissionScope.READ_FILE, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "path" to Schemas.strSchema("文件路径"),
                    "mimeType" to Schemas.strSchema("强制指定 MIME 类型（默认按扩展名推断）"),
                ),
            ) { args ->
                val file = resolveFile(deps, ToolArgs.str(args, "path"))
                guard(file)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                if (!file.exists()) return@tool McpToolResult.error("FILE_NOT_FOUND", "文件不存在: ${file.absolutePath}")
                val ctx = contextOf(deps)
                val mime = ToolArgs.optStr(args, "mimeType")?.takeIf { it.isNotBlank() } ?: mimeOf(file.name)
                val uri = contentUriFor(ctx, file)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = mime
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, file.name)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                try {
                    ctx.startActivity(Intent.createChooser(send, "分享 ${file.name}").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    McpToolResult.json(
                        buildJsonObject {
                            put("shared", JsonPrimitive(true))
                            put("path", JsonPrimitive(file.absolutePath))
                            put("mimeType", JsonPrimitive(mime))
                        },
                    )
                } catch (e: Exception) {
                    McpToolResult.error("SHARE_FAILED", "分享失败: ${e.message}")
                }
            },

            // ---------- 哈希 ----------
            f.tool(
                "file.hash", "计算文件哈希（MD5 / SHA-1 / SHA-256），校验下载文件或比对加密结果", ToolCategory.FILE,
                PermissionScope.READ_FILE, RiskLevel.LOW, timeoutMs = 60_000,
                inputSchema = Schemas.objectSchema(
                    "path" to Schemas.strSchema("文件路径"),
                    "algorithm" to Schemas.strSchema("算法：MD5 / SHA-1 / SHA-256（默认 SHA-256）"),
                ),
            ) { args ->
                val file = resolveFile(deps, ToolArgs.str(args, "path"))
                guard(file)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                if (!file.exists() || !file.isFile) {
                    return@tool McpToolResult.error("FILE_NOT_FOUND", "文件不存在: ${file.absolutePath}")
                }
                val algorithm = ToolArgs.str(args, "algorithm", "SHA-256").uppercase()
                if (algorithm !in listOf("MD5", "SHA-1", "SHA-256")) {
                    return@tool McpToolResult.error("INVALID_ARGUMENTS", "不支持的算法: $algorithm")
                }
                withContext(Dispatchers.IO) {
                    val digest = MessageDigest.getInstance(algorithm)
                    file.inputStream().use { input ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            digest.update(buf, 0, n)
                        }
                    }
                    val hex = digest.digest().joinToString("") { "%02x".format(it) }
                    McpToolResult.json(
                        buildJsonObject {
                            put("path", JsonPrimitive(file.absolutePath))
                            put("algorithm", JsonPrimitive(algorithm))
                            put("hash", JsonPrimitive(hex))
                            put("sizeBytes", JsonPrimitive(file.length()))
                        },
                    )
                }
            },

            // ---------- 压缩 ----------
            f.tool(
                "file.zip", "把文件或目录打包为 zip", ToolCategory.FILE,
                PermissionScope.WRITE_FILE, RiskLevel.MEDIUM, timeoutMs = 300_000,
                inputSchema = Schemas.objectSchema(
                    "source" to Schemas.strSchema("源文件或目录"),
                    "destination" to Schemas.strSchema("目标 zip 路径（默认 工作目录/<源名>.zip）"),
                ),
            ) { args ->
                val src = resolveFile(deps, ToolArgs.str(args, "source"))
                guard(src)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                if (!src.exists()) return@tool McpToolResult.error("FILE_NOT_FOUND", "源不存在: ${src.absolutePath}")
                val dst = ToolArgs.optStr(args, "destination")?.takeIf { it.isNotBlank() }
                    ?.let { resolveFile(deps, it) }
                    ?: File(WorkDir.directory(contextOf(deps)), "${src.name}.zip")
                guard(dst)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                withContext(Dispatchers.IO) {
                    dst.parentFile?.mkdirs()
                    var entries = 0
                    ZipOutputStream(dst.outputStream().buffered()).use { zos ->
                        val roots = if (src.isDirectory) src.listFiles()?.toList() ?: emptyList() else listOf(src)
                        fun writeEntry(file: File, entryName: String) {
                            if (file.isDirectory) {
                                val children = file.listFiles()?.sortedBy { it.name } ?: return
                                for (child in children) writeEntry(child, "$entryName${child.name}${if (child.isDirectory) "/" else ""}")
                            } else {
                                zos.putNextEntry(ZipEntry(entryName))
                                file.inputStream().use { it.copyTo(zos) }
                                zos.closeEntry()
                                entries++
                            }
                        }
                        for (r in roots) writeEntry(r, r.name + if (r.isDirectory) "/" else "")
                    }
                    McpToolResult.json(
                        buildJsonObject {
                            put("zipped", JsonPrimitive(true))
                            put("path", JsonPrimitive(dst.absolutePath))
                            put("entries", JsonPrimitive(entries))
                            put("sizeBytes", JsonPrimitive(dst.length()))
                        },
                    )
                }
            },
            f.tool(
                "file.unzip", "解压 zip 到目录（自动防护 Zip Slip 路径穿越）", ToolCategory.FILE,
                PermissionScope.WRITE_FILE, RiskLevel.MEDIUM, timeoutMs = 300_000,
                inputSchema = Schemas.objectSchema(
                    "path" to Schemas.strSchema("zip 文件路径"),
                    "destination" to Schemas.strSchema("解压目标目录（默认 工作目录/<zip名>/）"),
                ),
            ) { args ->
                val zip = resolveFile(deps, ToolArgs.str(args, "path"))
                guard(zip)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                if (!zip.exists() || !zip.isFile) {
                    return@tool McpToolResult.error("FILE_NOT_FOUND", "zip 文件不存在: ${zip.absolutePath}")
                }
                val dst = ToolArgs.optStr(args, "destination")?.takeIf { it.isNotBlank() }
                    ?.let { resolveFile(deps, it) }
                    ?: File(WorkDir.directory(contextOf(deps)), zip.nameWithoutExtension)
                guard(dst)?.let { return@tool McpToolResult.error("PATH_BLOCKED", it) }
                withContext(Dispatchers.IO) {
                    dst.mkdirs()
                    var count = 0
                    ZipFile(zip).use { zf ->
                        val entries = zf.entries()
                        while (entries.hasMoreElements()) {
                            val entry = entries.nextElement()
                            val out = File(dst, entry.name)
                            // Zip Slip 防护
                            val canonicalDst = dst.canonicalPath + File.separator
                            if (!out.canonicalPath.startsWith(canonicalDst)) {
                                return@withContext McpToolResult.error("ZIP_SLIP_BLOCKED", "非法条目路径: ${entry.name}")
                            }
                            if (entry.isDirectory) {
                                out.mkdirs()
                            } else {
                                out.parentFile?.mkdirs()
                                zf.getInputStream(entry).use { input ->
                                    out.outputStream().use { input.copyTo(it) }
                                }
                                count++
                            }
                        }
                    }
                    McpToolResult.json(
                        buildJsonObject {
                            put("unzipped", JsonPrimitive(true))
                            put("path", JsonPrimitive(zip.absolutePath))
                            put("destination", JsonPrimitive(dst.absolutePath))
                            put("files", JsonPrimitive(count))
                        },
                    )
                }
            },
        )
    }

    // ---------------- 私有辅助 ----------------

    private fun contextOf(deps: ToolDependencies): Context = deps.browserService.appContext()

    /** 解析路径：空 → 工作目录；相对 → 工作目录下；绝对 → 原样 */
    private fun resolveFile(deps: ToolDependencies, rawPath: String): File {
        val trimmed = rawPath.trim()
        return when {
            trimmed.isEmpty() -> WorkDir.directory(contextOf(deps))
            trimmed.startsWith("/") -> File(trimmed)
            else -> File(WorkDir.directory(contextOf(deps)), trimmed)
        }
    }

    /** 系统保护目录防护，返回 null 表示放行 */
    private fun guard(file: File): String? {
        val p = try {
            file.canonicalPath
        } catch (e: Exception) {
            file.absolutePath
        }
        if (BLOCKED_PREFIXES.any { p == it || p.startsWith("$it/") }) {
            return "路径 $p 位于系统保护目录，禁止访问"
        }
        return null
    }

    /** 简单通配符匹配（* 与 ?） */
    private fun globMatches(name: String, pattern: String): Boolean {
        val regex = pattern.replace(".", "\\.").replace("*", ".*").replace("?", ".")
        return name.matches(Regex(regex, RegexOption.IGNORE_CASE))
    }

    private fun formatTime(millis: Long): String =
        if (millis <= 0) "" else SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(millis))

    /** 常见扩展名 → MIME */
    private fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "txt", "log", "text", "conf", "ini" -> "text/plain"
            "js", "mjs", "cjs" -> "text/javascript"
            "json", "har", "map" -> "application/json"
            "html", "htm" -> "text/html"
            "css" -> "text/css"
            "xml" -> "text/xml"
            "svg" -> "image/svg+xml"
            "py" -> "text/x-python"
            "java" -> "text/x-java-source"
            "kt" -> "text/x-kotlin"
            "md", "markdown" -> "text/markdown"
            "csv", "tsv" -> "text/csv"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "gif" -> "image/gif"
            "webp" -> "image/webp"
            "bmp" -> "image/bmp"
            "pdf" -> "application/pdf"
            "zip" -> "application/zip"
            "gz" -> "application/gzip"
            "mp3", "m4a", "aac" -> "audio/mpeg"
            "wav" -> "audio/wav"
            "mp4", "m4v" -> "video/mp4"
            "apk" -> "application/vnd.android.package-archive"
            else -> "application/octet-stream"
        }
    }

    /** 公共存储路径 → FileProvider content:// URI，保证其他 App 能读取 */
    private fun contentUriFor(context: Context, file: File): Uri =
        androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file,
        )

    /** 递归复制，返回复制的文件数 */
    private fun copyRecursive(src: File, dst: File): Int {
        var count = 0
        if (src.isDirectory) {
            dst.mkdirs()
            src.listFiles()?.forEach { child ->
                count += copyRecursive(child, File(dst, child.name))
            }
        } else {
            dst.parentFile?.mkdirs()
            src.copyTo(dst, overwrite = true)
            count = 1
        }
        return count
    }

    /** 构建目录树 JSON */
    private fun buildTree(dir: File, depth: Int, maxDepth: Int, maxEntries: Int, counter: IntArray): kotlinx.serialization.json.JsonObject =
        buildJsonObject {
            put("name", JsonPrimitive(dir.name))
            put("path", JsonPrimitive(dir.absolutePath))
            put("type", JsonPrimitive("directory"))
            val children = dir.listFiles()?.sortedWith(
                compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() },
            ) ?: return@buildJsonObject
            put(
                "children",
                JsonArray(
                    children.mapNotNull { child ->
                        if (counter[0] >= maxEntries) return@mapNotNull null
                        counter[0]++
                        if (child.isDirectory) {
                            if (depth + 1 < maxDepth) buildTree(child, depth + 1, maxDepth, maxEntries, counter)
                            else buildJsonObject {
                                put("name", JsonPrimitive(child.name))
                                put("path", JsonPrimitive(child.absolutePath))
                                put("type", JsonPrimitive("directory"))
                                put("children", JsonPrimitive("[深度截断]"))
                            }
                        } else {
                            buildJsonObject {
                                put("name", JsonPrimitive(child.name))
                                put("path", JsonPrimitive(child.absolutePath))
                                put("type", JsonPrimitive("file"))
                                put("sizeBytes", JsonPrimitive(child.length()))
                            }
                        }
                    },
                ),
            )
        }
}
