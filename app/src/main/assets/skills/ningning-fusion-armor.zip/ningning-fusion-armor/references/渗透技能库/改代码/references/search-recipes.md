# 搜索配方（放这里，随时找）

## 最直给：限定搜 GitHub

```
site:github.com 关键词
site:github.com 关键词 language:python
site:github.com 关键词 stars:>500
```

## GitHub 站内高级搜索

```
关键词 stars:>100 language:python pushed:>2025-01-01
关键词 in:readme 主题词
```

## 找现成清单

```
awesome 关键词
关键词 开源 推荐
关键词 对比 哪个好
```
