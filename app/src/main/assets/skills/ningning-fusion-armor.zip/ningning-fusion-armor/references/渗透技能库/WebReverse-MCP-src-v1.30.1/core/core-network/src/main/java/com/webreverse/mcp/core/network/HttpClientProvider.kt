package com.webreverse.mcp.core.network

import com.webreverse.mcp.core.common.util.Time
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/** OkHttp 客户端提供者 */
object HttpClientProvider {

    @Volatile
    private var client: OkHttpClient? = null

    fun get(): OkHttpClient = client ?: synchronized(this) {
        client ?: build().also { client = it }
    }

    private fun build(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()
}

/** 网络可达性监控 */
class NetworkMonitor {
    fun isOnline(): Boolean = true
}
