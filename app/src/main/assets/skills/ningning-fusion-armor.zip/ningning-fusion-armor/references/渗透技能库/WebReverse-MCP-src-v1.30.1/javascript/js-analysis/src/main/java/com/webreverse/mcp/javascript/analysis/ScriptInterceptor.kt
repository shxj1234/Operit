package com.webreverse.mcp.javascript.analysis

import kotlinx.serialization.Serializable

/**
 * 脚本拦截改写的转换结果（v1.27.0）。
 */
@Serializable
data class ScriptTransformResult(
    val transformed: String,
    val originalHash: String = "",
    val transformedHash: String = "",
    val debuggerNeutralized: Int = 0,
    val transformRules: List<String> = emptyList(),
    val sriCompatibility: SriCompatibility = SriCompatibility.NONE,
    val notes: List<String> = emptyList(),
)

/** SRI（Subresource Integrity）兼容策略（报告 §37） */
@Serializable
enum class SriCompatibility {
    /** 未处理 SRI */
    NONE,

    /** 检测到脚本被改写，可能违反 HTML 中声明的 integrity——需提示仅实验模式使用 */
    PATCHED_VIOLATES_SRI,
}

/**
 * 脚本拦截器 / 执行前改写器（ScriptTransformer，报告 §7）。
 *
 * 目标：在 JS 被浏览器执行前，对响应 body 做"执行前拦截改写"——
 * 中和 debugger 语句/构造器/定时器循环，而不只是事后 Debugger.resume 或
 * 正则替换字符串（报告 §4/§5/§9 强调的唯一可靠路径）。
 *
 * 安全约束：
 *  - 仅中和调试类结构，绝不做破坏性全局改写（报告 §34"Never globally rewrite"）。
 *  - 保守字符串感知：不误伤字符串字面量与注释中的 "debugger"。
 *  - 记录 originalHash/transformedHash，供 Evidence Graph 溯源。
 *  - SRI 场景标记兼容性风险（剧本被改写后，若 HTML 声明了 integrity，浏览器可能拒绝执行）。
 */
class ScriptInterceptor {

    private fun sha256(input: String): String {
        return try {
            val md = java.security.MessageDigest.getInstance("SHA-256")
            md.digest(input.toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * 中和反调试：返回处理后的脚本。
     *
     * 处理策略（逐条保守）：
     *  1. 移除独立的 `debugger;` 语句（逐行，跳过含字符串引号的行避免误删字面量）
     *  2. 将 `Function("debugger")` / `x.constructor("debugger")` 替换为无害表达式
     *  3. 将 setInterval/setTimeout 回调内的 debugger 语句移除（保留定时器本身）
     *  4. eval("debugger") 内联字面量兜底
     *
     * 不处理：字符串值、注释、属性名。
     */
    fun transform(source: String): ScriptTransformResult {
        val originalHash = sha256(source)
        var out = source
        val notes = mutableListOf<String>()
        val rules = mutableListOf<String>()

        // ---- Pass 1: 独立 debugger 语句（逐行处理，保留行结构） ----
        var debuggerRemoved = 0
        val lines = out.split('\n')
        val cleaned = lines.map { line ->
            // 仅当行内不含字符串引号（' 或 "），避免把字符串/注释里的字面量当语句
            if (line.contains("debugger") && !line.contains("'") && !line.contains("\"")) {
                val newLine = line.replace(Regex("""\bdebugger\s*;?\s*""")) {
                    debuggerRemoved++
                    "__WRMCP_DBG_NEUTRALIZED__;"
                }
                newLine
            } else line
        }.joinToString("\n")
        out = cleaned

        // ---- Pass 2: Function 构造器内嵌 debugger ----
        out = out.replace(Regex("""(?:new\s+)?Function\s*\(\s*["'][^"']*debugger["']\s*\)""")) {
            debuggerRemoved++
            "function(){ return undefined; }"
        }

        // ---- Pass 3: constructor("debugger")() ----
        out = out.replace(Regex("""\.constructor\s*\(\s*["'][^"']*debugger["']\s*\)\s*\(\s*\)""")) {
            debuggerRemoved++
            "(function(){ return undefined; })()"
        }

        // ---- Pass 4: 定时器回调内 debugger ----
        out = out.replace(Regex("""(\{[^}]*?)\bdebugger\s*;?\s*([^}]*\})""")) { m ->
            if (m.value.contains("debugger") && m.value.contains(Regex("""\{[^}]*debugger"""))) {
                m.groupValues[1] + m.groupValues[2]
            } else m.value
        }

        if (debuggerRemoved > 0) {
            rules.add("neutralize_debugger_statements")
            notes.add("中和 $debuggerRemoved 处调试语句（执行前拦截改写）")
        } else {
            notes.add("未发现需要中和的 debugger 语句")
        }

        // ---- 标记最终产物存在（用于 distinct 后的防重复注入） ----
        val marker = "__WRMCP_SCRIPT_PATCHED__"
        if (!out.contains(marker)) {
            out += "\n(globalThis.__WRMCP_SCRIPT_PATCHED__ = (globalThis.__WRMCP_SCRIPT_PATCHED__||0)+1);"
        }

        val transformedHash = sha256(out)

        return ScriptTransformResult(
            transformed = out,
            originalHash = originalHash,
            transformedHash = transformedHash,
            debuggerNeutralized = debuggerRemoved,
            transformRules = rules,
            sriCompatibility = if (debuggerRemoved > 0) SriCompatibility.PATCHED_VIOLATES_SRI else SriCompatibility.NONE,
            notes = notes,
        )
    }

    /**
     * 判断是否为可拦截的 JS 内容类型（脚本响应：text/javascript / application/javascript / application/x-javascript）。
     */
    fun isJavaScriptMime(mimeType: String?): Boolean {
        val m = mimeType?.substringBefore(';')?.trim()?.lowercase() ?: return false
        return m == "text/javascript" ||
            m == "application/javascript" ||
            m == "application/x-javascript" ||
            m.endsWith("/javascript") ||
            m.endsWith("+json") && false // 明确排除 json
    }

    /**
     * SRI 风险提示：当脚本被改写且响应声明了 integrity 时，浏览器可能因哈希失配拒绝执行。
     * 返回一段 JSON 兼容的说明（供 MCP 工具返回）。
     */
    fun sriWarning(integrityHeader: String?, result: ScriptTransformResult): String? {
        if (integrityHeader.isNullOrBlank()) return null
        if (result.sriCompatibility != SriCompatibility.PATCHED_VIOLATES_SRI) return null
        return "脚本已被改写，但响应携带 SRI integrity（$integrityHeader）。浏览器可能因哈希失配拒绝执行——" +
            "实验/逆向模式可同时拦截 HTML 剥离对应 <script integrity>，或禁用 SRI 校验。"
    }
}