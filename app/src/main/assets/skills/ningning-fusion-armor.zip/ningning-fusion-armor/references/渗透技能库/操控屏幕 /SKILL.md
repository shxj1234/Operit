---
name: virtual-display-launcher
description: 在虚拟屏幕上启动任意 Android 应用 — 自动查找包名、解析主 Activity、创建虚拟屏并完成启动。
---

# Virtual Display Launcher

在独立虚拟屏幕（Virtual Display）上启动任意 Android 应用，不影响主屏幕操作。

## 适用场景

- 需要在虚拟屏上隔离运行应用
- 多应用并行操作（每个虚拟屏独立运行不同应用）
- 自动化测试需要独立显示环境
- 主屏幕被占用时需要额外显示空间

## 所需包

| 包名 | 用途 |
|------|------|
| `super_admin` | shell 执行 Android 系统命令（pm / am） |
| `system_tools` | 辅助系统操作 |
| `Automatic_ui_subagent` | 创建虚拟屏会话 |

## 执行步骤

### 1. 激活必需包

```
use_package: super_admin
use_package: system_tools
```

### 2. 查找目标包名

用关键词搜索已安装应用：

```
pm list packages | grep -i <关键词>
```

- 示例：`pm list packages | grep -i calc` → `com.android.bbkcalculator`
- 若搜索无结果，尝试更宽泛关键词或用 `pm list packages` 全量排查

### 3. 获取主 Activity

```
pm dump <包名> | grep -A1 'filter' | grep '<包名>/' | head -3
```

- 从输出中提取 `.Calculator` 形式的短名
- 主 Activity 拼接为 `<包名>/<短名>`，如 `com.android.bbkcalculator/.Calculator`

### 4. 创建虚拟屏

激活 `Automatic_ui_subagent` 包后调用 `run_subagent_virtual`：

- `intent`: 使用最小化任务，如 "停留在桌面，不要做任何操作，仅确认虚拟屏已就绪。"
- `max_steps`: 设为 `1`
- `agent_id`: 传入一个有意义标识，如 `vd_<app_keyword>`
- 从返回结果中提取 `data.displayId`（整数）

### 5. 在虚拟屏启动应用

```
am start -n <包名>/<主Activity> --display <displayId>
```

- 必须用 `super_admin:shell` 执行，不能用 `start_app`（`start_app` 只启动到主屏）
- 也不要用子代理 Launch（子代理 Launch 无法传 `--display` 参数）
- 返回 `exitCode=0` + `Starting: Intent { ... }` 即成功

### 6. 后续操作（可选）

若需在虚拟屏上继续 UI 自动化，复用第4步返回的 `agentId`：

```
run_subagent_virtual(agent_id=<agentId>, intent=...)
```

## 约束与注意事项

- `start_app` 工具只启动到主屏幕，**不能**指定虚拟屏
- 子代理的 Launch 动作**不支持** `--display` 参数
- `list_installed_apps` 默认不含系统应用，用 `pm list packages` 更可靠
- 每个虚拟屏会话的 `agent_id` 必须非 `'default'`
- 同一包名不能同时在两个虚拟屏中并行操作

## 期望输出

| 步骤 | 预期结果 |
|------|----------|
| 步骤2 | 包名（如 `com.android.bbkcalculator`） |
| 步骤3 | 主 Activity 短名（如 `.Calculator`） |
| 步骤4 | displayId（整数，如 `63`） |
| 步骤5 | `exitCode=0`，应用在虚拟屏可见 |

## 示例：在虚拟屏启动计算器

```
# 步骤2
shell: pm list packages | grep -i calc
→ com.android.bbkcalculator

# 步骤3
shell: pm dump com.android.bbkcalculator | grep -A1 'filter' | grep 'com.android.bbkcalculator/' | head -3
→ com.android.bbkcalculator/.Calculator

# 步骤4
run_subagent_virtual(intent="停留在桌面，不要做任何操作，仅确认虚拟屏已就绪。", max_steps=1, agent_id="calc_virtual_1")
→ displayId=63, agentId="calc_virtual_1"

# 步骤5
shell: am start -n com.android.bbkcalculator/.Calculator --display 63
→ exitCode=0 ✓
```
