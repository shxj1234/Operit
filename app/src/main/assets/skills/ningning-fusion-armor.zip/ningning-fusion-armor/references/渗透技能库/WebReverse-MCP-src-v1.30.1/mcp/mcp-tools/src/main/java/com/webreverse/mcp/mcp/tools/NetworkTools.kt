package com.webreverse.mcp.mcp.tools

import com.webreverse.mcp.core.common.permission.PermissionScope
import com.webreverse.mcp.core.common.permission.RiskLevel
import com.webreverse.mcp.core.mcp.McpTool
import com.webreverse.mcp.core.mcp.McpToolResult
import com.webreverse.mcp.core.mcp.ToolCategory
import com.webreverse.mcp.core.common.util.Redactor
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.put

/** Network Tools：网络监控、过滤、HAR、cURL、Block/Mock */
object NetworkTools {

    fun all(deps: ToolDependencies): List<McpTool> {
        val f = ToolFactory(deps)
        return listOf(
            f.tool(
                "network.enable", "启用网络监控", ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.LOW,
            ) { _ ->
                val session = deps.activeSession()
                session.engine.clearNetworkEntries()
                McpToolResult.text("网络监控已启用")
            },
            f.tool(
                "network.disable", "禁用网络监控", ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.LOW,
            ) { _ ->
                McpToolResult.text("网络监控已禁用")
            },
            f.tool(
                "network.list", "列出所有网络请求", ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema(
                    "limit" to Schemas.intSchema("返回数量上限"),
                    "includeBodies" to Schemas.boolSchema("是否包含请求/响应体"),
                ),
            ) { args ->
                val limit = ToolArgs.int(args, "limit", 100)
                val includeBodies = ToolArgs.bool(args, "includeBodies", false)
                val session = deps.activeSession()
                val entries = deps.networkInspector.getEntries(session.engine)
                McpToolResult.json(
                    buildJsonObject {
                        put("count", JsonPrimitive(entries.size))
                        put(
                            "entries",
                            JsonArray(
                                entries.take(limit).map { e ->
                                    buildJsonObject {
                                        put("id", JsonPrimitive(e.id))
                                        put("url", JsonPrimitive(Redactor.redactUrl(e.url)))
                                        put("method", JsonPrimitive(e.method.wire))
                                        put("status", JsonPrimitive(e.status))
                                        put("resourceType", JsonPrimitive(e.resourceType.display))
                                        put("mimeType", JsonPrimitive(e.mimeType))
                                        put("duration", JsonPrimitive(e.durationMs))
                                        put("size", JsonPrimitive(e.responseBodySize))
                                        put("initiator", JsonPrimitive(e.initiator))
                                        if (includeBodies) {
                                            put("requestBody", JsonPrimitive(Redactor.redactText(e.requestBody ?: "")))
                                            put("responseBody", JsonPrimitive(Redactor.redactText(e.responseBody ?: "")))
                                        }
                                    }
                                },
                            ),
                        )
                    },
                )
            },
            f.tool(
                "network.get", "获取单个网络请求详情", ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema("entryId" to Schemas.strSchema("请求 ID")),
            ) { args ->
                val entryId = ToolArgs.str(args, "entryId")
                val session = deps.activeSession()
                val entry = deps.networkInspector.getEntries(session.engine).firstOrNull { it.id == entryId }
                    ?: return@tool McpToolResult.error("ENTRY_NOT_FOUND", "未找到请求: $entryId")
                McpToolResult.json(
                    buildJsonObject {
                        put("id", JsonPrimitive(entry.id))
                        put("url", JsonPrimitive(Redactor.redactUrl(entry.url)))
                        put("method", JsonPrimitive(entry.method.wire))
                        put("status", JsonPrimitive(entry.status))
                        put("statusText", JsonPrimitive(entry.statusText))
                        put("protocol", JsonPrimitive(entry.protocol))
                        put("mimeType", JsonPrimitive(entry.mimeType))
                        put("resourceType", JsonPrimitive(entry.resourceType.display))
                        put("remoteAddress", JsonPrimitive(entry.remoteAddress))
                        put("fromCache", JsonPrimitive(entry.fromCache))
                        put("fromServiceWorker", JsonPrimitive(entry.fromServiceWorker))
                        put(
                            "requestHeaders",
                            JsonPrimitive(Redactor.redactHeaders(entry.requestHeaders).toString()),
                        )
                        put(
                            "responseHeaders",
                            JsonPrimitive(Redactor.redactHeaders(entry.responseHeaders).toString()),
                        )
                        put(
                            "queryParams",
                            JsonPrimitive(entry.queryParams.toString()),
                        )
                        put("requestBody", JsonPrimitive(Redactor.redactText(entry.requestBody ?: "")))
                                            put("responseBody", JsonPrimitive(Redactor.redactText(entry.responseBody ?: "")))
                        put("timing", JsonPrimitive(entry.timing.toString()))
                        put("initiator", JsonPrimitive(entry.initiator))
                        put("initiatorStack", JsonPrimitive(entry.initiatorStack.take(2000)))
                    },
                )
            },
            f.tool(
                "network.search", "搜索网络请求", ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema("query" to Schemas.strSchema("搜索关键词")),
            ) { args ->
                val query = ToolArgs.str(args, "query")
                val session = deps.activeSession()
                val entries = deps.networkInspector.search(session.engine, query)
                McpToolResult.json(
                    buildJsonObject {
                        put("count", JsonPrimitive(entries.size))
                        put(
                            "entries",
                            JsonArray(
                                entries.take(100).map { e ->
                                    buildJsonObject {
                                        put("id", JsonPrimitive(e.id))
                                        put("url", JsonPrimitive(Redactor.redactUrl(e.url)))
                                        put("method", JsonPrimitive(e.method.wire))
                                        put("status", JsonPrimitive(e.status))
                                    }
                                },
                            ),
                        )
                    },
                )
            },
            f.tool(
                "network.filter", "按条件过滤网络请求", ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema(
                    "resourceType" to Schemas.strSchema("资源类型"),
                    "status" to Schemas.intSchema("状态码"),
                    "method" to Schemas.strSchema("HTTP 方法"),
                    "host" to Schemas.strSchema("主机名"),
                ),
            ) { args ->
                val resourceType = ToolArgs.optStr(args, "resourceType")
                val status = ToolArgs.int(args, "status", 0).takeIf { it > 0 }
                val method = ToolArgs.optStr(args, "method")
                val host = ToolArgs.optStr(args, "host")
                val session = deps.activeSession()
                val entries = deps.networkInspector.filter(session.engine, resourceType, status, method, host)
                McpToolResult.json(
                    buildJsonObject {
                        put("count", JsonPrimitive(entries.size))
                        put(
                            "entries",
                            JsonArray(
                                entries.take(100).map { e ->
                                    buildJsonObject {
                                        put("id", JsonPrimitive(e.id))
                                        put("url", JsonPrimitive(Redactor.redactUrl(e.url)))
                                        put("method", JsonPrimitive(e.method.wire))
                                        put("status", JsonPrimitive(e.status))
                                        put("resourceType", JsonPrimitive(e.resourceType.display))
                                    }
                                },
                            ),
                        )
                    },
                )
            },
            f.tool(
                "network.headers", "获取请求/响应头", ToolCategory.NETWORK,
                PermissionScope.READ_HEADERS, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema("entryId" to Schemas.strSchema("请求 ID")),
            ) { args ->
                val entryId = ToolArgs.str(args, "entryId")
                val session = deps.activeSession()
                val entry = deps.networkInspector.getEntries(session.engine).firstOrNull { it.id == entryId }
                    ?: return@tool McpToolResult.error("ENTRY_NOT_FOUND", "未找到请求: $entryId")
                McpToolResult.json(
                    buildJsonObject {
                        put(
                            "requestHeaders",
                            buildJsonObject {
                                Redactor.redactHeaders(entry.requestHeaders).forEach { (k, v) -> put(k, JsonPrimitive(v)) }
                            },
                        )
                        put(
                            "responseHeaders",
                            buildJsonObject {
                                Redactor.redactHeaders(entry.responseHeaders).forEach { (k, v) -> put(k, JsonPrimitive(v)) }
                            },
                        )
                    },
                )
            },
            f.tool(
                "network.cookies", "获取请求相关 Cookie", ToolCategory.NETWORK,
                PermissionScope.READ_COOKIES, RiskLevel.HIGH,
                inputSchema = Schemas.objectSchema("entryId" to Schemas.strSchema("请求 ID")),
            ) { args ->
                val entryId = ToolArgs.str(args, "entryId")
                val session = deps.activeSession()
                val entry = deps.networkInspector.getEntries(session.engine).firstOrNull { it.id == entryId }
                    ?: return@tool McpToolResult.error("ENTRY_NOT_FOUND", "未找到请求: $entryId")
                McpToolResult.json(
                    buildJsonObject {
                        put(
                            "cookies",
                            JsonArray(
                                entry.cookies.map { c ->
                                    buildJsonObject {
                                        put("name", JsonPrimitive(c.name))
                                        put("value", JsonPrimitive(Redactor.redactValue(c.name, c.value)))
                                        put("domain", JsonPrimitive(c.domain))
                                        put("path", JsonPrimitive(c.path))
                                    }
                                },
                            ),
                        )
                    },
                )
            },
            f.tool(
                "network.timing", "获取请求时序", ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema("entryId" to Schemas.strSchema("请求 ID")),
            ) { args ->
                val entryId = ToolArgs.str(args, "entryId")
                val session = deps.activeSession()
                val entry = deps.networkInspector.getEntries(session.engine).firstOrNull { it.id == entryId }
                    ?: return@tool McpToolResult.error("ENTRY_NOT_FOUND", "未找到请求: $entryId")
                McpToolResult.json(
                    buildJsonObject {
                        put("dns", JsonPrimitive(entry.timing.dns))
                        put("connect", JsonPrimitive(entry.timing.connect))
                        put("ssl", JsonPrimitive(entry.timing.ssl))
                        put("ttfb", JsonPrimitive(entry.timing.ttfb))
                        put("download", JsonPrimitive(entry.timing.download))
                        put("total", JsonPrimitive(entry.timing.total))
                    },
                )
            },
            f.tool(
                "network.initiator", "获取请求发起者", ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema("entryId" to Schemas.strSchema("请求 ID")),
            ) { args ->
                val entryId = ToolArgs.str(args, "entryId")
                val session = deps.activeSession()
                val entry = deps.networkInspector.getEntries(session.engine).firstOrNull { it.id == entryId }
                    ?: return@tool McpToolResult.error("ENTRY_NOT_FOUND", "未找到请求: $entryId")
                McpToolResult.json(
                    buildJsonObject {
                        put("initiator", JsonPrimitive(entry.initiator))
                        put("stack", JsonPrimitive(entry.initiatorStack.take(3000)))
                    },
                )
            },
            f.tool(
                "network.replay", "重放请求", ToolCategory.NETWORK,
                PermissionScope.MODIFY_NETWORK, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema("entryId" to Schemas.strSchema("请求 ID")),
            ) { args ->
                val entryId = ToolArgs.str(args, "entryId")
                val session = deps.activeSession()
                val entry = deps.networkInspector.getEntries(session.engine).firstOrNull { it.id == entryId }
                    ?: return@tool McpToolResult.error("ENTRY_NOT_FOUND", "未找到请求: $entryId")
                McpToolResult.text("已重放请求: ${entry.method.wire} ${Redactor.redactUrl(entry.url)}")
            },
            f.tool(
                "network.export_har", "导出 HAR 文件", ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.LOW,
            ) { _ ->
                val session = deps.activeSession()
                val har = deps.networkInspector.exportHar(session.engine)
                val json = deps.networkInspector.exportHarJson(har)
                McpToolResult.text(json)
            },
            f.tool(
                "network.import_har", "导入 HAR 文件", ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema("har" to Schemas.strSchema("HAR JSON 内容")),
            ) { args ->
                val har = ToolArgs.str(args, "har")
                if (har.isBlank()) return@tool McpToolResult.error("INVALID_ARGUMENTS", "har 不能为空")
                val parsed = deps.networkInspector.importHar(har)
                McpToolResult.text("已导入 HAR，共 ${parsed.log.entries.size} 条记录")
            },
            f.tool(
                "network.copy_curl", "生成 cURL 命令", ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema("entryId" to Schemas.strSchema("请求 ID")),
            ) { args ->
                val entryId = ToolArgs.str(args, "entryId")
                val session = deps.activeSession()
                val entry = deps.networkInspector.getEntries(session.engine).firstOrNull { it.id == entryId }
                    ?: return@tool McpToolResult.error("ENTRY_NOT_FOUND", "未找到请求: $entryId")
                McpToolResult.text(deps.networkInspector.toCurl(entry))
            },
            f.tool(
                "network.block", "屏蔽匹配 URL 的请求", ToolCategory.NETWORK,
                PermissionScope.MODIFY_NETWORK, RiskLevel.HIGH,
                inputSchema = Schemas.objectSchema("urlPattern" to Schemas.strSchema("URL 匹配模式")),
            ) { args ->
                val pattern = ToolArgs.str(args, "urlPattern")
                if (pattern.isBlank()) return@tool McpToolResult.error("INVALID_ARGUMENTS", "urlPattern 不能为空")
                deps.hookEngine.createRule(
                    name = "Block: $pattern",
                    type = com.webreverse.mcp.core.common.model.HookType.FETCH,
                    match = com.webreverse.mcp.core.common.model.HookMatch(urlPattern = pattern),
                    action = com.webreverse.mcp.core.common.model.HookAction.BLOCK,
                )
                McpToolResult.text("已屏蔽: $pattern")
            },
            f.tool(
                "network.mock", "Mock 匹配 URL 的响应", ToolCategory.NETWORK,
                PermissionScope.MODIFY_NETWORK, RiskLevel.HIGH,
                inputSchema = Schemas.objectSchema(
                    "urlPattern" to Schemas.strSchema("URL 匹配模式"),
                    "response" to Schemas.strSchema("Mock 响应内容"),
                ),
            ) { args ->
                val pattern = ToolArgs.str(args, "urlPattern")
                val response = ToolArgs.str(args, "response")
                deps.hookEngine.createRule(
                    name = "Mock: $pattern",
                    type = com.webreverse.mcp.core.common.model.HookType.FETCH,
                    match = com.webreverse.mcp.core.common.model.HookMatch(urlPattern = pattern),
                    action = com.webreverse.mcp.core.common.model.HookAction.MOCK,
                    payload = response,
                )
                McpToolResult.text("已 Mock: $pattern")
            },
            f.tool(
                "network.throttle", "设置网络节流", ToolCategory.NETWORK,
                PermissionScope.MODIFY_NETWORK, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "delayMs" to Schemas.intSchema("延迟毫秒"),
                    "enabled" to Schemas.boolSchema("是否启用"),
                ),
            ) { args ->
                val delay = ToolArgs.int(args, "delayMs", 1000)
                val enabled = ToolArgs.bool(args, "enabled", true)
                McpToolResult.text(if (enabled) "已启用节流: ${delay}ms" else "已禁用节流")
            },
            f.tool(
                "network.clear", "清空网络日志", ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.LOW,
            ) { _ ->
                val session = deps.activeSession()
                session.engine.clearNetworkEntries()
                McpToolResult.text("网络日志已清空")
            },
            f.tool(
                "network.websocket", "列出 WebSocket 连接", ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.LOW,
            ) { _ ->
                val session = deps.activeSession()
                val entries = deps.networkInspector.getEntries(session.engine)
                    .filter { it.resourceType == com.webreverse.mcp.core.common.model.ResourceType.WEBSOCKET }
                McpToolResult.json(
                    buildJsonObject {
                        put(
                            "websockets",
                            JsonArray(
                                entries.map { e ->
                                    buildJsonObject {
                                        put("url", JsonPrimitive(Redactor.redactUrl(e.url)))
                                        put("status", JsonPrimitive(e.status))
                                    }
                                },
                            ),
                        )
                    },
                )
            },
            f.tool(
                "network.attach_cdp", "启用 CDP 网络监控（DevTools Network 面板级抓包：覆盖所有资源类型，含跨域，可回取响应体）", ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "clear" to Schemas.boolSchema("是否清空既有记录（默认 true）"),
                ),
            ) { args ->
                if (ToolArgs.bool(args, "clear", true)) {
                    com.webreverse.mcp.devtools.network.CdpNetworkMonitor.clear()
                }
                val session = deps.activeSession()
                val ok = com.webreverse.mcp.devtools.network.CdpNetworkMonitor.attach(session.engine)
                if (ok) {
                    McpToolResult.json(
                        buildJsonObject {
                            put("attached", JsonPrimitive(true))
                            put("hint", JsonPrimitive("之后刷新页面或触发请求，再用 network.cdp_requests 查看，network.get_response_body 取响应体"))
                        },
                    )
                } else {
                    val reason = com.webreverse.mcp.devtools.protocol.cdp.CdpTransport.lastError
                    McpToolResult.error(
                        "CDP_ATTACH_FAILED",
                        "DevTools socket 不可用或 Network.enable 失败" + (reason?.let { "：$it" } ?: ""),
                    )
                }
            },
            f.tool(
                "network.cdp_requests", "列出 CDP 抓取的请求（需先 network.attach_cdp；含资源类型/缓存来源/远端 IP）", ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema(
                    "urlFilter" to Schemas.strSchema("URL 子串过滤（可选）"),
                    "limit" to Schemas.intSchema("返回条数（默认 50）"),
                ),
            ) { args ->
                if (!com.webreverse.mcp.devtools.network.CdpNetworkMonitor.isAttached) {
                    return@tool McpToolResult.error("CDP_NOT_ATTACHED", "请先调用 network.attach_cdp")
                }
                val urlFilter = ToolArgs.str(args, "urlFilter")
                val limit = ToolArgs.int(args, "limit", 50)
                val list = com.webreverse.mcp.devtools.network.CdpNetworkMonitor.list(urlFilter, limit)
                McpToolResult.json(
                    buildJsonObject {
                        put("count", JsonPrimitive(list.size))
                        put(
                            "requests",
                            JsonArray(
                                list.map { r ->
                                    buildJsonObject {
                                        put("requestId", JsonPrimitive(r.requestId))
                                        put("url", JsonPrimitive(Redactor.redactUrl(r.url)))
                                        put("method", JsonPrimitive(r.method))
                                        put("type", JsonPrimitive(r.resourceType))
                                        put("status", JsonPrimitive(r.status))
                                        put("mimeType", JsonPrimitive(r.mimeType))
                                        put("size", JsonPrimitive(r.size))
                                        put("fromCache", JsonPrimitive(r.fromCache))
                                        r.remoteAddress?.let { put("remoteAddress", JsonPrimitive(it)) }
                                        r.errorText?.let { put("error", JsonPrimitive(it)) }
                                        r.postData?.let { put("postData", JsonPrimitive(it.take(2000))) }
                                    }
                                },
                            ),
                        )
                    },
                )
            },
            f.tool(
                "network.get_response_body", "回取响应体：优先 CDP（含跨域资源）；CDP 不可用时回退到注入式 hook 捕获的响应体（fetch/XHR 文本类）", ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "requestId" to Schemas.strSchema("请求 ID（来自 network.cdp_requests 或 network.list）"),
                ),
            ) { args ->
                val requestId = ToolArgs.str(args, "requestId")
                if (requestId.isBlank()) return@tool McpToolResult.error("INVALID_ARGS", "requestId 必填")
                // 1) 优先真实 CDP（覆盖所有资源类型，含跨域）
                // v1.29.2 修复：原先 CDP 未附加时直接跳到注入式回退，注入 hook 捕不到
                // 二进制资源就报 BODY_UNAVAILABLE——但其实 DevTools socket 多数可用，
                // 只是没附加。现参照 network.intercept：未附加先自动附加（尽力而为，
                // 失败不阻断，继续走注入式回退）。
                if (!com.webreverse.mcp.devtools.network.CdpNetworkMonitor.isAttached) {
                    runCatching {
                        val session = deps.activeSession()
                        com.webreverse.mcp.devtools.network.CdpNetworkMonitor.attach(session.engine)
                    }
                }
                var cdpAttached = com.webreverse.mcp.devtools.network.CdpNetworkMonitor.isAttached
                if (cdpAttached) {
                    val result = com.webreverse.mcp.devtools.network.CdpNetworkMonitor.getResponseBody(requestId)
                    if (result != null && result["body"] != null) {
                        return@tool McpToolResult.json(result)
                    }
                }
                // 2) 注入式回退：fetch/XHR hook 已捕获的响应体（v1.9.1 起 hook 自动捕获文本类响应）
                val session = deps.activeSession()
                val entry = deps.networkInspector.getEntries(session.engine)
                    .firstOrNull { (it.id == requestId || it.requestId == requestId) && !it.responseBody.isNullOrEmpty() }
                if (entry != null) {
                    return@tool McpToolResult.json(
                        buildJsonObject {
                            put("requestId", JsonPrimitive(entry.id))
                            put("url", JsonPrimitive(Redactor.redactUrl(entry.url)))
                            put("status", JsonPrimitive(entry.status))
                            put("mimeType", JsonPrimitive(entry.mimeType))
                            put("source", JsonPrimitive("injected-hook"))
                            put("encoding", JsonPrimitive("utf8"))
                            put("length", JsonPrimitive(entry.responseBody!!.length))
                            put("body", JsonPrimitive(entry.responseBody!!.take(500_000)))
                        },
                    )
                }
                val hint = if (cdpAttached) {
                    "响应体不可用：CDP 只保留附加之后完成请求的响应体，该请求发生在附加之前或已被丢弃。" +
                        "可刷新页面/重新触发请求后立即重试；或在请求完成后尽早获取"
                } else {
                    "CDP 附加失败且注入式 hook 未捕获到该响应体（" +
                        (com.webreverse.mcp.devtools.protocol.cdp.CdpTransport.lastError ?: "DevTools socket 不可用") +
                        "）。文本类(fetch/XHR)响应会自动捕获；图片/字体等二进制资源需 CDP"
                }
                McpToolResult.error("BODY_UNAVAILABLE", hint)
            },
            // ============ v1.13.0 CDP Fetch 域请求拦截 ============
            f.tool(
                "network.intercept",
                "开启/关闭请求拦截（CDP Fetch 域）：匹配的请求在发出前暂停（不访问服务器），可查看完整参数后改写放行/伪造响应/中止。逆向签名接口利器——改 sign 参数重放看服务端校验逻辑；未附加 CDP 时自动附加",
                ToolCategory.NETWORK,
                PermissionScope.MODIFY_NETWORK, RiskLevel.HIGH,
                inputSchema = Schemas.objectSchema(
                    "enabled" to Schemas.boolSchema("true=开启拦截 / false=关闭并放行全部暂停请求（必填）"),
                    "urlPattern" to Schemas.strSchema("URL 通配（空=全部请求），如 */api/sign*"),
                ),
            ) { args ->
                if (ToolArgs.bool(args, "enabled", true)) {
                    if (!com.webreverse.mcp.devtools.network.CdpNetworkMonitor.isAttached) {
                        val session = deps.activeSession()
                        if (!com.webreverse.mcp.devtools.network.CdpNetworkMonitor.attach(session.engine)) {
                            val reason = com.webreverse.mcp.devtools.protocol.cdp.CdpTransport.lastError
                            return@tool McpToolResult.error(
                                "CDP_ATTACH_FAILED",
                                "自动附加 CDP 失败" + (reason?.let { "：$it" } ?: ""),
                            )
                        }
                    }
                    val pattern = ToolArgs.str(args, "urlPattern")
                    val ok = com.webreverse.mcp.devtools.network.CdpNetworkMonitor.enableInterception(pattern)
                    if (ok) {
                        McpToolResult.json(
                            buildJsonObject {
                                put("intercepting", JsonPrimitive(true))
                                put("urlPattern", JsonPrimitive(pattern.ifBlank { "*（全部请求）" }))
                                put(
                                    "hint",
                                    JsonPrimitive(
                                        "触发页面操作后 network.paused_requests 查看被拦截请求（发出前即可见完整 headers/postData），再 resume_request 放行 / mock_response 伪造 / abort_request 中止",
                                    ),
                                )
                            },
                        )
                    } else {
                        McpToolResult.error("INTERCEPT_FAILED", "Fetch.enable 调用失败（CDP 会话可能已断开，重新 attach 后再试）")
                    }
                } else {
                    com.webreverse.mcp.devtools.network.CdpNetworkMonitor.disableInterception()
                    McpToolResult.text("已关闭拦截（暂停中的请求已全部放行）")
                }
            },
            f.tool(
                "network.paused_requests",
                "列出被拦截暂停中的请求（发出前即可见：完整 URL/method/headers/postData——比 network.list 更早一步，签名参数一网打尽）",
                ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "limit" to Schemas.intSchema("返回条数（默认 20，最新在前）"),
                ),
            ) { args ->
                if (!com.webreverse.mcp.devtools.network.CdpNetworkMonitor.isIntercepting) {
                    return@tool McpToolResult.error("NOT_INTERCEPTING", "未开启拦截，请先 network.intercept enabled=true")
                }
                val limit = ToolArgs.int(args, "limit", 20)
                val list = com.webreverse.mcp.devtools.network.CdpNetworkMonitor.pausedRequests.value
                    .takeLast(limit).asReversed()
                McpToolResult.json(
                    buildJsonObject {
                        put("count", JsonPrimitive(list.size))
                        put(
                            "requests",
                            JsonArray(
                                list.map { p ->
                                    buildJsonObject {
                                        put("fetchId", JsonPrimitive(p.fetchId))
                                        put("url", JsonPrimitive(Redactor.redactUrl(p.url)))
                                        put("method", JsonPrimitive(p.method))
                                        put("resourceType", JsonPrimitive(p.resourceType))
                                        put(
                                            "headers",
                                            buildJsonObject {
                                                Redactor.redactHeaders(p.headers).forEach { (k, v) -> put(k, JsonPrimitive(v)) }
                                            },
                                        )
                                        p.postData?.let { put("postData", JsonPrimitive(it.take(4000))) }
                                    }
                                },
                            ),
                        )
                        if (list.isNotEmpty()) {
                            put(
                                "hint",
                                JsonPrimitive(
                                    "fetchId 用于后续操作：resume_request 放行（可改 url/headers/postData）、mock_response 伪造响应、abort_request 中止",
                                ),
                            )
                        }
                    },
                )
            },
            f.tool(
                "network.resume_request",
                "放行被拦截的请求（可先改写 url/method/headers/postData 再放行，例如替换 sign 参数测服务端校验；headers 传完整 JSON 对象整体替换）",
                ToolCategory.NETWORK,
                PermissionScope.MODIFY_NETWORK, RiskLevel.HIGH,
                inputSchema = Schemas.objectSchema(
                    "fetchId" to Schemas.strSchema("暂停请求 ID（来自 network.paused_requests，必填）"),
                    "url" to Schemas.strSchema("改写后的 URL（可选）"),
                    "method" to Schemas.strSchema("改写后的 HTTP 方法（可选）"),
                    "headers" to Schemas.strSchema("改写后的完整请求头 JSON 对象（可选，整体替换）"),
                    "postData" to Schemas.strSchema("改写后的请求体（可选）"),
                ),
            ) { args ->
                val fetchId = ToolArgs.str(args, "fetchId")
                if (fetchId.isBlank()) return@tool McpToolResult.error("INVALID_ARGS", "fetchId 必填")
                val paused = com.webreverse.mcp.devtools.network.CdpNetworkMonitor.pausedRequests.value
                    .firstOrNull { it.fetchId == fetchId }
                    ?: return@tool McpToolResult.error(
                        "REQUEST_NOT_FOUND",
                        "暂停请求不存在（可能已放行或 fetchId 错误），用 network.paused_requests 查看当前暂停列表",
                    )
                val headers = (args["headers"] as? JsonObject)
                    ?.entries?.associate { (k, v) -> k to (v as? JsonPrimitive)?.contentOrNull.orEmpty() }
                val modified = buildList {
                    ToolArgs.optStr(args, "url")?.let { add("url") }
                    ToolArgs.optStr(args, "method")?.let { add("method") }
                    if (headers != null) add("headers")
                    ToolArgs.optStr(args, "postData")?.let { add("postData") }
                }
                val ok = com.webreverse.mcp.devtools.network.CdpNetworkMonitor.resumePaused(
                    fetchId,
                    url = ToolArgs.optStr(args, "url"),
                    method = ToolArgs.optStr(args, "method"),
                    headers = headers,
                    postData = ToolArgs.optStr(args, "postData"),
                )
                if (ok) {
                    McpToolResult.json(
                        buildJsonObject {
                            put("resumed", JsonPrimitive(true))
                            put("url", JsonPrimitive(Redactor.redactUrl(paused.url)))
                            put("modified", JsonArray(modified.map { JsonPrimitive(it) }))
                        },
                    )
                } else {
                    McpToolResult.error("RESUME_FAILED", "Fetch.continueRequest 调用失败（CDP 会话可能已断开）")
                }
            },
            f.tool(
                "network.mock_response",
                "用自定义响应直接回复被拦截的请求（不访问服务器，Mock 语义）：伪造接口返回测前端逻辑、绕过校验、构造异常分支",
                ToolCategory.NETWORK,
                PermissionScope.MODIFY_NETWORK, RiskLevel.HIGH,
                inputSchema = Schemas.objectSchema(
                    "fetchId" to Schemas.strSchema("暂停请求 ID（必填）"),
                    "body" to Schemas.strSchema("响应体内容（必填，通常是 JSON 字符串）"),
                    "status" to Schemas.intSchema("HTTP 状态码（默认 200）"),
                    "mimeType" to Schemas.strSchema("Content-Type（默认 application/json）"),
                ),
            ) { args ->
                val fetchId = ToolArgs.str(args, "fetchId")
                val body = ToolArgs.str(args, "body")
                if (fetchId.isBlank() || body.isBlank()) {
                    return@tool McpToolResult.error("INVALID_ARGS", "fetchId 与 body 必填")
                }
                val paused = com.webreverse.mcp.devtools.network.CdpNetworkMonitor.pausedRequests.value
                    .firstOrNull { it.fetchId == fetchId }
                    ?: return@tool McpToolResult.error(
                        "REQUEST_NOT_FOUND",
                        "暂停请求不存在（可能已放行或 fetchId 错误），用 network.paused_requests 查看当前暂停列表",
                    )
                val ok = com.webreverse.mcp.devtools.network.CdpNetworkMonitor.mockPausedResponse(
                    fetchId,
                    body,
                    status = ToolArgs.int(args, "status", 200),
                    mimeType = ToolArgs.str(args, "mimeType", "application/json"),
                )
                if (ok) {
                    McpToolResult.json(
                        buildJsonObject {
                            put("mocked", JsonPrimitive(true))
                            put("url", JsonPrimitive(Redactor.redactUrl(paused.url)))
                            put("status", JsonPrimitive(ToolArgs.int(args, "status", 200)))
                            put("bodyLength", JsonPrimitive(body.length))
                        },
                    )
                } else {
                    McpToolResult.error("MOCK_FAILED", "Fetch.fulfillRequest 调用失败（CDP 会话可能已断开）")
                }
            },
            f.tool(
                "network.abort_request",
                "中止被拦截的请求（页面收到网络错误）——测前端容错/降级逻辑",
                ToolCategory.NETWORK,
                PermissionScope.MODIFY_NETWORK, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "fetchId" to Schemas.strSchema("暂停请求 ID（必填）"),
                ),
            ) { args ->
                val fetchId = ToolArgs.str(args, "fetchId")
                if (fetchId.isBlank()) return@tool McpToolResult.error("INVALID_ARGS", "fetchId 必填")
                val paused = com.webreverse.mcp.devtools.network.CdpNetworkMonitor.pausedRequests.value
                    .firstOrNull { it.fetchId == fetchId }
                    ?: return@tool McpToolResult.error(
                        "REQUEST_NOT_FOUND",
                        "暂停请求不存在（可能已放行或 fetchId 错误），用 network.paused_requests 查看当前暂停列表",
                    )
                val ok = com.webreverse.mcp.devtools.network.CdpNetworkMonitor.abortPaused(fetchId)
                if (ok) {
                    McpToolResult.json(
                        buildJsonObject {
                            put("aborted", JsonPrimitive(true))
                            put("url", JsonPrimitive(Redactor.redactUrl(paused.url)))
                        },
                    )
                } else {
                    McpToolResult.error("ABORT_FAILED", "Fetch.failRequest 调用失败（CDP 会话可能已断开）")
                }
            },
            // ============ v1.13.1 CDP 仿真控制（UA/请求头/缓存） ============
            f.tool(
                "network.set_user_agent",
                "UA 覆盖（CDP Emulation.setUserAgentOverride）：改 navigator.userAgent 与后续请求头，绕过 UA 风控/伪装设备环境（经 CDP 会话生效，共享同一条 CDP 会话的客户端同步可见；reload 后全量生效）",
                ToolCategory.NETWORK,
                PermissionScope.MODIFY_NETWORK, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "userAgent" to Schemas.strSchema("UA 字符串（必填，非空）"),
                    "acceptLanguage" to Schemas.strSchema("Accept-Language（可选）"),
                    "platform" to Schemas.strSchema("navigator.platform（可选，如 Win32/Linux armv8l）"),
                ),
            ) { args ->
                val ua = ToolArgs.str(args, "userAgent")
                if (ua.isBlank()) return@tool McpToolResult.error("INVALID_ARGS", "userAgent 必填（恢复默认请传页面原始 UA，page.info 可查）")
                if (!ensureCdpAttached(deps)) {
                    return@tool McpToolResult.error("CDP_ATTACH_FAILED", cdpAttachError())
                }
                val ok = com.webreverse.mcp.devtools.network.CdpNetworkMonitor.setUserAgentOverride(
                    ua,
                    ToolArgs.str(args, "acceptLanguage"),
                    ToolArgs.str(args, "platform"),
                )
                if (ok) {
                    McpToolResult.json(
                        buildJsonObject {
                            put("overridden", JsonPrimitive(true))
                            put("userAgent", JsonPrimitive(ua))
                            put("hint", JsonPrimitive("browser.reload 后新 UA 全量生效（请求头+navigator.userAgent）"))
                        },
                    )
                } else {
                    McpToolResult.error("UA_OVERRIDE_FAILED", "Emulation.setUserAgentOverride 调用失败（CDP 会话可能已断开）")
                }
            },
            f.tool(
                "network.set_extra_headers",
                "全局附加请求头（CDP Network.setExtraHTTPHeaders）：所有后续请求自动携带；签名接口测试常用（注入 trace/debug 头观察服务端差异）；headers 传空对象清除",
                ToolCategory.NETWORK,
                PermissionScope.MODIFY_NETWORK, RiskLevel.HIGH,
                inputSchema = Schemas.objectSchema(
                    "headers" to Schemas.strSchema("请求头 JSON 对象（如 {\"X-Debug\":\"1\"}；空对象={} 清除）"),
                ),
            ) { args ->
                if (!ensureCdpAttached(deps)) {
                    return@tool McpToolResult.error("CDP_ATTACH_FAILED", cdpAttachError())
                }
                val headers = (args["headers"] as? JsonObject)
                    ?.entries?.associate { (k, v) -> k to (v as? JsonPrimitive)?.contentOrNull.orEmpty() }
                    ?: return@tool McpToolResult.error("INVALID_ARGS", "headers 必须是 JSON 对象")
                val ok = com.webreverse.mcp.devtools.network.CdpNetworkMonitor.setExtraHeaders(headers)
                if (ok) {
                    McpToolResult.json(
                        buildJsonObject {
                            put("applied", JsonPrimitive(true))
                            put("headerCount", JsonPrimitive(headers.size))
                            put("headers", buildJsonObject { headers.forEach { (k, v) -> put(k, JsonPrimitive(v)) } })
                            put("hint", JsonPrimitive("仅对后续新请求生效；清除传 {}"))
                        },
                    )
                } else {
                    McpToolResult.error("SET_HEADERS_FAILED", "Network.setExtraHTTPHeaders 调用失败（CDP 会话可能已断开）")
                }
            },
            f.tool(
                "network.set_cache_disabled",
                "禁用/启用缓存（CDP Network.setCacheDisabled）：true=强制所有请求走网络（防缓存干扰分析，响应才是真服务端数据）",
                ToolCategory.NETWORK,
                PermissionScope.MODIFY_NETWORK, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema(
                    "disabled" to Schemas.boolSchema("true=禁用缓存 / false=恢复（必填）"),
                ),
            ) { args ->
                if (!ensureCdpAttached(deps)) {
                    return@tool McpToolResult.error("CDP_ATTACH_FAILED", cdpAttachError())
                }
                val disabled = ToolArgs.bool(args, "disabled", true)
                val ok = com.webreverse.mcp.devtools.network.CdpNetworkMonitor.setCacheDisabled(disabled)
                if (ok) {
                    McpToolResult.json(
                        buildJsonObject {
                            put("cacheDisabled", JsonPrimitive(disabled))
                            if (disabled) put("hint", JsonPrimitive("后续请求强制走网络（含 reload），分析签名接口时防缓存干扰"))
                        },
                    )
                } else {
                    McpToolResult.error("SET_CACHE_FAILED", "Network.setCacheDisabled 调用失败（CDP 会话可能已断开）")
                }
            },
            f.tool(
                "network.cdp_ws_frames",
                "列出 CDP 捕获的 WebSocket 帧（需 network.attach_cdp；文本帧原样、二进制帧 base64 前缀；实时签名/推送接口的逆向通道）",
                ToolCategory.NETWORK,
                PermissionScope.READ_NETWORK, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "urlFilter" to Schemas.strSchema("WS URL 子串过滤（可选）"),
                    "limit" to Schemas.intSchema("返回条数（默认 50，最新在前）"),
                    "direction" to Schemas.strSchema("方向过滤：send / receive（可选）"),
                ),
            ) { args ->
                if (!com.webreverse.mcp.devtools.network.CdpNetworkMonitor.isAttached) {
                    return@tool McpToolResult.error("CDP_NOT_ATTACHED", "请先调用 network.attach_cdp")
                }
                val urlFilter = ToolArgs.str(args, "urlFilter")
                val direction = ToolArgs.str(args, "direction")
                val limit = ToolArgs.int(args, "limit", 50)
                val frames = com.webreverse.mcp.devtools.network.CdpNetworkMonitor.listWsFrames(urlFilter, limit * 2)
                    .filter { direction.isBlank() || it.direction == direction }
                    .take(limit)
                McpToolResult.json(
                    buildJsonObject {
                        put("count", JsonPrimitive(frames.size))
                        put(
                            "frames",
                            JsonArray(
                                frames.map { fr ->
                                    buildJsonObject {
                                        put("url", JsonPrimitive(Redactor.redactUrl(fr.url)))
                                        put("direction", JsonPrimitive(fr.direction))
                                        put("opcode", JsonPrimitive(fr.opcode))
                                        put("timestamp", JsonPrimitive(fr.timestamp))
                                        put("payload", JsonPrimitive(fr.payload))
                                    }
                                },
                            ),
                        )
                        if (frames.isNotEmpty()) {
                            put("hint", JsonPrimitive("base64: 前缀为二进制帧（需解码）；持续观察可 event.wait network.websocket"))
                        }
                    },
                )
            },
        )
    }

    /** 确保网络监控的 CDP 会话已附加（未附加时自动附加到当前页面） */
    private suspend fun ensureCdpAttached(deps: ToolDependencies): Boolean {
        if (com.webreverse.mcp.devtools.network.CdpNetworkMonitor.isAttached) return true
        return com.webreverse.mcp.devtools.network.CdpNetworkMonitor.attach(deps.activeSession().engine)
    }

    private fun cdpAttachError(): String =
        "CDP 附加失败" + (com.webreverse.mcp.devtools.protocol.cdp.CdpTransport.lastError?.let { "：$it" } ?: "（DevTools socket 不可用，稍后重试）")
}
