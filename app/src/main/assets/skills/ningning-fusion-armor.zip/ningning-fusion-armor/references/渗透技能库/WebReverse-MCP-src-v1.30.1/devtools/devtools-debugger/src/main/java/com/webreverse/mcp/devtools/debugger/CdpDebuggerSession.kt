package com.webreverse.mcp.devtools.debugger

import com.webreverse.mcp.browser.engine.BrowserEngine
import com.webreverse.mcp.core.common.event.ConsoleEvent
import com.webreverse.mcp.core.common.event.DebuggerEvent
import com.webreverse.mcp.core.common.event.EventBus
import com.webreverse.mcp.core.common.model.CallFrame
import com.webreverse.mcp.core.common.model.Scope
import com.webreverse.mcp.core.common.model.ScopeType
import com.webreverse.mcp.devtools.protocol.cdp.CdpEvent
import com.webreverse.mcp.devtools.protocol.cdp.CdpScript
import com.webreverse.mcp.devtools.protocol.cdp.CdpSession
import com.webreverse.mcp.devtools.protocol.cdp.CdpHub
import com.webreverse.mcp.devtools.protocol.cdp.CdpTransport
import com.webreverse.mcp.devtools.protocol.cdp.RawWebSocket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/**
 * 真实 CDP 调试会话（基于 V8 Debugger domain）。
 *
 * 能力（均为 Chromium/V8 原生语义，非 evaluateJavascript 模拟）：
 * - Debugger.enable 后 scriptParsed 流（scriptId/url/sourceMapUrl 收集）
 * - setBreakpointByUrl 真源码断点（V8 执行 condition）
 * - Debugger.paused 真暂停态 callFrames（含 scopeChain objectId）
 * - stepInto/stepOver/stepOut/restartFrame/resume
 * - evaluateOnCallFrame（暂停态读取局部变量）
 * - Runtime.getProperties（解析 scope 变量）
 * - getScriptSource（取脚本源码，配合 SourceMap 工具链）
 *
 * 附注：CDP attach 后，页面内注入的 `debugger;` 语句同样触发 Debugger.paused，
 * 因此注入式断点（XHR/DOM/函数 Hook 中注入的 debugger 语句）自动升级为真断点。
 */
class CdpDebuggerSession private constructor(
    val tabId: String,
    private val session: CdpSession,
    private val scope: CoroutineScope,
    private val eventBus: EventBus,
    private val onStateChange: (String) -> Unit,
) {
    private val json = Json { ignoreUnknownKeys = true }

    private val _scripts = MutableStateFlow<List<CdpScript>>(emptyList())
    val scripts: StateFlow<List<CdpScript>> = _scripts.asStateFlow()

    /** 其他客户端（外部调试器等，经 CDP 复用枢纽接入）设置的断点（breakpointResolved 同步，MCP 侧可见） */
    class RemoteBreakpoint(
        val breakpointId: String,
        val scriptId: String,
        val line: Int,
        val url: String,
    )

    private val remoteBreakpoints = LinkedHashMap<String, RemoteBreakpoint>()

    /** 列出后端已解析的全部断点（含其他客户端设置、经本会话设置的） */
    fun listRemoteBreakpoints(): List<RemoteBreakpoint> = synchronized(remoteBreakpoints) { remoteBreakpoints.values.toList() }

    private fun scriptUrl(scriptId: String): String =
        _scripts.value.firstOrNull { it.scriptId == scriptId }?.url ?: scriptId

    /** CPU Profile 结果缓存（stopCpuProfile 后可取） */
    @Volatile
    var lastCpuProfile: JsonObject? = null
        private set

    /** 最近一次暂停的原始 callFrames（CDP 结构，含 objectId） */
    @Volatile
    var rawPauseParams: JsonObject? = null
        private set

    @Volatile
    var pauseReason: String = ""
        private set

    val isConnected: Boolean get() = session.isConnected

    fun close() = session.close()

    // ---------------- 连接 ----------------

    companion object {
        /**
         * 尝试与目标 WebView 页面建立 CDP 会话。
         * 失败（无 DevTools socket / 页面不匹配 / 握手失败）返回 null，调用方降级注入式。
         */
        suspend fun connect(
            engine: BrowserEngine,
            eventBus: EventBus,
            scope: CoroutineScope,
            onStateChange: (String) -> Unit,
        ): CdpDebuggerSession? {
            val pages = CdpTransport.listPages()
            if (pages == null) {
                if (CdpTransport.lastError == null) CdpTransport.lastError = "无法获取 DevTools 页面列表"
                return null
            }
            val targetUrl = engine.currentUrl()
            val pageCandidates = pages.filter { it.type == "page" }
            if (pageCandidates.isEmpty()) {
                CdpTransport.lastError = "DevTools 已连接但无可调试页面目标（页面可能尚未加载完成，稍后重试）"
                return null
            }
            val page = pageCandidates.firstOrNull { p ->
                !targetUrl.isNullOrBlank() && p.url.isNotBlank() &&
                    (p.url == targetUrl || normalizeUrl(p.url) == normalizeUrl(targetUrl))
            } ?: pageCandidates.firstOrNull { p ->
                !targetUrl.isNullOrBlank() && p.url.contains(hostOf(targetUrl)) && hostOf(targetUrl).length > 3
            } ?: pageCandidates.first() ?: return null

            // 优先经 CDP 复用枢纽（TcpWebSocket 回环接入）：
            // 与 CdpNetworkMonitor 等进程内 MCP 会话共享同一条后端 CDP 会话，
            // 事件流互通不互踢。枢纽不可用时回退直连 unix socket
            // （独立会话，语义不变）。
            val wsPath = CdpTransport.wsPathOf(page)
            val ws: RawWebSocket? = CdpHub.connectViaHub(wsPath)
                ?: CdpTransport.connectWebSocket(wsPath = wsPath)
            if (ws == null) {
                if (CdpTransport.lastError == null) CdpTransport.lastError = "WebSocket 升级失败"
                return null
            }
            val session = CdpSession(ws, scope)
            val cdp = CdpDebuggerSession(engine.tabId, session, scope, eventBus, onStateChange)
            session.start()
            // 域启用：失败即视为不可用
            val runtimeResult = session.callDetailed("Runtime.enable")
            if (runtimeResult.isFailure) {
                CdpTransport.lastError = "Runtime.enable 失败: ${runtimeResult.exceptionOrNull()?.message}"
                session.close()
                return null
            }
            val debuggerResult = session.callDetailed("Debugger.enable")
            if (debuggerResult.isFailure) {
                CdpTransport.lastError = "Debugger.enable 失败: ${debuggerResult.exceptionOrNull()?.message}"
                session.close()
                return null
            }
            cdp.collectEvents()
            CdpTransport.lastError = null
            return cdp
        }

        private fun normalizeUrl(url: String): String =
            url.substringBefore('#').trimEnd('/').lowercase()

        private fun hostOf(url: String): String =
            url.substringAfter("//").substringBefore('/')
    }

    private fun collectEvents() {
        scope.launch {
            session.events.collect { event -> onEvent(event) }
        }
    }

    private fun onEvent(event: CdpEvent) {
        when (event.method) {
            "Debugger.scriptParsed" -> handleScriptParsed(event.params)
            "Debugger.breakpointResolved" -> {
                // 断点解析回调：其他客户端设置的断点在此同步
                val bpId = event.params["breakpointId"]?.jsonPrimitive?.contentOrNull ?: return
                val loc = event.params["location"]?.jsonObject
                synchronized(remoteBreakpoints) {
                    val scriptId = loc?.get("scriptId")?.jsonPrimitive?.contentOrNull ?: ""
                    val line = ((loc?.get("lineNumber")?.jsonPrimitive?.intOrNull ?: 0) + 1)
                    remoteBreakpoints[bpId] = RemoteBreakpoint(bpId, scriptId, line, scriptUrl(scriptId))
                }
            }
            "Profiler.consoleProfileFinished" -> Unit // CPU profile 完成事件（stop 时同步取）
            // 未捕获异常（含 Promise rejection）：带完整调用栈发出，
            // AI 用 event.wait console.error 即可捕获——WebView onConsoleMessage 不带栈
            "Runtime.exceptionThrown" -> handleExceptionThrown(event.params)
            // consoleAPICalled 不转发：WebView onConsoleMessage 已覆盖同源消息，转发会双份
            "Debugger.paused" -> {
                rawPauseParams = event.params
                pauseReason = event.params["reason"]?.jsonPrimitive?.contentOrNull ?: ""
                onStateChange("PAUSED")
                val frames = parseCallFrames(event.params)
                eventBus.tryEmit(
                    DebuggerEvent.Paused(tabId, pauseReason, encodeFrames(frames)),
                )
                // 命中真断点时发出 BreakpointHit（hitBreakpoints 携带 CDP breakpointId）
                val hits = event.params["hitBreakpoints"]?.jsonArray
                val firstHit = hits?.firstOrNull()?.jsonPrimitive?.contentOrNull
                if (firstHit != null && frames.isNotEmpty()) {
                    eventBus.tryEmit(
                        DebuggerEvent.BreakpointHit(tabId, firstHit, frames[0].url, frames[0].lineNumber),
                    )
                }
            }
            "Debugger.resumed" -> {
                onStateChange("RESUMED")
                rawPauseParams = null
                pauseReason = ""
                eventBus.tryEmit(DebuggerEvent.Resumed(tabId))
            }
        }
    }

    private fun handleScriptParsed(params: JsonObject) {
        val scriptId = params["scriptId"]?.jsonPrimitive?.contentOrNull ?: return
        val url = params["url"]?.jsonPrimitive?.contentOrNull ?: ""
        val script = CdpScript(
            scriptId = scriptId,
            url = url,
            startLine = params["startLine"]?.jsonPrimitive?.intOrNull ?: 0,
            endLine = params["endLine"]?.jsonPrimitive?.intOrNull ?: 0,
            sourceMapUrl = params["sourceMapURL"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() },
            hasSourceURL = params["hasSourceURL"]?.jsonPrimitive?.contentOrNull == "true",
            length = params["length"]?.jsonPrimitive?.contentOrNull?.toLongOrNull() ?: 0,
        )
        _scripts.value = (_scripts.value.filterNot { it.scriptId == scriptId }) + script
        eventBus.tryEmit(DebuggerEvent.ScriptParsed(tabId, scriptId, url))
    }

    /** Runtime.exceptionThrown：解析 exceptionDetails（text/exception.description/stackTrace） */
    private fun handleExceptionThrown(params: JsonObject) {
        val details = params["exceptionDetails"]?.jsonObject ?: return
        val text = details["text"]?.jsonPrimitive?.contentOrNull ?: ""
        val exception = details["exception"]?.jsonObject
        val description = exception?.get("description")?.jsonPrimitive?.contentOrNull
            ?: exception?.get("value")?.jsonPrimitive?.contentOrNull
        // description 通常已含 JS .stack（message + at frames），优先取
        val url = details["url"]?.jsonPrimitive?.contentOrNull
            ?: scriptUrl(details["scriptId"]?.jsonPrimitive?.contentOrNull ?: "")
        val line = (details["lineNumber"]?.jsonPrimitive?.intOrNull ?: -1) + 1
        val cdpStack = details["stackTrace"]?.jsonObject?.get("callFrames")?.jsonArray
            ?.joinToString("\n") { f ->
                val fo = f as? JsonObject ?: return@joinToString "    at <unknown>"
                val fn = fo["functionName"]?.jsonPrimitive?.contentOrNull?.ifBlank { "<anonymous>" } ?: "<anonymous>"
                val fUrl = fo["url"]?.jsonPrimitive?.contentOrNull?.ifBlank {
                    scriptUrl(fo["scriptId"]?.jsonPrimitive?.contentOrNull ?: "")
                }
                val fLine = (fo["lineNumber"]?.jsonPrimitive?.intOrNull ?: 0) + 1
                "    at $fn ($fUrl:$fLine)"
            }.orEmpty()
        val message = buildString {
            append(description ?: text)
            if (url.isNotBlank()) append(" @ $url:$line")
        }.take(3000)
        val stack = cdpStack.ifBlank { description?.substringAfter('\n')?.take(4000) ?: "" }
        eventBus.tryEmit(ConsoleEvent.Exception(tabId, message, stack))
    }

    // ---------------- Debugger domain ----------------

    suspend fun pause(): Boolean = session.call("Debugger.pause") != null

    suspend fun resume(): Boolean = session.call("Debugger.resume") != null

    suspend fun stepInto(): Boolean = session.call("Debugger.stepInto") != null

    suspend fun stepOver(): Boolean = session.call("Debugger.stepOver") != null

    suspend fun stepOut(): Boolean = session.call("Debugger.stepOut") != null

    suspend fun restartFrame(): Boolean {
        val frameId = currentCallFrameIds().firstOrNull() ?: return false
        return session.call(
            "Debugger.restartFrame",
            buildJsonObject { put("callFrameId", frameId) },
        ) != null
    }

    suspend fun setPauseOnExceptions(state: String): Boolean =
        session.call(
            "Debugger.setPauseOnExceptions",
            buildJsonObject { put("state", state) },
        ) != null

    /**
     * 真源码行断点：V8 在指定位置暂停并执行 condition。
     * lineNumber/columnNumber 均为 1-based（DevTools 习惯），CDP 需要 0-based。
     *
     * columnNumber 对 minified 单行 JSVMP 是必需的：整文件几十万列时，
     * 纯行断点只会命中该行第一个可断点位（模块头部），打不进 dispatch 循环。
     *
     * @return CDP breakpointId（存入 Breakpoint.scriptId 供移除），失败返回 null
     */
    suspend fun setBreakpointByUrl(
        url: String,
        lineNumber: Int,
        columnNumber: Int? = null,
        condition: String? = null,
    ): String? {
        val params = buildJsonObject {
            put("lineNumber", (lineNumber - 1).coerceAtLeast(0))
            columnNumber?.takeIf { it > 0 }?.let { put("columnNumber", it - 1) }
            if (url.isBlank()) {
                put("urlRegex", ".*")
            } else {
                put("url", url)
            }
            condition?.takeIf { it.isNotBlank() }?.let { put("condition", it) }
        }
        val result = session.call("Debugger.setBreakpointByUrl", params) ?: return null
        val bpId = result["breakpointId"]?.jsonPrimitive?.contentOrNull
        // locations: 实际命中位置（urlRegex 可能命中多个脚本）
        val firstLoc = result["locations"]?.jsonArray?.firstOrNull()?.jsonObject
        if (bpId != null) {
            synchronized(remoteBreakpoints) {
                remoteBreakpoints[bpId] = RemoteBreakpoint(
                    bpId,
                    firstLoc?.get("scriptId")?.jsonPrimitive?.contentOrNull ?: "",
                    (firstLoc?.get("lineNumber")?.jsonPrimitive?.intOrNull ?: lineNumber - 1) + 1,
                    url,
                )
            }
        }
        return bpId
    }

    suspend fun removeBreakpoint(cdpBreakpointId: String): Boolean {
        val ok = session.call(
            "Debugger.removeBreakpoint",
            buildJsonObject { put("breakpointId", cdpBreakpointId) },
        ) != null
        if (ok) synchronized(remoteBreakpoints) { remoteBreakpoints.remove(cdpBreakpointId) }
        return ok
    }

    // ---------------- v1.13.0 CDP 增强 ----------------

    /** Debugger.searchInContent：脚本内容搜索（不拉全量源码，返回行号+命中行） */
    suspend fun searchInContent(scriptId: String, query: String, caseSensitive: Boolean = false, limit: Int = 50): JsonArray {
        val result = session.call(
            "Debugger.searchInContent",
            buildJsonObject {
                put("scriptId", scriptId)
                put("query", query)
                put("caseSensitive", caseSensitive)
            },
        ) ?: return JsonArray(emptyList())
        val matches = result["result"]?.jsonArray ?: return JsonArray(emptyList())
        val out = mutableListOf<JsonObject>()
        for (m in matches.take(limit)) {
            val mo = m as? JsonObject ?: continue
            out.add(
                buildJsonObject {
                    put("lineNumber", (mo["lineNumber"]?.jsonPrimitive?.intOrNull ?: 0) + 1)
                    put("lineContent", mo["lineContent"]?.jsonPrimitive?.contentOrNull ?: "")
                },
            )
        }
        return JsonArray(out)
    }

    /**
     * Debugger.getPossibleBreakpoints：查询可断点位置。
     * AI 打断点前先查（行号会被 V8 自动对齐到最近的 statement 起点），
     * 返回 actualLocation 供 set_breakpoint 精确命中。
     */
    suspend fun getPossibleBreakpoints(
        url: String,
        line: Int,
        column: Int? = null,
        restrictToFunction: Boolean = false,
        limit: Int = 20,
    ): JsonArray {
        val start = buildJsonObject {
            put("lineNumber", (line - 1).coerceAtLeast(0))
            column?.takeIf { it > 0 }?.let { put("columnNumber", it - 1) }
            put("scriptId", resolveScriptId(url) ?: "")
        }
        val params = buildJsonObject {
            put("start", start)
            put("restrictToFunction", restrictToFunction)
        }
        val result = session.call("Debugger.getPossibleBreakpoints", params)
            ?: return JsonArray(emptyList())
        val locations = result["locations"]?.jsonArray ?: return JsonArray(emptyList())
        val out = mutableListOf<JsonObject>()
        for (loc in locations.take(limit)) {
            val lo = loc as? JsonObject ?: continue
            val scriptId = lo["scriptId"]?.jsonPrimitive?.contentOrNull ?: ""
            out.add(
                buildJsonObject {
                    put("scriptId", scriptId)
                    put("url", scriptUrl(scriptId))
                    put("lineNumber", (lo["lineNumber"]?.jsonPrimitive?.intOrNull ?: 0) + 1)
                    put("columnNumber", (lo["columnNumber"]?.jsonPrimitive?.intOrNull ?: 0) + 1)
                },
            )
        }
        return JsonArray(out)
    }

    /** url -> scriptId（前缀/文件名匹配） */
    private fun resolveScriptId(url: String): String? =
        _scripts.value.firstOrNull { it.url == url }?.scriptId
            ?: _scripts.value.firstOrNull { it.url.endsWith(url) }?.scriptId
            ?: _scripts.value.firstOrNull { it.url.contains(url.substringAfterLast('/')) }?.scriptId

    /** Debugger.setVariableValue：暂停态修改局部变量（改完单步即可观察影响） */
    suspend fun setVariableValue(
        frameIndex: Int,
        scopeNumber: Int,
        variableName: String,
        newValue: String,
    ): Result<JsonObject> {
        val frameId = currentCallFrameIds().getOrNull(frameIndex)
            ?: return Result.failure(IllegalStateException("未处于暂停态或帧不存在"))
        // newValue 按 JS 表达式求值（数字/字符串/对象均可）
        return session.callDetailed(
            "Debugger.setVariableValue",
            buildJsonObject {
                put("callFrameId", frameId)
                put("scopeNumber", scopeNumber)
                put("variableName", variableName)
                put("newValue", buildJsonObject { put("expression", newValue) })
            },
        )
    }

    /**
     * Runtime.queryObjects：查询某构造器/原型现有的全部实例。
     * 逆向利器：找加密器实例（如 queryObjects("window.JSEncrypt") 后逐一 dump）。
     */
    suspend fun queryObjects(prototypeExpression: String, limit: Int = 20): JsonObject {
        // 先求值拿到 prototype 的 objectId
        val eval = session.call(
            "Runtime.evaluate",
            buildJsonObject {
                put("expression", "(${prototypeExpression}).prototype")
                put("returnByValue", false)
            },
        ) ?: return buildJsonObject { put("ok", false); put("error", "原型求值失败") }
        val objectId = eval["result"]?.jsonObject?.get("objectId")?.jsonPrimitive?.contentOrNull
            ?: return buildJsonObject {
                put("ok", false)
                put("error", "表达式无 prototype（非构造器或不存在）")
            }
        val query = session.call(
            "Runtime.queryObjects",
            buildJsonObject { put("prototypeObjectId", objectId) },
        ) ?: return buildJsonObject { put("ok", false); put("error", "queryObjects 调用失败") }
        val objectsId = query["objects"]?.jsonObject?.get("objectId")?.jsonPrimitive?.contentOrNull
            ?: return buildJsonObject { put("ok", false); put("error", "无实例") }
        // 展开实例数组（每个元素再展开一层给 className/description）
        val props = getObjectProperties(objectsId, limit)
        return buildJsonObject {
            put("ok", true)
            put("prototype", prototypeExpression)
            put("instances", props)
        }
    }

    /** Runtime.callFunctionOn：在指定对象上执行函数（配合 get_object_properties 的 objectId） */
    suspend fun callFunctionOn(
        objectId: String,
        functionDeclaration: String,
        arguments: List<String> = emptyList(),
        awaitPromise: Boolean = true,
    ): JsonObject {
        val args = JsonArray(
            arguments.map { arg ->
                buildJsonObject { put("expression", arg) }
            },
        )
        val result = session.call(
            "Runtime.callFunctionOn",
            buildJsonObject {
                put("objectId", objectId)
                put("functionDeclaration", functionDeclaration)
                put("arguments", args)
                put("returnByValue", true)
                put("awaitPromise", awaitPromise)
            },
        ) ?: return buildJsonObject { put("ok", false); put("error", "callFunctionOn 调用失败") }
        val remote = result["result"]?.jsonObject ?: JsonObject(emptyMap())
        val exception = result["exceptionDetails"]?.jsonObject
        return buildJsonObject {
            put("ok", exception == null)
            put("type", remote["type"]?.jsonPrimitive?.contentOrNull ?: "")
            put("value", describeRemoteValue(remote) ?: "")
            remote["objectId"]?.jsonPrimitive?.contentOrNull?.let { put("objectId", it) }
            exception?.let {
                put(
                    "exception",
                    buildJsonObject {
                        put("text", it["text"]?.jsonPrimitive?.contentOrNull ?: "")
                        it["exception"]?.jsonObject?.get("description")?.jsonPrimitive?.contentOrNull
                            ?.let { d -> put("description", d.take(2000)) }
                    },
                )
            }
        }
    }

    /** DOMDebugger.setEventListenerBreakpoint：CDP 原生事件断点（与 DevTools Event Listener Breakpoints 同语义） */
    suspend fun setEventListenerBreakpoint(eventName: String): Boolean =
        session.call(
            "DOMDebugger.setEventListenerBreakpoint",
            buildJsonObject { put("eventName", eventName) },
        ) != null

    suspend fun removeEventListenerBreakpoint(eventName: String): Boolean =
        session.call(
            "DOMDebugger.removeEventListenerBreakpoint",
            buildJsonObject { put("eventName", eventName) },
        ) != null

    /** DOMDebugger.setXHRBreakpoint：CDP 原生 XHR/fetch 断点（请求发起前暂停，DevTools 同款） */
    suspend fun setXHRBreakpoint(urlPattern: String): Boolean =
        session.call(
            "DOMDebugger.setXHRBreakpoint",
            buildJsonObject { put("url", urlPattern) },
        ) != null

    suspend fun removeXHRBreakpoint(urlPattern: String): Boolean =
        session.call(
            "DOMDebugger.removeXHRBreakpoint",
            buildJsonObject { put("url", urlPattern) },
        ) != null

    /**
     * Debugger.setInstrumentationBreakpoint：脚本级断点。
     * beforeScriptExecution = 任何新脚本执行前暂停（拦截加密初始化/JSVMP 加载）。
     */
    suspend fun setInstrumentationBreakpoint(instrumentation: String = "beforeScriptExecution"): Boolean =
        session.call(
            "Debugger.setInstrumentationBreakpoint",
            buildJsonObject { put("instrumentation", instrumentation) },
        ) != null

    suspend fun removeInstrumentationBreakpoint(instrumentation: String = "beforeScriptExecution"): Boolean =
        session.call(
            "Debugger.removeInstrumentationBreakpoint",
            buildJsonObject { put("instrumentation", instrumentation) },
        ) != null

    // ---------------- CPU Profiler（热点函数定位） ----------------

    private var cpuProfiling = false

    /** Profiler.enable + Profiler.start：录制 CPU profile（逆向时让页面跑加密流程，热点即加密函数） */
    suspend fun startCpuProfile(): Boolean {
        if (cpuProfiling) return true
        val enabled = session.call("Profiler.enable") != null
        if (!enabled) return false
        val ok = session.call("Profiler.setSamplingInterval", buildJsonObject { put("interval", 1000) }) != null
            && session.call("Profiler.start") != null
        cpuProfiling = ok
        return ok
    }

    /**
     * Profiler.stop：结束录制并解析 profile。
     * 返回按 selfTime 排序的热点函数（含 url:line，可直接 set_breakpoint 定位）。
     */
    suspend fun stopCpuProfile(topN: Int = 25): JsonObject {
        if (!cpuProfiling) {
            return buildJsonObject { put("ok", false); put("error", "未在录制（先 start）") }
        }
        val result = session.call("Profiler.stop")
        cpuProfiling = false
        session.call("Profiler.disable")
        if (result == null) return buildJsonObject { put("ok", false); put("error", "Profiler.stop 失败") }
        val profile = result["profile"]?.jsonObject
            ?: return buildJsonObject { put("ok", false); put("error", "无 profile 数据") }
        lastCpuProfile = profile
        return analyzeCpuProfile(profile, topN)
    }

    private fun analyzeCpuProfile(profile: JsonObject, topN: Int): JsonObject {
        val nodes = profile["nodes"]?.jsonArray ?: return buildJsonObject { put("ok", false); put("error", "无 nodes") }
        val samples = profile["samples"]?.jsonArray ?: JsonArray(emptyList())
        val timeDeltas = profile["timeDeltas"]?.jsonArray ?: JsonArray(emptyList())
        // 节点表
        data class Node(val id: Int, val fn: String, val url: String, val line: Int, val parent: Int?)
        val nodeById = HashMap<Int, Node>()
        val parentOf = HashMap<Int, Int>()
        for (n in nodes) {
            val no = n as? JsonObject ?: continue
            val id = no["id"]?.jsonPrimitive?.intOrNull ?: continue
            val cf = no["callFrame"]?.jsonObject ?: JsonObject(emptyMap())
            val url = cf["url"]?.jsonPrimitive?.contentOrNull ?: ""
            nodeById[id] = Node(
                id = id,
                fn = cf["functionName"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() } ?: "(anonymous)",
                url = url,
                line = ((cf["lineNumber"]?.jsonPrimitive?.intOrNull ?: -1) + 1),
                parent = null,
            )
            (no["children"]?.jsonArray ?: emptyList()).forEach { c ->
                (c as? JsonObject)?.get("id")?.jsonPrimitive?.intOrNull?.let { cid -> parentOf[cid] = id }
            }
        }
        // selfTime 累计
        val selfMicros = HashMap<Int, Long>()
        var prevSample: Int? = null
        for (i in samples.indices) {
            val s = samples[i].jsonPrimitive.intOrNull ?: continue
            val delta = timeDeltas.getOrNull(i)?.jsonPrimitive?.intOrNull ?: 0
            if (delta <= 0) continue
            val target = prevSample ?: s // delta 属于上一采样点（Chrome 语义）
            selfMicros[target] = (selfMicros[target] ?: 0L) + delta
            prevSample = s
        }
        val total = selfMicros.values.sum().coerceAtLeast(1L)
        val hot = selfMicros.entries
            .filter { (id, us) -> id != 0 && us > 0 && nodeById.containsKey(id) }
            .sortedByDescending { it.value }
            .take(topN)
            .mapNotNull { (id, us) ->
                val node = nodeById[id] ?: return@mapNotNull null
                buildJsonObject {
                    put("selfTimeMs", kotlin.math.round(us / 1000.0 * 10) / 10)
                    put("selfTimePct", kotlin.math.round(us * 1000.0 / total) / 10)
                    put("function", node.fn)
                    put("url", node.url)
                    put("line", node.line)
                }
            }
        return buildJsonObject {
            put("ok", true)
            put("totalSamples", samples.size)
            put("totalTimeMs", kotlin.math.round(total / 1000.0 * 10) / 10)
            put("hotFunctions", JsonArray(hot))
            put("hint", "selfTime 最高的函数即热点（加密/签名计算通常霸榜），url:line 可直接 debugger.set_breakpoint")
        }
    }

    /** 暂停态在调用帧上求值（可读局部变量/闭包变量）；非暂停态走 Runtime.evaluate */
    suspend fun evaluateOnCallFrame(expression: String, frameIndex: Int = 0): String? {
        val frameId = currentCallFrameIds().getOrNull(frameIndex)
            ?: return evaluateGlobal(expression)
        val result = session.call(
            "Debugger.evaluateOnCallFrame",
            buildJsonObject {
                put("callFrameId", frameId)
                put("expression", expression)
                put("returnByValue", true)
                put("silent", true)
            },
        ) ?: return null
        return describeRemoteValue(result["result"]?.jsonObject)
    }

    suspend fun evaluateGlobal(expression: String): String? {
        val result = session.call(
            "Runtime.evaluate",
            buildJsonObject {
                put("expression", expression)
                put("returnByValue", true)
            },
        ) ?: return null
        return describeRemoteValue(result["result"]?.jsonObject)
    }

    /**
     * Runtime.evaluate 增强版（DevTools Console 语义）：
     * - awaitPromise：支持 await fetch(...) / Promise 表达式
     * - exceptionDetails：异常文本 + 堆栈（而非静默 undefined）
     * - objectId：复杂对象返回引用，供 [getObjectProperties] 继续展开
     */
    suspend fun evaluateDetailed(expression: String, awaitPromise: Boolean = true): JsonObject {
        val result = session.call(
            "Runtime.evaluate",
            buildJsonObject {
                put("expression", expression)
                put("returnByValue", true)
                put("awaitPromise", awaitPromise)
                put("userGesture", true)
            },
        ) ?: return buildJsonObject {
            put("ok", false)
            put("error", "CDP 调用失败（会话未连接或超时）")
        }
        val remote = result["result"]?.jsonObject ?: JsonObject(emptyMap())
        val exception = result["exceptionDetails"]?.jsonObject
        return buildJsonObject {
            val failed = exception != null
            put("ok", !failed)
            put("type", remote["type"]?.jsonPrimitive?.contentOrNull ?: "")
            remote["subtype"]?.jsonPrimitive?.contentOrNull?.let { put("subtype", it) }
            remote["className"]?.jsonPrimitive?.contentOrNull?.let { put("className", it) }
            put("value", describeRemoteValue(remote) ?: "")
            remote["objectId"]?.jsonPrimitive?.contentOrNull?.let { put("objectId", it) }
            if (failed) {
                put(
                    "exception",
                    buildJsonObject {
                        put("text", exception["text"]?.jsonPrimitive?.contentOrNull ?: "")
                        exception["exception"]?.jsonObject?.get("description")?.jsonPrimitive?.contentOrNull
                            ?.let { put("description", it.take(4000)) }
                        exception["exception"]?.jsonObject?.get("value")?.jsonPrimitive?.contentOrNull
                            ?.let { put("value", it) }
                    },
                )
            }
        }
    }

    /** Runtime.getProperties：按 objectId 展开远程对象（Console 里点开对象的能力） */
    suspend fun getObjectProperties(objectId: String, maxEntries: Int = 100): JsonArray {
        val result = session.call(
            "Runtime.getProperties",
            buildJsonObject {
                put("objectId", objectId)
                put("ownProperties", true)
            },
        ) ?: return JsonArray(emptyList())
        val props = result["result"]?.jsonArray ?: return JsonArray(emptyList())
        val out = mutableListOf<JsonObject>()
        for (p in props.take(maxEntries)) {
            val po = p as? JsonObject ?: continue
            val valueObj = po["value"]?.jsonObject
            out.add(
                buildJsonObject {
                    put("name", po["name"]?.jsonPrimitive?.contentOrNull ?: "")
                    put("type", valueObj?.get("type")?.jsonPrimitive?.contentOrNull ?: "")
                    valueObj?.get("subtype")?.jsonPrimitive?.contentOrNull?.let { put("subtype", it) }
                    put("value", describeRemoteValue(valueObj) ?: "")
                    valueObj?.get("objectId")?.jsonPrimitive?.contentOrNull?.let { put("objectId", it) }
                },
            )
        }
        return JsonArray(out)
    }

    suspend fun getScriptSource(scriptId: String): String? {
        val result = session.call(
            "Debugger.getScriptSource",
            buildJsonObject { put("scriptId", scriptId) },
        ) ?: return null
        return result["scriptSource"]?.jsonPrimitive?.contentOrNull
    }

    /** 暂停态调用帧的 scopeChain 解析（Runtime.getProperties 读取真实变量） */
    suspend fun scopesOfFrame(frameIndex: Int = 0): List<Scope> {
        val params = rawPauseParams ?: return emptyList()
        val frames = params["callFrames"]?.jsonArray ?: return emptyList()
        val frame = frames.getOrNull(frameIndex)?.jsonObject ?: return emptyList()
        val scopeChain = frame["scopeChain"]?.jsonArray ?: return emptyList()
        return scopeChain.mapNotNull { sc ->
            val scopeObj = sc as? JsonObject ?: return@mapNotNull null
            val type = scopeObj["type"]?.jsonPrimitive?.contentOrNull ?: "global"
            val name = scopeObj["name"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
                ?: scopeObj["object"]?.jsonObject?.get("className")?.jsonPrimitive?.contentOrNull
                ?: type
            val objectId = scopeObj["object"]?.jsonObject?.get("objectId")?.jsonPrimitive?.contentOrNull
            val variables = objectId?.let { fetchProperties(it) } ?: emptyMap()
            Scope(
                type = runCatching { ScopeType.valueOf(type.uppercase()) }
                    .getOrDefault(ScopeType.GLOBAL),
                name = name,
                variables = variables,
            )
        }
    }

    /** 暂停态 frame[0] 的 LOCAL scope 变量（真实局部变量，非 window 采样） */
    suspend fun localsOfFrame(frameIndex: Int = 0): Map<String, String> {
        val scopes = scopesOfFrame(frameIndex)
        val local = scopes.filter { it.type == ScopeType.LOCAL || it.type == ScopeType.CLOSURE }
        if (local.isEmpty()) return emptyMap()
        // 多个 local/closure scope 依序合并（内层遮蔽外层）
        val merged = LinkedHashMap<String, String>()
        local.reversed().forEach { merged.putAll(it.variables) }
        return merged
    }

    // ---------------- 内部工具 ----------------

    private suspend fun fetchProperties(objectId: String): Map<String, String> {
        val result = session.call(
            "Runtime.getProperties",
            buildJsonObject {
                put("objectId", objectId)
                put("ownProperties", true)
            },
        ) ?: return emptyMap()
        val props = result["result"]?.jsonArray ?: return emptyMap()
        val out = LinkedHashMap<String, String>()
        for (p in props) {
            val po = p as? JsonObject ?: continue
            val name = po["name"]?.jsonPrimitive?.contentOrNull ?: continue
            val valueObj = po["value"]?.jsonObject
            val rendered = describeRemoteValue(valueObj) ?: ""
            out[name] = rendered.take(300)
            if (out.size >= 64) break // 变量数量上限，防大对象拖垮会话
        }
        return out
    }

    private fun describeRemoteValue(value: JsonObject?): String? {
        value ?: return null
        val type = value["type"]?.jsonPrimitive?.contentOrNull ?: return ""
        return when {
            value.containsKey("value") -> {
                val raw = value["value"]?.jsonPrimitive?.contentOrNull
                    ?: value["value"].toString()
                if (type == "string") "'$raw'" else raw
            }
            value.containsKey("description") -> value["description"]?.jsonPrimitive?.contentOrNull ?: type
            else -> type
        }
    }

    private fun currentCallFrameIds(): List<String> {
        val frames = rawPauseParams?.get("callFrames")?.jsonArray ?: return emptyList()
        return frames.mapNotNull { f ->
            (f as? JsonObject)?.get("callFrameId")?.jsonPrimitive?.contentOrNull
        }
    }

    /** CDP callFrames -> 领域模型（lineNumber/columnNumber 转 1-based） */
    internal fun parseCallFrames(params: JsonObject): List<CallFrame> {
        val frames = params["callFrames"]?.jsonArray ?: return emptyList()
        val scriptUrlById = _scripts.value.associate { it.scriptId to it.url }
        return frames.mapNotNull { f ->
            val fo = f as? JsonObject ?: return@mapNotNull null
            val location = fo["location"]?.jsonObject ?: JsonObject(emptyMap())
            val scriptId = location["scriptId"]?.jsonPrimitive?.contentOrNull ?: ""
            CallFrame(
                callFrameId = fo["callFrameId"]?.jsonPrimitive?.contentOrNull ?: "",
                functionName = fo["functionName"]?.jsonPrimitive?.contentOrNull ?: "(anonymous)",
                url = scriptUrlById[scriptId] ?: scriptId,
                lineNumber = (location["lineNumber"]?.jsonPrimitive?.intOrNull ?: 0) + 1,
                columnNumber = (location["columnNumber"]?.jsonPrimitive?.intOrNull ?: 0) + 1,
                scopeChain = (fo["scopeChain"]?.jsonArray ?: emptyList()).mapNotNull { sc ->
                    val sco = sc as? JsonObject ?: return@mapNotNull null
                    val type = sco["type"]?.jsonPrimitive?.contentOrNull ?: "global"
                    Scope(
                        type = runCatching { ScopeType.valueOf(type.uppercase()) }
                            .getOrDefault(ScopeType.GLOBAL),
                        name = sco["name"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() } ?: type,
                    )
                },
                thisObject = describeRemoteValue(fo["this"]?.jsonObject) ?: "",
            )
        }
    }

    private fun encodeFrames(frames: List<CallFrame>): String =
        runCatching { json.encodeToString(kotlinx.serialization.builtins.ListSerializer(CallFrame.serializer()), frames) }.getOrDefault("[]")
}
