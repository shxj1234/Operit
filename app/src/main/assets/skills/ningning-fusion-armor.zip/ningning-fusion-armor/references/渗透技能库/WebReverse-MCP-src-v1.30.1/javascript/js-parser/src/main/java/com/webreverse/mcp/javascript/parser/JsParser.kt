package com.webreverse.mcp.javascript.parser

import kotlinx.serialization.Serializable

/** 词法 Token */
@Serializable
data class JsToken(
    val type: TokenType,
    val value: String,
    val start: Int,
    val end: Int,
    val line: Int,
)

@Serializable
enum class TokenType {
    IDENTIFIER, KEYWORD, STRING, NUMBER, PUNCTUATOR, COMMENT, REGEX, TEMPLATE, WHITESPACE
}

/** 提取结果 */
@Serializable
data class JsExtraction(
    val strings: List<String> = emptyList(),
    val identifiers: List<String> = emptyList(),
    val urls: List<String> = emptyList(),
    val functionNames: List<String> = emptyList(),
    val callExpressions: List<CallExpressionInfo> = emptyList(),
    val memberExpressions: List<String> = emptyList(),
    val variables: List<String> = emptyList(),
    val constants: List<String> = emptyList(),
)

@Serializable
data class CallExpressionInfo(
    val callee: String,
    val arguments: List<String> = emptyList(),
    val line: Int = 0,
)

/** 源码位置 */
@Serializable
data class SourceLocation(
    val file: String = "",
    val line: Int = 0,
    val column: Int = 0,
)

/** 函数信息 */
@Serializable
data class FunctionInfo(
    val name: String,
    val params: List<String> = emptyList(),
    val body: String = "",
    val line: Int = 0,
    val isAnonymous: Boolean = false,
    val isArrow: Boolean = false,
)

/** 模式检测结果 */
@Serializable
data class PatternMatch(
    val pattern: String,
    val matches: List<PatternOccurrence> = emptyList(),
)

@Serializable
data class PatternOccurrence(
    val value: String,
    val line: Int = 0,
    val context: String = "",
)

/**
 * 轻量级 JavaScript 解析器 / 分析器。
 * 提供 Tokenize、字符串/标识符/URL/函数/调用表达式提取、模式检测、美化、混淆检测。
 */
class JsParser {

    private val keywords = setOf(
        "var", "let", "const", "function", "return", "if", "else", "for", "while",
        "do", "switch", "case", "break", "continue", "new", "this", "typeof", "instanceof",
        "in", "of", "try", "catch", "finally", "throw", "class", "extends", "super",
        "import", "export", "default", "async", "await", "yield", "delete", "void",
        "null", "true", "false", "undefined", "debugger", "static", "get", "set",
    )

    private val stringPattern = Regex("\"([^\"\\\\]|\\\\.)*\"|'([^'\\\\]|\\\\.)*'|`([^`\\\\]|\\\\.)*`")
    private val urlPattern = Regex("""(https?://[^\s"'`)\]]+|//[^\s"'`)\]]+|/api/[^\s"'`)\]]+|wss?://[^\s"'`)\]]+)""")
    private val identifierPattern = Regex("[A-Za-z_$][A-Za-z0-9_$]*")
    private val numberPattern = Regex("\\b(0[xX][0-9a-fA-F]+|0[bB][01]+|0[oO][0-7]+|\\d+\\.?\\d*([eE][+-]?\\d+)?)\\b")

    fun tokenize(source: String): List<JsToken> {
        val tokens = mutableListOf<JsToken>()
        var i = 0
        var line = 1
        val n = source.length
        while (i < n) {
            val c = source[i]
            when {
                c == '\n' -> { line++; i++ }
                c.isWhitespace() -> {
                    val start = i
                    while (i < n && source[i].isWhitespace()) i++
                    tokens.add(JsToken(TokenType.WHITESPACE, source.substring(start, i), start, i, line))
                }
                c == '/' && i + 1 < n && source[i + 1] == '/' -> {
                    val start = i
                    while (i < n && source[i] != '\n') i++
                    tokens.add(JsToken(TokenType.COMMENT, source.substring(start, i), start, i, line))
                }
                c == '/' && i + 1 < n && source[i + 1] == '*' -> {
                    val start = i
                    i += 2
                    while (i + 1 < n && !(source[i] == '*' && source[i + 1] == '/')) {
                        if (source[i] == '\n') line++
                        i++
                    }
                    i = minOf(i + 2, n)
                    tokens.add(JsToken(TokenType.COMMENT, source.substring(start, i), start, i, line))
                }
                c == '"' || c == '\'' || c == '`' -> {
                    val start = i
                    val quote = c
                    i++
                    while (i < n && source[i] != quote) {
                        if (source[i] == '\\') i++
                        if (source[i] == '\n') line++
                        i++
                    }
                    i = minOf(i + 1, n)
                    tokens.add(JsToken(TokenType.STRING, source.substring(start, i), start, i, line))
                }
                c.isDigit() -> {
                    val start = i
                    val m = numberPattern.find(source, i)
                    if (m != null && m.range.first == i) {
                        i = m.range.last + 1
                        tokens.add(JsToken(TokenType.NUMBER, m.value, start, i, line))
                    } else {
                        i++
                    }
                }
                c.isLetter() || c == '_' || c == '$' -> {
                    val start = i
                    while (i < n && (source[i].isLetterOrDigit() || source[i] == '_' || source[i] == '$')) i++
                    val word = source.substring(start, i)
                    tokens.add(
                        JsToken(
                            if (word in keywords) TokenType.KEYWORD else TokenType.IDENTIFIER,
                            word, start, i, line,
                        )
                    )
                }
                else -> {
                    val start = i
                    val two = if (i + 1 < n) source.substring(i, i + 2) else ""
                    if (two in setOf("=>", "==", "===", "!=", "!==", "<=", ">=", "&&", "||", "++", "--", "+=", "-=", "*=", "/=", "**", "??", "?.", "?:")) {
                        tokens.add(JsToken(TokenType.PUNCTUATOR, two, start, i + 2, line))
                        i += 2
                    } else {
                        tokens.add(JsToken(TokenType.PUNCTUATOR, c.toString(), start, i + 1, line))
                        i++
                    }
                }
            }
        }
        return tokens
    }

    /** 提取字符串字面量 */
    fun extractStrings(source: String): List<String> {
        return stringPattern.findAll(source).map { it.value.trim('"', '\'', '`') }.toList()
    }

    /** 提取 URL */
    fun extractUrls(source: String): List<String> {
        return urlPattern.findAll(source).map { it.value.trim('"', '\'', '`') }.distinct().toList()
    }

    /** 提取标识符 */
    fun extractIdentifiers(source: String): List<String> {
        return identifierPattern.findAll(source).map { it.value }.filterNot { it in keywords }.toList()
    }

    /** 提取函数定义 */
    fun extractFunctions(source: String): List<FunctionInfo> {
        val functions = mutableListOf<FunctionInfo>()
        // function name(params) { ... }
        val funcRegex = Regex("""\bfunction\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*\(([^)]*)\)\s*\{""")
        funcRegex.findAll(source).forEach { m ->
            val name = m.groupValues[1]
            val params = m.groupValues[2].split(",").map { it.trim() }.filter { it.isNotEmpty() }
            val line = source.substring(0, m.range.first).count { it == '\n' } + 1
            functions.add(FunctionInfo(name = name, params = params, line = line, body = m.value))
        }
        // const name = (params) => { ... }
        val arrowRegex = Regex("""(?:const|let|var)\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*=\s*(?:async\s*)?(?:\(([^)]*)\)|([A-Za-z_$][A-Za-z0-9_$]*))\s*=>\s*\{""")
        arrowRegex.findAll(source).forEach { m ->
            val name = m.groupValues[1]
            val params = (m.groupValues[2] + "," + m.groupValues[3]).split(",").map { it.trim() }.filter { it.isNotEmpty() }
            val line = source.substring(0, m.range.first).count { it == '\n' } + 1
            functions.add(FunctionInfo(name = name, params = params, line = line, body = m.value, isArrow = true))
        }
        // 匿名函数
        val anonRegex = Regex("""\bfunction\s*\(([^)]*)\)\s*\{""")
        anonRegex.findAll(source).forEach { m ->
            val params = m.groupValues[1].split(",").map { it.trim() }.filter { it.isNotEmpty() }
            val line = source.substring(0, m.range.first).count { it == '\n' } + 1
            functions.add(FunctionInfo(name = "(anonymous)", params = params, line = line, body = m.value, isAnonymous = true))
        }
        return functions
    }

    /** 提取调用表达式 */
    fun extractCallExpressions(source: String): List<CallExpressionInfo> {
        val calls = mutableListOf<CallExpressionInfo>()
        val regex = Regex("""([A-Za-z_$][A-Za-z0-9_$]*(?:\.[A-Za-z_$][A-Za-z0-9_$]*)*)\s*\(([^)]{0,200})\)""")
        regex.findAll(source).forEach { m ->
            val callee = m.groupValues[1]
            val args = splitArguments(m.groupValues[2])
            val line = source.substring(0, m.range.first).count { it == '\n' } + 1
            calls.add(CallExpressionInfo(callee = callee, arguments = args, line = line))
        }
        return calls
    }

    /** 提取成员表达式 */
    fun extractMemberExpressions(source: String): List<String> {
        val regex = Regex("""[A-Za-z_$][A-Za-z0-9_$]*\.[A-Za-z_$][A-Za-z0-9_$]*""")
        return regex.findAll(source).map { it.value }.distinct().toList()
    }

    /** 提取变量声明 */
    fun extractVariables(source: String): List<String> {
        val regex = Regex("""\b(?:var|let|const)\s+([A-Za-z_$][A-Za-z0-9_$]*(?:\s*,\s*[A-Za-z_$][A-Za-z0-9_$]*)*)""")
        return regex.findAll(source).flatMap { m ->
            m.groupValues[1].split(",").map { it.trim() }.filter { it.isNotEmpty() }
        }.toList()
    }

    /** 提取常量 */
    fun extractConstants(source: String): List<String> {
        val regex = Regex("""\bconst\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*=\s*([^;,\n]{0,100})""")
        return regex.findAll(source).map { "${it.groupValues[1]} = ${it.groupValues[2].trim()}" }.toList()
    }

    /** 完整提取 */
    fun extractAll(source: String): JsExtraction = JsExtraction(
        strings = extractStrings(source),
        identifiers = extractIdentifiers(source),
        urls = extractUrls(source),
        functionNames = extractFunctions(source).map { it.name },
        callExpressions = extractCallExpressions(source),
        memberExpressions = extractMemberExpressions(source),
        variables = extractVariables(source),
        constants = extractConstants(source),
    )

    /** 模式检测 */
    fun detectPatterns(source: String, patterns: List<String>): List<PatternMatch> {
        return patterns.map { pattern ->
            val regex = Regex(Regex.escape(pattern))
            val matches = regex.findAll(source).map { m ->
                val line = source.substring(0, m.range.first).count { it == '\n' } + 1
                val start = maxOf(0, m.range.first - 40)
                val end = minOf(source.length, m.range.last + 60)
                PatternOccurrence(
                    value = m.value,
                    line = line,
                    context = source.substring(start, end).replace("\n", " "),
                )
            }.toList()
            PatternMatch(pattern, matches)
        }
    }

    /** 检测危险/动态模式 */
    fun detectDangerousPatterns(source: String): List<PatternMatch> = detectPatterns(
        source,
        listOf(
            "eval(", "new Function(", "Function(", "setTimeout(\"", "setInterval(\"",
            "document.write(", "atob(", "btoa(", "decodeURIComponent(", "String.fromCharCode(",
            "WebAssembly.instantiate", "WebAssembly.compile", "new Proxy(", "Reflect.",
            "debugger", "console.log", "window.location", "document.cookie",
        ),
    )

    /** 美化（基础缩进格式化） */
    fun beautify(source: String): String {
        val sb = StringBuilder()
        var indent = 0
        var i = 0
        val n = source.length
        var inString: Char? = null
        var inTemplate = false
        while (i < n) {
            val c = source[i]
            if (inString != null) {
                sb.append(c)
                if (c == '\\' && i + 1 < n) { sb.append(source[i + 1]); i += 2; continue }
                if (c == inString) inString = null
                i++
                continue
            }
            when {
                c == '"' || c == '\'' -> { inString = c; sb.append(c); i++ }
                c == '`' -> { inTemplate = !inTemplate; sb.append(c); i++ }
                c == '{' -> {
                    sb.append(" {\n")
                    indent++
                    repeat(indent) { sb.append("  ") }
                    i++
                }
                c == '}' -> {
                    sb.append("\n")
                    indent = maxOf(0, indent - 1)
                    repeat(indent) { sb.append("  ") }
                    sb.append("}")
                    i++
                }
                c == ';' -> {
                    sb.append(";\n")
                    repeat(indent) { sb.append("  ") }
                    i++
                }
                c == '\n' -> { sb.append('\n'); repeat(indent) { sb.append("  ") }; i++ }
                c == ',' -> { sb.append(", "); i++ }
                else -> { sb.append(c); i++ }
            }
        }
        return sb.toString()
    }

    /** 压缩检测 */
    fun isMinified(source: String): Boolean {
        if (source.length < 200) return false
        val lines = source.lines().filter { it.isNotBlank() }
        if (lines.size <= 3) return true
        val avgLineLength = source.length / lines.size.toDouble()
        return avgLineLength > 200
    }

    private fun splitArguments(args: String): List<String> {
        if (args.isBlank()) return emptyList()
        val result = mutableListOf<String>()
        var depth = 0
        var current = StringBuilder()
        var inString: Char? = null
        for (c in args) {
            if (inString != null) {
                current.append(c)
                if (c == inString) inString = null
                continue
            }
            when (c) {
                '"', '\'', '`' -> { inString = c; current.append(c) }
                '(', '[', '{' -> { depth++; current.append(c) }
                ')', ']', '}' -> { depth--; current.append(c) }
                ',' -> if (depth == 0) { result.add(current.toString().trim()); current = StringBuilder() } else current.append(c)
                else -> current.append(c)
            }
        }
        if (current.isNotBlank()) result.add(current.toString().trim())
        return result
    }
}
