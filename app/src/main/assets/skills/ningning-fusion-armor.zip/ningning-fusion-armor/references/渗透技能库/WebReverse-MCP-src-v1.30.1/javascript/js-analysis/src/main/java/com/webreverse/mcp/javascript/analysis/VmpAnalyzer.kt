package com.webreverse.mcp.javascript.analysis

/**
 * JSVMP（JS 虚拟机保护）静态探测器 v2。
 *
 * v2 相比 v1 的关键改进（对应评审报告 2.2/2.4）：
 * 1. **输出 column**：minified 单行文件里行断点形同虚设，V8 需要列号才能
 *    打进 dispatch 循环。候选同时携带 line+column，直接喂给
 *    setBreakpointByUrl(columnNumber)。
 * 2. **opcode → case handler 切片**：自动提取 dispatch switch 内每个
 *    `case 0xNN:` 分支的代码体——"这个 opcode 干了什么"的语义信息，
 *    与 trace 的 opcode 频次关联后直接喂 LLM。
 * 3. minified 场景不再整窗统计：特征窗口收敛到 switch 体内部。
 */
class VmpDetector {

    data class VmpCandidate(
        val line: Int,          // 1-based，dispatch 循环起始行
        val column: Int,        // 1-based，match 起点（minified 单行时即 offset+1）
        val switchLine: Int,    // switch 语句位置（decision-tree 风格时为首分支位置）
        val switchColumn: Int,
        val score: Int,         // 置信度 0-100
        val reasons: List<String>,
        val suggestedOps: List<String>,      // 疑似 opcode/pc 变量名
        val caseCount: Int,
        val handlers: List<OpHandler>,       // opcode -> case 体切片
        // v1.9.0 P1-5：派发风格。switch = while+switch 经典派发；
        // if-tree = if/else-if 比较链派发（switch 检测盲区，混淆器二线形态）
        val dispatchStyle: String = "switch",
    )

    data class OpHandler(
        val key: String,     // "0x1a" / "26" / "default"
        val snippet: String, // case 体源码（截断）
        val line: Int,
        val column: Int,
    )

    /** 最多保留的 handler 数量（防爆内存） */
    private val maxHandlers = 120

    fun detect(source: String): List<VmpCandidate> {
        val switchCandidates = detectSwitchDispatch(source)
        val treeCandidates = detectDecisionTree(source)
        // v1.23.0：数组派发形态（handlers[bc[pc++]]()）——混淆器三线形态
        val arrayCandidates = detectArrayDispatch(source)
        // 去重：decision-tree 与 switch 位置重叠时保留高分者
        val merged = switchCandidates.toMutableList()
        treeCandidates.forEach { tree ->
            val overlap = merged.any { m ->
                kotlin.math.abs(m.switchLine - tree.switchLine) <= 2 &&
                    kotlin.math.abs(m.switchColumn - tree.switchColumn) < 200
            }
            if (!overlap) merged.add(tree)
        }
        arrayCandidates.forEach { arr ->
            val overlap = merged.any { m ->
                kotlin.math.abs(m.switchLine - arr.switchLine) <= 2 &&
                    kotlin.math.abs(m.switchColumn - arr.switchColumn) < 200
            }
            if (!overlap) merged.add(arr)
        }
        return merged.sortedByDescending { it.score }
    }

    /**
     * v1.23.0：数组派发（array-of-handlers）检测。
     *
     * 混淆器对抗 switch/if-tree 特征扫描的三线形态：把 handler 函数放进一个数组，
     * 派发循环用 opcode 直接索引调用：
     * ```
     * var _h = [function(){...}, function(){...}, ...];   // handler 数组
     * while (1) { _h[_bc[_pc++]](); }                      // 数组派发
     * ```
     * 识别要点：
     * - 数组字面量含大量函数引用（函数表达式或 handler 标识符）
     * - 存在 `arr[bc[pc++]]()` / `arr[opcode]()` 派发调用
     * - 外层无条件循环包裹
     */
    private fun detectArrayDispatch(source: String): List<VmpCandidate> {
        if (source.isBlank()) return emptyList()

        val lineStarts = buildList {
            add(0)
            var i = 0
            while (i < source.length) {
                if (source[i] == '\n' && i + 1 < source.length) add(i + 1)
                i++
            }
        }
        fun offsetToLineCol(offset: Int): Pair<Int, Int> {
            var lo = 0; var hi = lineStarts.size - 1
            while (lo < hi) {
                val mid = (lo + hi + 1) / 2
                if (lineStarts[mid] <= offset) lo = mid else hi = mid - 1
            }
            return (lo + 1) to (offset - lineStarts[lo] + 1)
        }

        val loopRe = Regex("""while\s*\(\s*(!!?\s*[]\d]|1\b|true\b)|for\s*\(\s*;;\s*\)""")
        // 数组声明：var NAME = [ ... ]
        val arrayDeclRe = Regex("""(?:var|let|const)\s+([A-Za-z_$][\w$]{0,20})\s*=\s*\[""")
        // 派发调用：NAME[bc[pc++]]() / NAME[opcode]() / NAME[bc[pc]]()
        val dispatchRe = Regex(
            """([A-Za-z_$][\w$]{0,20})\s*\[\s*([A-Za-z_$][\w$]{0,20})\s*\[\s*([A-Za-z_$][\w$]{0,20})\s*(?:\+\+)?\s*\]\s*\]\s*\(\s*\)""",
        )

        val out = mutableListOf<VmpCandidate>()
        val seenArrays = mutableSetOf<String>()

        for (decl in arrayDeclRe.findAll(source)) {
            val arrName = decl.groupValues[1]
            if (arrName in seenArrays) continue

            // 提取数组字面量内容（到匹配的 ]）
            val arrStart = decl.range.last + 1
            val arrEnd = findArrayEnd(source, arrStart)
            if (arrEnd <= arrStart) continue
            val arrBody = source.substring(arrStart, arrEnd)

            // 统计数组内函数引用（function 表达式 / 标识符）
            val fnExprCount = Regex("""function\s*\(""").findAll(arrBody).count()
            val idRefs = Regex("""[A-Za-z_$][\w$]{0,20}""").findAll(arrBody)
                .map { it.value }.distinct().count()
            val totalElements = Regex(""",""").findAll(arrBody).count() + 1
            if (fnExprCount < 4 && idRefs < 4) continue
            if (totalElements < 6) continue

            // 找该数组的派发调用点（数组名被 `arr[expr]()` 索引调用）
            val esc = Regex.escape(arrName)
            val callRe = Regex("""$esc\s*\[\s*[^\]]{1,60}\]\s*\(\s*\)""")
            val dispatchCalls = callRe.findAll(source).toList()
            if (dispatchCalls.isEmpty()) continue

            // 检查任一调用点在无条件循环内
            val firstCall = dispatchCalls.first().range.first
            val lookBack = source.substring((firstCall - 600).coerceAtLeast(0), firstCall)
            val loopMatch = loopRe.findAll(lookBack).lastOrNull()
            if (loopMatch == null) continue

            // 确认是字节码索引派发（下标含数组访问）或 opcode 变量
            val dispatchSample = dispatchCalls.first().value
            val isBytecodeIndexed = dispatchRe.containsMatchIn(dispatchSample) ||
                dispatchSample.contains('[') && dispatchSample.contains(']')

            // 提取 handler 切片（数组元素）
            val handlers = extractArrayHandlers(arrBody)

            var score = 25
            val reasons = mutableListOf<String>()
            reasons.add("array-of-handlers dispatch：handler 数组 $totalElements 元素（函数表达式×$fnExprCount）")
            if (totalElements >= 30) { score += 30; reasons.add("数组规模 $totalElements（典型 JSVMP 规模）") }
            else if (totalElements >= 12) { score += 20; reasons.add("数组规模 $totalElements") }
            else score += 12
            score += 20; reasons.add("无条件循环 ${loopMatch.value.trim()} 内数组索引调用 $arrName[expr]()")
            if (isBytecodeIndexed) { score += 10; reasons.add("下标为字节码数组访问（bc[pc++] 型）——强特征") }
            if (source.contains("Math.imul")) { score += 5; reasons.add("Math.imul（VM 常用乘法原语）") }
            if (source.contains("fromCharCode")) { score += 5; reasons.add("fromCharCode（字符串表解密）") }

            val (sLine, sCol) = offsetToLineCol(decl.range.first)
            val (lLine, lCol) = offsetToLineCol(lookBackStartOf(lookBack, loopMatch))
            seenArrays.add(arrName)
            out.add(
                VmpCandidate(
                    line = lLine,
                    column = lCol,
                    switchLine = sLine,
                    switchColumn = sCol,
                    score = score.coerceAtMost(100),
                    reasons = reasons,
                    suggestedOps = extractArrayVars(dispatchSample),
                    caseCount = totalElements,
                    handlers = handlers,
                    dispatchStyle = "array",
                ),
            )
            if (out.size >= 3) break
        }
        return out
    }

    /** 从 `var X = [` 起始 offset 找到匹配的数组结束 `]` */
    private fun findArrayEnd(source: String, start: Int): Int {
        var depth = 0
        var i = start
        var strip = '\u0000'
        while (i < source.length) {
            val c = source[i]
            if (strip != '\u0000') {
                if (c == '\\') i++
                else if (c == strip) strip = '\u0000'
            } else {
                when (c) {
                    '"', '\'' -> strip = c
                    '[' -> depth++
                    ']' -> {
                        depth--
                        if (depth == 0) return i
                    }
                }
            }
            i++
        }
        return -1
    }

    /** 提取 handler 数组元素为 OpHandler 切片 */
    private fun extractArrayHandlers(arrBody: String): List<OpHandler> {
        val handlers = mutableListOf<OpHandler>()
        val parts = splitTopLevelCommas(arrBody)
        parts.take(maxHandlers).forEachIndexed { idx, p ->
            val t = p.trim()
            if (t.isEmpty()) return@forEachIndexed
            handlers.add(
                OpHandler(
                    key = idx.toString(),
                    snippet = t.take(220),
                    line = 0,
                    column = 0,
                ),
            )
        }
        return handlers
    }

    /** 顶层逗号切分（尊重 ()[]{} 与字符串） */
    private fun splitTopLevelCommas(s: String): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        var depth = 0
        var i = 0
        var strip = '\u0000'
        while (i < s.length) {
            val c = s[i]
            if (strip != '\u0000') {
                sb.append(c)
                if (c == '\\') { i++; if (i < s.length) sb.append(s[i]) }
                else if (c == strip) strip = '\u0000'
            } else {
                when {
                    c == '"' || c == '\'' -> { strip = c; sb.append(c) }
                    c == '(' || c == '[' || c == '{' -> { depth++; sb.append(c) }
                    c == ')' || c == ']' || c == '}' -> { depth = maxOf(0, depth - 1); sb.append(c) }
                    c == ',' && depth == 0 -> { if (sb.isNotBlank()) out.add(sb.toString()); sb.clear() }
                    else -> sb.append(c)
                }
            }
            i++
        }
        if (sb.isNotBlank()) out.add(sb.toString())
        return out
    }

    /** 计算循环匹配在 lookBack 内的绝对 offset（用于行号） */
    private fun lookBackStartOf(lookBack: String, loopMatch: MatchResult): Int {
        return loopMatch.range.first
    }

    /**
     * v1.9.0 P1-5：decision-tree dispatcher 检测。
     *
     * 混淆器对抗 switch 特征扫描的二线形态：同一变量与一串常量做
     * 相等比较的 if/else-if 链（编译器视角就是手写跳转表）：
     * `if(bc[pc]===0x1){...}else if(bc[pc]===0x2){...}...`
     * 识别要点：
     * - 同一比较主体（如 bc[pc++]）重复出现 >= 6 次
     * - 比较常量各不相同且均为小整数/hex
     * - 外层有无条件循环包裹（与 switch 版同要求）
     */
    private fun detectDecisionTree(source: String): List<VmpCandidate> {
        if (source.isBlank()) return emptyList()

        // 行首 offset 表（复用 switch 版逻辑）
        val lineStarts = buildList {
            add(0)
            var i = 0
            while (i < source.length) {
                if (source[i] == '\n' && i + 1 < source.length) add(i + 1)
                i++
            }
        }
        fun offsetToLineCol(offset: Int): Pair<Int, Int> {
            var lo = 0; var hi = lineStarts.size - 1
            while (lo < hi) {
                val mid = (lo + hi + 1) / 2
                if (lineStarts[mid] <= offset) lo = mid else hi = mid - 1
            }
            return (lo + 1) to (offset - lineStarts[lo] + 1)
        }

        // if (X === K) / if (K === X) / if (X == K)，X 为任意标识符表达式（含取值）
        val condRe = Regex(
            """if\s*\(\s*([A-Za-z_$][\w$.\[\]]{1,30}?)\s*(?:={2,3}|!==?)\s*(0x[0-9a-fA-F]{1,6}|\d{1,6})\s*\)|if\s*\(\s*(0x[0-9a-fA-F]{1,6}|\d{1,6})\s*(?:={2,3}|!==?)\s*([A-Za-z_$][\w$.\[\]]{1,30}?)\s*\)""",
        )
        val loopRe = Regex("""while\s*\(\s*(!!?\s*[]\d]|1\b|true\b)|for\s*\(\s*;;\s*\)""")

        data class Branch(val const: String, val offset: Int, val nextOffset: Int)

        val out = mutableListOf<VmpCandidate>()
        val seenSubjects = mutableSetOf<String>()

        for (m in condRe.findAll(source)) {
            val subject = (m.groupValues[1].ifBlank { m.groupValues[4] }).trim()
            if (subject.isBlank() || subject in seenSubjects) continue
            seenSubjects.add(subject)

            // 收集同一主体的全部分支（同主体比较链）
            // 注意 `if (X === K)` 在 if 与 X 之间有括号，前缀后需容忍可选 `(`
            val esc = Regex.escape(subject)
            val sameSubjectRe = Regex(
                """(?:if|&&|\|\||\?|:|,|;|\{)\s*\(?\s*(?:$esc\s*(?:={2,3}|!==?)\s*(0x[0-9a-fA-F]{1,6}|\d{1,6})|(0x[0-9a-fA-F]{1,6}|\d{1,6})\s*(?:={2,3}|!==?)\s*$esc)""",
            )
            val branches = sameSubjectRe.findAll(source)
                .map { bm -> Branch(bm.groupValues[1].ifBlank { bm.groupValues[2] }, bm.range.first, bm.range.last + 1) }
                .toList()
            val distinctConsts = branches.map { it.const }.distinct()
            if (distinctConsts.size < 6) continue

            // 外层循环上下文（向前 600 字符）
            val firstOffset = branches.first().offset
            val lookBack = source.substring((firstOffset - 600).coerceAtLeast(0), firstOffset)
            val hasLoop = loopRe.containsMatchIn(lookBack)
            if (!hasLoop) continue

            // 分支体：当前比较结束 -> 下一分支开始
            val handlers = branches.withIndex().mapNotNull { (idx, b) ->
                val bodyEnd = branches.getOrNull(idx + 1)?.offset
                    ?: (b.nextOffset + 1200).coerceAtMost(source.length)
                val raw = source.substring(b.nextOffset, bodyEnd)
                    .replace(Regex("""^\s*(\?\s*)?"""), "")
                    .replace(Regex("""\s+"""), " ")
                    .trim()
                    .trimStart(':').trim()
                if (raw.isEmpty()) null
                else OpHandler(
                    key = b.const,
                    snippet = raw.take(220),
                    line = offsetToLineCol(b.offset).first,
                    column = offsetToLineCol(b.offset).second,
                )
            }

            var score = 25
            val reasons = mutableListOf<String>()
            reasons.add("decision-tree dispatch：if/else-if 比较链 ${distinctConsts.size} 分支（switch 检测盲区形态）")
            if (distinctConsts.size >= 20) { score += 30; reasons.add("分支规模 ${distinctConsts.size}（典型 JSVMP 规模）") }
            else if (distinctConsts.size >= 12) { score += 20; reasons.add("分支规模 ${distinctConsts.size}") }
            else score += 12
            score += 15; reasons.add("同一比较主体 $subject 重复出现")
            if (distinctConsts.count { it.startsWith("0x") } >= 4) {
                score += 10; reasons.add("hex 比较常量 ${distinctConsts.count { it.startsWith("0x") }} 个（dispatch 强特征）")
            }
            if (source.contains("Math.imul")) { score += 5; reasons.add("Math.imul（VM 常用乘法原语）") }

            // 建议变量：比较主体 + 派发区段内的数组访问（如 _0xbc[_0xpc++]）
            val region = source.substring(
                (firstOffset - 300).coerceAtLeast(0),
                (branches.last().offset + 300).coerceAtMost(source.length),
            )
            val suggested = (extractArrayVars(subject) + extractArrayVars(region)).distinct().take(6)

            val (sLine, sCol) = offsetToLineCol(firstOffset)
            out.add(
                VmpCandidate(
                    line = sLine,
                    column = sCol,
                    switchLine = sLine,
                    switchColumn = sCol,
                    score = score.coerceAtMost(100),
                    reasons = reasons,
                    suggestedOps = suggested,
                    caseCount = distinctConsts.size,
                    handlers = handlers,
                    dispatchStyle = "if-tree",
                ),
            )
            if (out.size >= 3) break
        }
        return out
    }

    /** 从判别式（如 `_0xbc[_0xpc++]`）提取数组/pc 变量名 */
    private fun extractArrayVars(subject: String): List<String> =
        Regex("""([A-Za-z_$][\w$]{0,12})\s*\[|"([A-Za-z_$][\w$]{0,12})"""")
            .findAll(subject)
            .map { it.groupValues[1].ifBlank { it.groupValues[2] } }
            .filter { it.isNotBlank() }
            .distinct()
            .take(6)
            .toList()

    private fun detectSwitchDispatch(source: String): List<VmpCandidate> {
        if (source.isBlank()) return emptyList()

        val loopRe = Regex("""while\s*\(\s*(!!?\s*[]\d]|1\b|true\b)|for\s*\(\s*;;\s*\)""")
        val switchRe = Regex("""\bswitch\s*\(""")
        val caseHeadRe = Regex("""\bcase\s+(0x[0-9a-fA-F]{1,6}|\d{1,6}|['"][\w+-]{1,4}['"])\s*:""")
        val hexLitRe = Regex("""0x[0-9a-fA-F]{1,4}\b""")
        val vmpVarRe = Regex(
            """\b(_?0x[0-9a-fA-F]+|(?:op|code|bytecode|opcode|pc|sp|ip|ctx|ins|instr)\w{0,4})\s*\[""",
        )

        // 行首 offset 表：行号 <-> offset 互转（一次构建，O(n)）
        val lineStarts = buildList {
            add(0)
            var i = 0
            while (i < source.length) {
                if (source[i] == '\n' && i + 1 < source.length) add(i + 1)
                i++
            }
        }
        fun offsetToLineCol(offset: Int): Pair<Int, Int> {
            // 二分找所在行
            var lo = 0; var hi = lineStarts.size - 1
            while (lo < hi) {
                val mid = (lo + hi + 1) / 2
                if (lineStarts[mid] <= offset) lo = mid else hi = mid - 1
            }
            return (lo + 1) to (offset - lineStarts[lo] + 1)
        }

        val candidates = mutableListOf<VmpCandidate>()
        // 每个 switch 只评估一次（以 switch offset 为 key 去重）
        val seenSwitches = mutableSetOf<Int>()

        for (switchMatch in switchRe.findAll(source)) {
            val switchOffset = switchMatch.range.first
            if (!seenSwitches.add(switchOffset)) continue

            // switch 判别式 + 循环上下文：向上回看 400 字符找无条件循环
            val lookBackStart = (switchOffset - 400).coerceAtLeast(0)
            val lookBack = source.substring(lookBackStart, switchOffset)
            val loopMatch = loopRe.findAll(lookBack).lastOrNull() ?: continue

            // case 体窗口：从 switch 判别式开始，到该 switch 后第 3 个 case 结束或 +20000 字符
            val switchRegion = source.substring(switchOffset, (switchOffset + 24_000).coerceAtMost(source.length))
            val caseMatches = caseHeadRe.findAll(switchRegion).take(400).toList()
            if (caseMatches.size < 4) continue

            // 提取 opcode -> handler 切片
            val handlers = mutableListOf<OpHandler>()
            for ((idx, cm) in caseMatches.withIndex()) {
                val bodyStart = cm.range.last + 1
                val bodyEnd = if (idx + 1 < caseMatches.size) {
                    caseMatches[idx + 1].range.first
                } else {
                    (bodyStart + 1200).coerceAtMost(switchRegion.length)
                }
                val raw = switchRegion.substring(bodyStart, bodyEnd)
                    .replace(Regex("""\s+"""), " ")
                    .trim()
                if (raw.isEmpty()) continue
                handlers.add(
                    OpHandler(
                        key = cm.groupValues[1],
                        snippet = raw.take(220),
                        line = offsetToLineCol(switchOffset + cm.range.first).first,
                        column = offsetToLineCol(switchOffset + cm.range.first).second,
                    ),
                )
                if (handlers.size >= maxHandlers) break
            }

            // 评分（特征收敛在 switch 体内部，不再全文件统计）
            val switchBody = switchRegion.substring(
                0,
                (caseMatches.lastOrNull()?.range?.last ?: 0).coerceAtMost(switchRegion.length),
            )
            var score = 0
            val reasons = mutableListOf<String>()
            when {
                caseMatches.size >= 30 -> { score += 40; reasons.add("switch-case ${caseMatches.size} 个（典型 JSVMP 规模）") }
                caseMatches.size >= 12 -> { score += 30; reasons.add("switch-case ${caseMatches.size} 个") }
                else -> { score += 15; reasons.add("switch-case ${caseMatches.size} 个") }
            }
            score += 25; reasons.add("无条件循环 ${loopMatch.value.trim()} 包裹 switch")
            val hexCount = hexLitRe.findAll(switchBody).count()
            if (hexCount >= 40) { score += 15; reasons.add("switch 内 0x 字面量密度高（$hexCount）") }
            else if (hexCount >= 10) { score += 8; reasons.add("switch 内 0x 字面量 $hexCount 个") }
            val arrayOps = vmpVarRe.findAll(switchBody).map { it.groupValues[1] }.distinct().take(6).toList()
            if (arrayOps.isNotEmpty()) { score += 10; reasons.add("疑似字节码数组访问: ${arrayOps.joinToString(",")}") }
            if (source.contains("Math.imul")) { score += 5; reasons.add("Math.imul（VM 常用乘法原语）") }
            if (source.contains("fromCharCode")) { score += 5; reasons.add("fromCharCode（字符串表解密）") }
            // hex case 键（0xNN:）是 JSVMP dispatch 的强特征
            val hexCaseKeys = caseMatches.count { it.groupValues[1].startsWith("0x") }
            if (hexCaseKeys >= 8) { score += 10; reasons.add("十六进制 case 键 $hexCaseKeys 个（dispatch 强特征）") }

            val (sLine, sCol) = offsetToLineCol(switchOffset)
            val (lLine, lCol) = offsetToLineCol(lookBackStart + loopMatch.range.first)
            candidates.add(
                VmpCandidate(
                    line = lLine,
                    column = lCol,
                    switchLine = sLine,
                    switchColumn = sCol,
                    score = score.coerceAtMost(100),
                    reasons = reasons,
                    suggestedOps = arrayOps,
                    caseCount = caseMatches.size,
                    handlers = handlers,
                ),
            )
            if (candidates.size >= 6) break
        }
        return candidates.sortedByDescending { it.score }
    }
}

/**
 * VM 指令 trace 折叠分析器 v2。
 *
 * v2 改进（对应评审报告缺陷 3/4）：
 * 1. analyze 接受真实 total（含被采样率跳过与环形覆盖的部分），百分比不失真
 * 2. n-gram 改滑窗（步长 1）——非重叠采样会漏相位偏移的循环块
 */
class VmpTraceAnalyzer {

    data class TraceReport(
        val totalSamples: Int,       // 真实触发总数（来自计数器，非 tail 长度）
        val sampledCount: Int,       // 实际进入分析的样本数
        val uniqueOpcodes: Int,
        val topOpcodes: List<OpcodeStat>,
        val loops: List<LoopBlock>,
        val sequenceSummary: String,
    )

    data class OpcodeStat(val opcode: String, val count: Int, val percent: Double)

    data class LoopBlock(val sequence: String, val repeats: Int)

    fun analyze(samples: List<String>, realTotal: Int = samples.size): TraceReport {
        if (samples.isEmpty()) {
            return TraceReport(realTotal, 0, 0, emptyList(), emptyList(), "")
        }
        val total = samples.size
        val freq = samples.groupingBy { it }.eachCount()
        val top = freq.entries
            .sortedByDescending { it.value }
            .take(30)
            .map { OpcodeStat(it.key, it.value, it.value * 100.0 / total) }

        // 循环块检测：滑窗 n-gram（步长 1），找高频重复块
        val loopCounts = HashMap<String, Int>()
        for (n in intArrayOf(2, 3, 4, 6, 8, 12)) {
            if (samples.size < n * 2) break
            var i = 0
            while (i + n <= samples.size) {
                val g = samples.subList(i, i + n).joinToString("→")
                loopCounts[g] = (loopCounts[g] ?: 0) + 1
                i += 1
            }
        }
        val loops = loopCounts.entries
            .filter { it.value >= 3 }
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key.length })
            .take(40)
            .map { (seq, count) ->
                val display = if (seq.length > 120) seq.take(117) + "..." else seq
                LoopBlock(display, count)
            }
            // 去除被更长块完全包含的短块（保留信息量最大的）
            .filterNot { short -> loopsContain(loopCounts, short) }
            .take(10)

        val summary = buildSequence(samples)
        return TraceReport(realTotal, total, freq.size, top, loops, summary)
    }

    /** 短块是否被某个出现次数相同、长度更长的块覆盖 */
    private fun loopsContain(all: Map<String, Int>, candidate: LoopBlock): Boolean =
        all.entries.any { (seq, count) ->
            count >= candidate.repeats && seq.length > candidate.sequence.length && seq.contains(candidate.sequence.removeSuffix("..."))
        }

    /** RLE 压缩序列：A A A B → A×3 B，长序列截断 */
    private fun buildSequence(samples: List<String>): String {
        val rle = mutableListOf<String>()
        var i = 0
        while (i < samples.size) {
            var j = i
            while (j < samples.size && samples[j] == samples[i]) j++
            val run = j - i
            rle.add(if (run > 1) "${samples[i]}×$run" else samples[i])
            i = j
        }
        val flat = rle.joinToString(" ")
        return when {
            flat.length <= 3000 -> flat
            else -> flat.take(1500) + " …[省略中段]… " + flat.takeLast(1200)
        }
    }

    /**
     * 对照组差分（评审报告 P2：实战最快的签名区段定位法）。
     * 对两次采样序列做 LCS 对齐，返回差异区段：
     * baseline 中缺失、testcase 中新增的 opcode 块即疑似签名路径。
     */
    data class TraceDiff(
        val baselineLen: Int,
        val testLen: Int,
        val addedBlocks: List<String>,
        val removedBlocks: List<String>,
        val commonRatio: Double,
    )

    fun diff(baseline: List<String>, test: List<String>): TraceDiff {
        if (baseline.isEmpty() || test.isEmpty()) {
            return TraceDiff(baseline.size, test.size, emptyList(), emptyList(), 0.0)
        }
        // LCS DP（限长防爆内存：>4000 时降级为频次差）
        if (baseline.size > 4000 || test.size > 4000) {
            val fb = baseline.groupingBy { it }.eachCount()
            val ft = test.groupingBy { it }.eachCount()
            val added = (ft.keys - fb.keys).map { "$it (+${ft[it]})" }
            val removed = (fb.keys - ft.keys).map { "$it (-${fb[it]})" }
            val inter = fb.keys.intersect(ft.keys).sumOf { minOf(fb[it] ?: 0, ft[it] ?: 0) }
            return TraceDiff(baseline.size, test.size, added, removed, inter * 2.0 / (baseline.size + test.size))
        }
        val n = baseline.size; val m = test.size
        val dp = Array(n + 1) { IntArray(m + 1) }
        for (i in n - 1 downTo 0) {
            for (j in m - 1 downTo 0) {
                dp[i][j] = if (baseline[i] == test[j]) dp[i + 1][j + 1] + 1
                else maxOf(dp[i + 1][j], dp[i][j + 1])
            }
        }
        // 回溯差异块
        val added = mutableListOf<String>()
        val removed = mutableListOf<String>()
        var i = 0; var j = 0
        while (i < n && j < m) {
            when {
                baseline[i] == test[j] -> { i++; j++ }
                dp[i + 1][j] >= dp[i][j + 1] -> { removed.add(baseline[i]); i++ }
                else -> { added.add(test[j]); j++ }
            }
        }
        while (i < n) { removed.add(baseline[i]); i++ }
        while (j < m) { added.add(test[j]); j++ }
        fun rle(list: List<String>): List<String> {
            if (list.isEmpty()) return emptyList()
            val out = mutableListOf<String>()
            var k = 0
            while (k < list.size) {
                var e = k
                while (e < list.size && list[e] == list[k]) e++
                out.add(if (e - k > 1) "${list[k]}×${e - k}" else list[k])
                k = e
            }
            return out
        }
        val common = dp[0][0]
        return TraceDiff(
            baselineLen = n,
            testLen = m,
            addedBlocks = rle(added).take(60),
            removedBlocks = rle(removed).take(60),
            commonRatio = common * 2.0 / (n + m),
        )
    }
}
