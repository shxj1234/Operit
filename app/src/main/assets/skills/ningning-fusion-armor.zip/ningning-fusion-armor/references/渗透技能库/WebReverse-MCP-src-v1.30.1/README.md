# MCP Browser / WebReverse MCP

> AI 驱动的网页调试与逆向分析工作台 —— 让 Claude、GPT、Gemini、Cursor 等 AI Agent 通过 MCP 连接 Android 浏览器

一个基于 Android 的专业浏览器、网页分析器、JavaScript 调试器、网络分析器和 MCP Server 平台。外部 AI Agent / LLM / IDE Agent 通过 MCP（Model Context Protocol）连接 Android 浏览器，对当前网页执行自动化浏览、DOM 分析、JavaScript 分析、网络分析、调试、断点、运行时观测、Hook、脚本注入等操作。

---

## 目录

- [核心特性](#核心特性)
- [技术栈](#技术栈)
- [架构设计](#架构设计)
- [模块结构](#模块结构)
- [MCP 协议](#mcp-协议)
- [快速开始](#快速开始)
- [AI Agent 连接指南](#ai-agent-连接指南)
- [安全模型](#安全模型)
- [License](#license)

---

## 核心特性

### 🌐 浏览器模式
- 地址栏、URL 搜索、多标签、标签组
- 页面前进 / 后退 / 刷新 / 停止 / 首页 / 全屏
- Cookie / LocalStorage / SessionStorage / IndexedDB / Cache 管理
- 历史记录、收藏夹、最近关闭
- 页面源码查看

### 🔬 AI 调试与网络分析（MCP Tools，CDP 直连，v1.15.0 重构）
v1.15.0 移除了内置 DevTools 前端（51MB 静态资源），调试与网络能力全部经 MCP Tools 暴露给 AI，由 **CDP 复用枢纽**承载：同一页面只保持一条后端 CDP 连接，进程内多个 MCP 会话（调试器/网络监视器/脚本工具）共享接入，断点、暂停与网络事件在会话间广播，互不踢线。CDP 不可用时自动降级为注入式实现（evaluateJavascript + Hook），能力零缺失。

| 能力域 | 覆盖（工具前缀） |
|--------|------|
| **DOM** | DOM Tree、属性、Computed Style、Box Model、Shadow DOM、XPath、CSS Selector（`dom.*`） |
| **Console** | evaluate JS（同步/异步）、inspect object、console.log/warn/error/table/dir 捕获（`console.*` / `js.evaluate`） |
| **Sources** | JS/CSS/HTML/JSON 源码、Pretty Print、SourceMap 还原、Global Search、Diff（`js.*` / `page.*`） |
| **Network** | HTTP/HTTPS/Fetch/XHR/WebSocket 采集、Headers/Cookies/Body/Timing、HAR 导出、Copy as cURL、请求重放/Mock/UA 伪装（`network.*`） |
| **Storage** | Cookies / LocalStorage / SessionStorage / IndexedDB / Cache Storage / Service Worker（`storage.*`） |
| **Debugger** | 断点（Line/Function/DOM/Event/XHR/Exception/Logpoint）、单步、调用栈、作用域、局部变量、CPU Profile（`debugger.*`） |
| **Performance** | Navigation Timing、First Paint / FCP、资源瀑布图、内存快照（`page.performance`） |
| **Security** | HTTPS/CSP 检查、框架检测、敏感数据脱敏审计（`re.*`） |
| **暂停放行** | 断点命中页面暂停时，浏览器内悬浮"调试器已暂停"提示条一键放行——无需任何调试前端即可恢复执行 |

### 🧩 JavaScript 分析系统
- **AST 解析**：基于 ESTree 规范的解析器（JsParser），支持函数/字符串/标识符/调用表达式搜索
- **混淆检测**（Obfuscation Score 0-100）：
  - 字符串数组编码、控制流平坦化、变量重命名、不可达代码
  - eval / new Function / setTimeout 动态代码检测
  - 反调试检测（debugger 语句、时间检测、console 检测、Function.toString 检测）
- **API Discovery**：自动从 HTML/JS/Network 提取 API Endpoint、Method、Headers、Caller
- **框架检测**：React / Vue / Angular / Svelte / Next.js / Nuxt / Vite / Webpack / jQuery / Axios / Redux 等
- **SourceMap 解析**：还原压缩代码到原始源码

### 🪝 Hook 引擎
- **网络 Hook**：URL/Host/Path/Method/Header/Body/Regex 匹配 + Log/Modify/Block/Redirect/Delay/Mock 动作
- **Runtime Hook**：`hookFunction()` / `hookMethod()` / `hookProperty()` / `hookFetch()` / `hookXHR()` / `hookWebSocket()` / `hookStorage()`
- **生命周期**：install / enable / disable / remove / reset / export / import
- **内置类型**：Function / Method / Property / Event / Fetch / XHR / WebSocket / Storage / Cookie / Console / Timer / Crypto / Canvas / Clipboard / History / Location

### 🖥️ MCP Server
- **传输方式**：HTTP（`POST /mcp`）+ WebSocket（`/mcp/ws`）+ SSE（`/mcp/sse`）
- **协议**：JSON-RPC 2.0，兼容 MCP 2025-03-26 规范
- **260+ Tools**：18 个分类（Browser / Tab / DOM / JavaScript / Debugger / Network / Hook / Storage / Page / Reverse Engineering / **Evidence / Graph / Pipeline** / Frame / Worker / Performance / Event / Workspace / **File System** / MCP / System）
- **12 Resources**：`browser://current-page`、`browser://dom`、`browser://network` 等
- **14 Prompts**：`analyze_page`、`analyze_login_flow`、`trace_function`、`evidence_workflow`（证据驱动工作流）等

### 🧠 证据图谱引擎（v1.14.0 核心架构）
- **Evidence Store**：订阅 EventBus 自动沉淀证据——网络请求 / Hook 命中 / 断点命中 / 控制台异常 / 页面加载全程留痕，无需手动采集
- **Reverse Graph**：端点 / 函数 / 脚本 / 令牌 / 加密操作 / 存储键自动建图，关系含 CALLS / REQUESTS / GENERATES / WRITES / SIGNS 等；高权重节点即逆向入口
- **时间窗关联**：加密 Hook 命中 ↔ ±3s 内的网络请求自动建立 SIGNS 边（"这个请求的签名是这个函数算的"）
- **Analysis Pipeline**：5 条端到端流水线编排现有 300+ 工具
  - `recon`：页面全景侦察（框架/端点/脚本/混淆/存储一次入图）
  - `api_trace`：接口调用链（请求 → initiator 栈函数 → 引用脚本）
  - `token_trace`：令牌溯源（存储扫描 → 引用脚本，值脱敏）
  - `crypto_link`：加密关联（Hook 命中 ↔ 请求时间窗配对，输出候选签名函数）
  - `snapshot`：运行时现场（暂停态调用栈+变量入证据库，帧链建图）
- **Runtime Snapshot**：断点命中现场（调用栈/局部变量/命中断点）一键沉淀为可查询证据

### 🔐 权限安全模型
- 22 个权限作用域（READ_PAGE / EXECUTE_JS / READ_NETWORK / MODIFY_NETWORK / INSTALL_HOOK / READ_FILE / WRITE_FILE 等）
- 4 档授权范围：一次 / 当前网站 / 当前 Tab / 永久
- 敏感数据默认脱敏：`[REDACTED_COOKIE]` / `[REDACTED_TOKEN]` / `[REDACTED_SECRET]`
- 认证：API Token + 配对码 + QR 配对 + IP Allowlist + 仅局域网模式

---

## 技术栈

| 类别 | 技术 |
|------|------|
| 语言 | Kotlin 2.0+ |
| UI | Jetpack Compose + Material 3（含 Expressive） |
| 架构 | Clean Architecture + Multi-module |
| 异步 | Coroutines + Flow / StateFlow / SharedFlow |
| 导航 | Navigation Compose（自研响应式路由） |
| 持久化 | Room + DataStore |
| 网络 | OkHttp + Kotlin Serialization |
| 浏览器内核 | Android WebView / androidx.webkit |
| 调试协议 | Chromium DevTools Protocol（unix socket 直连 + 进程内复用枢纽，注入式降级） |
| MCP Server | Ktor（Netty）+ WebSocket + SSE |
| DI | 手动 DI 容器（AppContainer） |
| 日志 | Timber + 自研分类日志（9 类） |
| 最低支持 | Android 8.0（API 26） |

---

## 架构设计

```
┌─────────────────────────────────────────────────────────────┐
│                        AI Agent                             │
│         Claude / GPT / Gemini / Cursor / IDE Agent          │
└──────────────────────┬──────────────────────────────────────┘
                       │  Wi-Fi / LAN  (JSON-RPC 2.0)
                       ▼
┌─────────────────────────────────────────────────────────────┐
│                    MCP Server (Ktor)                        │
│  ┌─────────────┐ ┌──────────────┐ ┌────────────────────┐   │
│  │ HTTP /mcp   │ │ WebSocket    │ │ SSE /mcp/sse      │   │
│  └─────────────┘ └──────────────┘ └────────────────────┘   │
│  ┌──────────────────────────────────────────────────────┐  │
│  │           ToolRegistry (100+ Tools)                  │  │
│  │  Browser│Tab│DOM│JS│Debugger│Network│Hook│Storage   │  │
│  │  Page│ReverseEngineering│Frame│Worker│Performance   │  │
│  │  Event│Workspace│MCP│System                        │  │
│  └──────────────────────────────────────────────────────┘  │
│  ┌──────────────┐  ┌───────────────┐  ┌────────────────┐  │
│  │ 12 Resources │  │ 13 Prompts    │  │ Auth + Session │  │
│  └──────────────┘  └───────────────┘  └────────────────┘  │
└──────────────────────┬──────────────────────────────────────┘
                       │  ToolDependencies（依赖注入）
                       ▼
┌─────────────────────────────────────────────────────────────┐
│                      领域服务层                              │
│  ┌────────────┐ ┌─────────────┐ ┌────────────────────────┐ │
│  │ Browser    │ │ DevTools    │ │ JavaScript 分析        │ │
│  │ Service    │ │ Inspector   │ │ Parser/Obfuscation/API │ │
│  │ (多 Tab)   │ │ Console     │ │ Discovery/Framework    │ │
│  │            │ │ Debugger    │ │ Workspace              │ │
│  │ Hook       │ │ Network     │ │ Manager                │ │
│  │ Engine     │ │ Storage     │ │ (项目管理)             │ │
│  └────────────┘ │ Performance │ └────────────────────────┘ │
│                 └─────────────┘                             │
└──────────────────────┬──────────────────────────────────────┘
                       │  EventBus（解耦通信）
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              BrowserEngine (WebView 封装)                    │
│   JsBridge (console/network/hook 注入) + NetworkBridge      │
└─────────────────────────────────────────────────────────────┘
```

### 数据流向（Clean Architecture）

```
MCP Tool → UseCase → BrowserService → BrowserEngine → WebView
    ↓                                    ↓
EventBus ←—————— Hook/Console/Network 事件 ——————→ JsBridge
    ↓
Room 持久化 + UI StateFlow 更新
```

---

## 模块结构

```
WebReverseMCP/
├── app/                        # 应用入口 + Compose UI + DI 容器
├── core/
│   ├── core-common/            # 事件总线、领域模型、权限模型、工具类
│   ├── core-logging/           # 统一日志（9 分类 + 环形缓冲）
│   ├── core-security/          # TokenManager + PermissionManager
│   ├── core-network/           # OkHttp 封装、HAR 导出
│   ├── core-database/          # Room（17 张表）+ Repository
│   ├── core-ui/                # 共享 Compose 组件
│   └── core-mcp/               # MCP 协议核心（McpTool/ToolRegistry/JSON-RPC）
├── browser/
│   ├── browser-engine/         # WebView 封装、JsBridge、NetworkBridge
│   ├── browser-tabs/           # TabManager（多标签 + 标签组）
│   ├── browser-history/        # 历史记录
│   ├── browser-bookmarks/      # 收藏夹
│   └── browser-ui/             # 浏览器 UI 组件
├── devtools/
│   ├── devtools-protocol/      # CDP 传输与协议（LocalSocket/TcpWebSocket/CdpHub）
│   ├── devtools-dom/           # DOM Inspector
│   ├── devtools-console/       # Console Manager
│   ├── devtools-debugger/      # Debugger Manager（断点/调用栈）
│   ├── devtools-network/       # Network Inspector（HAR）
│   ├── devtools-storage/       # Storage Inspector
│   └── devtools-performance/   # Performance Analyzer
├── javascript/
│   ├── js-parser/              # JsParser（ESTree AST）
│   ├── js-analysis/            # 混淆检测/API 发现/框架检测/SourceMap/Diff
│   └── js-runtime/             # JsRuntimeHook（运行时 Hook）
├── hook/
│   ├── hook-engine/            # HookEngine（规则生命周期）
│   └── hook-rules/             # HookRuleBuilder
├── mcp/
│   ├── mcp-server/             # Ktor Server + McpServerManager + QR
│   ├── mcp-tools/              # 250+ Tools（19 分类，含 File System 文件系统）
│   ├── mcp-resources/          # 12 个 browser:// 资源
│   └── mcp-prompts/            # 13 个内置 Prompt
├── workspace/
│   ├── workspace-core/         # WorkspaceManager
│   └── workspace-ui/           # 工作区 UI
```

---

## MCP 协议

### Tool 调用示例

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "js.evaluate",
    "arguments": {
      "expression": "document.title"
    }
  }
}
```

### 核心 Tool 分类（250+）

| 分类 | 示例 |
|------|------|
| Browser | `browser.open` `browser.reload` `browser.screenshot` `browser.current_url` |
| Tab | `tab.list` `tab.create` `tab.close` `tab.group` |
| DOM | `dom.query` `dom.get_html` `dom.click` `dom.get_xpath` `dom.set_attribute` |
| JavaScript | `js.evaluate` `js.parse_ast` `js.beautify` `js.detect_obfuscation` `js.extract_strings` |
| Debugger | `debugger.set_breakpoint` `debugger.pause` `debugger.call_stack` `debugger.locals` |
| Network | `network.list` `network.export_har` `network.copy_curl` `network.replay` `network.mock` |
| Hook | `hook.create` `hook.fetch` `hook.websocket` `hook.function` `hook.export` |
| Storage | `storage.cookies` `storage.local` `storage.indexeddb` `storage.clear` |
| Page | `page.inspect` `page.framework_detect` `page.api_list` `page.performance` |
| Reverse Engineering | `re.find_api` `re.find_token` `re.detect_obfuscator` `re.trace_function` `re.generate_report` |
| **File System** | `file.read` `file.write` `file.search` `file.list` `file.open` `file.share` `file.hash` `file.zip` `file.unzip` |

#### File System 工具（19 个）

逆向工作流闭环的关键补充：AI 下载 JS/HAR 后可**离线阅读与检索**（`file.read` / `file.search`），
逆向成果可直接**落盘为脚本文件**（`file.write` / `file.append`），并可通过 `file.open` / `file.share`
把产物交给设备上的其他应用或用户。

| 工具 | 说明 |
|------|------|
| `file.workdir` / `file.set_workdir` | 查看 / 切换工作目录 |
| `file.read` | 读取文件（文本按行分页，二进制 base64） |
| `file.write` / `file.append` | 创建覆盖 / 追加写入（文本或 base64） |
| `file.list` / `file.tree` | 列目录（通配符过滤、递归）/ 树形结构 |
| `file.stat` / `file.exists` | 元信息 / 存在性检查 |
| `file.mkdir` / `file.delete` | 建目录 / 删文件（删除为高风险） |
| `file.copy` / `file.move` | 复制（递归）/ 移动重命名 |
| `file.search` | 本地 grep：文本/正则、目录递归、超长压缩行自动截取匹配点上下文窗口 |
| `file.open` / `file.share` | 唤起系统应用打开 / 系统分享面板 |
| `file.hash` | MD5 / SHA-1 / SHA-256 流式哈希 |
| `file.zip` / `file.unzip` | 打包 / 解压（内置 Zip Slip 防护） |

路径规则：相对路径基于工作目录（`/storage/emulated/0/Download/WebReverseMCP`），
绝对路径直接使用；`/proc` `/sys` `/dev` `/system` 等系统目录拒绝访问。
`browser.download` 额外支持 `data:` URI 直接落盘。

### Resources

```
browser://current-page    browser://dom          browser://console
browser://network         browser://cookies      browser://local-storage
browser://sources         browser://tabs         browser://debugger
browser://performance     browser://hooks        browser://workspace
```

### Prompts

```
analyze_page · analyze_javascript · analyze_network · analyze_login_flow
analyze_api · analyze_obfuscation · find_function · trace_function
trace_request · debug_javascript · inspect_dom · analyze_storage
generate_reverse_engineering_report
```

---

## 快速开始

### 环境要求

- Android Studio Ladybug+
- JDK 17
- Android SDK 35

### 构建

```bash
# 克隆项目
git clone <repo-url>
cd WebReverseMCP

# 构建 Debug APK
./gradlew :app:assembleDebug

# 构建 Release APK
./gradlew :app:assembleRelease
```

### 运行

1. 在 Android 设备上安装 APK
2. 确保 Android 与 AI Agent 处于同一局域网
3. 打开 App → MCP Server 页面 → 启动 Server
4. 获取 Token 和配对码
5. 在 AI Agent 侧配置 MCP 连接

---

## AI Agent 连接指南

### Claude Desktop / Cursor 配置

```json
{
  "mcpServers": {
    "webreverse": {
      "url": "http://<Android-IP>:8787/mcp",
      "headers": {
        "Authorization": "Bearer <Your-Token>"
      }
    }
  }
}
```

### WebSocket 连接

```json
{
  "mcpServers": {
    "webreverse": {
      "url": "ws://<Android-IP>:8787/mcp/ws",
      "headers": {
        "X-MCP-Token": "<Your-Token>"
      }
    }
  }
}
```

### 使用示例

连接成功后，AI Agent 可以执行：

```
用户: 分析这个页面的登录请求
AI:   1. browser.current_url        → 获取当前 URL
      2. dom.query("form")          → 找到登录表单
      3. js.find_function("login")  → 查找登录函数
      4. network.list()             → 监控网络请求
      5. hook.fetch()               → Hook fetch 调用
      6. debugger.set_breakpoint()  → 设置函数断点
      7. 用户执行登录
      8. network.search("login")    → 捕获登录请求
      9. 生成 Login Flow 分析报告
```

---

## 安全模型

### 默认保护策略

1. **敏感数据默认脱敏**：密码、Cookie、Authorization、Token、API Key、银行卡信息
   自动替换为 `[REDACTED_*]`，禁止自动发送给外部 AI
2. **仅局域网**：默认只监听局域网接口，禁止公网访问
3. **强制认证**：随机生成 Token + 配对码，支持 QR 配对
4. **高风险操作需授权**：读取 Cookie / 修改请求 / 执行 JS / 安装 Hook 必须用户确认

### 权限作用域

| 作用域 | 风险等级 | 说明 |
|--------|---------|------|
| READ_PAGE | 低 | 读取页面基本信息 |
| EXECUTE_JS | 高 | 在页面执行任意 JavaScript |
| READ_DOM | 低 | 读取 DOM 树 |
| READ_NETWORK | 中 | 读取网络请求 |
| MODIFY_NETWORK | 高 | 修改/阻断网络请求 |
| READ_COOKIES | 高 | 读取 Cookie（敏感） |
| INSTALL_HOOK | 高 | 安装运行时 Hook |
| READ_FILE | 低 | 读取工作目录及可访问文件 |
| WRITE_FILE | 中/高 | 写入文件（删除为高） |

### 合规声明

本工具仅供学习研究与自己拥有/明确授权的网页调试使用。设计上不提供窃取第三方账号、Cookie、Token、支付数据等功能。

---

## License

MIT License

Copyright (c) 2026 WebReverse MCP
