package com.webreverse.mcp.devtools.protocol.cdp

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * CDP 会话：JSON-RPC 请求/响应配对 + 事件流。
 *
 * 与 [com.webreverse.mcp.devtools.protocol.DevToolsProtocol] 中的静态数据模型不同，
 * 本类提供真正的 Transport/Session 能力：消息 id 管理、pending 响应分发、
 * domain 事件 Flow（Debugger.paused / scriptParsed / Runtime.* 等）。
 */
class CdpSession(
    private val ws: RawWebSocket,
    private val scope: CoroutineScope,
) {
    private val json = Json { ignoreUnknownKeys = true }

    private val pending = ConcurrentHashMap<Int, CompletableDeferred<JsonObject>>()
    private val idCounter = AtomicInteger(0)
    private val active = AtomicBoolean(false)

    private val _events = MutableSharedFlow<CdpEvent>(
        extraBufferCapacity = 1024,
        onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST,
    )
    val events: SharedFlow<CdpEvent> = _events.asSharedFlow()

    val isConnected: Boolean get() = active.get() && !ws.isClosed()

    /** 启动接收循环（阻塞读 socket，跑在 IO 协程） */
    fun start() {
        if (!active.compareAndSet(false, true)) return
        scope.launch(Dispatchers.IO) {
            while (active.get() && !ws.isClosed()) {
                val message = runCatching { ws.readTextMessage() }.getOrNull() ?: break
                if (message.isNotEmpty()) dispatch(message)
            }
            close()
        }
    }

    private fun dispatch(message: String) {
        val obj = runCatching { json.parseToJsonElement(message).jsonObject }.getOrNull() ?: return
        val id = obj["id"]?.jsonPrimitive?.intOrNull
        if (id != null) {
            pending.remove(id)?.complete(obj)
        } else {
            val method = obj["method"]?.jsonPrimitive?.contentOrNull ?: return
            val params = obj["params"] as? JsonObject ?: JsonObject(emptyMap())
            _events.tryEmit(CdpEvent(method, params))
        }
    }

    /** 发送 CDP 命令并等待完整响应（含 error 字段时由调用方判断） */
    suspend fun send(method: String, params: JsonObject = JsonObject(emptyMap())): JsonObject {
        if (!isConnected) throw CdpException("CDP 会话未连接")
        val id = idCounter.incrementAndGet()
        val deferred = CompletableDeferred<JsonObject>()
        pending[id] = deferred
        val payload = buildJsonObject {
            put("id", id)
            put("method", method)
            put("params", params)
        }
        if (!ws.sendText(payload.toString())) {
            pending.remove(id)
            throw CdpException("CDP 发送失败: $method")
        }
        val response = withTimeoutOrNull(REQUEST_TIMEOUT_MS) { deferred.await() }
        if (response == null) {
            pending.remove(id)
            throw CdpException("CDP 响应超时: $method")
        }
        return response
    }

    /** 便捷调用：成功返回 result 对象，失败（协议 error / 连接异常）返回 null */
    suspend fun call(method: String, params: JsonObject = JsonObject(emptyMap())): JsonObject? {
        val response = runCatching { send(method, params) }.getOrNull() ?: return null
        return if (response.containsKey("error")) null else response["result"]?.jsonObject
    }

    /** 同 [call]，但把协议 error message 带回（供诊断） */
    suspend fun callDetailed(method: String, params: JsonObject = JsonObject(emptyMap())): Result<JsonObject> {
        val response = runCatching { send(method, params) }.getOrElse {
            return Result.failure(it)
        }
        val error = response["error"] as? JsonObject
        if (error != null) {
            val message = error["message"]?.jsonPrimitive?.contentOrNull ?: "unknown CDP error"
            return Result.failure(CdpException("$method: $message"))
        }
        return Result.success(response["result"]?.jsonObject ?: JsonObject(emptyMap()))
    }

    fun close() {
        active.set(false)
        ws.close()
        pending.values.forEach { it.completeExceptionally(CdpException("CDP 会话已关闭")) }
        pending.clear()
    }

    companion object {
        private const val REQUEST_TIMEOUT_MS = 20_000L
    }
}
