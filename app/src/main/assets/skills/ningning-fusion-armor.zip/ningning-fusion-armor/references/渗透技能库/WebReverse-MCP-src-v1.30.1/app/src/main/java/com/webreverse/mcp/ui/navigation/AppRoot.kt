package com.webreverse.mcp.ui.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import com.webreverse.mcp.di.AppContainer
import com.webreverse.mcp.ui.bookmarks.BookmarksScreen
import com.webreverse.mcp.ui.browser.BrowserScreen
import com.webreverse.mcp.ui.breakpoints.BreakpointsScreen
import com.webreverse.mcp.ui.history.HistoryScreen
import com.webreverse.mcp.ui.home.HomeScreen
import com.webreverse.mcp.ui.hooks.HooksScreen
import com.webreverse.mcp.ui.logs.LogsScreen
import com.webreverse.mcp.ui.mcp.McpServerScreen
import com.webreverse.mcp.ui.permissions.PermissionsScreen
import com.webreverse.mcp.ui.scripts.ScriptsScreen
import com.webreverse.mcp.ui.settings.SettingsScreen
import com.webreverse.mcp.ui.terminal.TerminalScreen
import com.webreverse.mcp.ui.theme.ThemeMode
import com.webreverse.mcp.ui.workspace.WorkspaceScreen

/**
 * 应用根布局：响应式导航 + 主/子页面路由。
 * - 手机（窄屏）：底部 NavigationBar
 * - 平板/大屏/横屏（宽屏）：左侧 NavigationRail，与内容用 Row 并排
 * - 子页面：顶部 TopAppBar 带返回箭头
 */
@Composable
fun WebReverseAppRoot(
    container: AppContainer,
    themeMode: ThemeMode,
    onThemeModeChange: (ThemeMode) -> Unit,
    dynamicColor: Boolean,
    onDynamicColorChange: (Boolean) -> Unit,
) {
    var currentDestination by rememberSaveable { mutableStateOf(Destination.Home.route) }
    var currentSubRoute by rememberSaveable { mutableStateOf<String?>(null) }

    val isExpanded = isExpandedWidth()

    /** 导航：主页面路由切换主导航，子页面路由进入子页面 */
    val navigateTo: (String) -> Unit = { route ->
        if (Routes.mainRoutes.contains(route)) {
            currentDestination = route
            currentSubRoute = null
        } else {
            currentSubRoute = route
        }
    }

    /** 从子页面返回 */
    val goBack: () -> Unit = { currentSubRoute = null }

    val showBottomBar = !isExpanded && currentSubRoute == null
    val showRail = isExpanded && currentSubRoute == null
    val isSubPage = currentSubRoute != null

    // 子页面时拦截系统返回键，返回主页而非退出 App
    BackHandler(enabled = isSubPage) {
        currentSubRoute = null
    }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                AppBottomBar(
                    current = currentDestination,
                    onSelect = { currentDestination = it },
                )
            }
        },
    ) { padding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            // 左侧 NavigationRail（仅宽屏主页面显示）
            if (showRail) {
                NavigationRail {
                    Destination.all.forEach { dest ->
                        NavigationRailItem(
                            selected = currentDestination == dest.route,
                            onClick = { currentDestination = dest.route },
                            icon = {
                                Icon(
                                    imageVector = dest.icon,
                                    contentDescription = dest.label,
                                )
                            },
                            label = { Text(dest.label) },
                        )
                    }
                }
            }

            // 右侧内容区域
            Box(modifier = Modifier.weight(1f)) {
                if (isSubPage) {
                    // 子页面自带 TopAppBar 和返回按钮，直接渲染
                    SubScreen(
                        container = container,
                        route = currentSubRoute!!,
                        onBack = goBack,
                    )
                } else {
                    AppContent(
                        container = container,
                        destination = currentDestination,
                        themeMode = themeMode,
                        onThemeModeChange = onThemeModeChange,
                        dynamicColor = dynamicColor,
                        onDynamicColorChange = onDynamicColorChange,
                        onNavigate = navigateTo,
                    )
                }
            }
        }
    }
}

@Composable
private fun AppBottomBar(
    current: String,
    onSelect: (String) -> Unit,
) {
    NavigationBar {
        Destination.all.forEach { dest ->
            NavigationBarItem(
                selected = current == dest.route,
                onClick = { onSelect(dest.route) },
                icon = {
                    Icon(
                        imageVector = dest.icon,
                        contentDescription = dest.label,
                    )
                },
                label = { Text(dest.label) },
            )
        }
    }
}

@Composable
private fun AppContent(
    container: AppContainer,
    destination: String,
    themeMode: ThemeMode,
    onThemeModeChange: (ThemeMode) -> Unit,
    dynamicColor: Boolean,
    onDynamicColorChange: (Boolean) -> Unit,
    onNavigate: (String) -> Unit,
) {
    when (destination) {
        Destination.Home.route -> HomeScreen(container, onNavigate)
        Destination.Browser.route -> BrowserScreen(container)
        Destination.Mcp.route -> McpServerScreen(container)
        Destination.Workspace.route -> WorkspaceScreen(container)
        Destination.Settings.route -> SettingsScreen(
            container = container,
            themeMode = themeMode,
            onThemeModeChange = onThemeModeChange,
            dynamicColor = dynamicColor,
            onDynamicColorChange = onDynamicColorChange,
        )
    }
}

/** 子页面路由分发 */
@Composable
private fun SubScreen(
    container: AppContainer,
    route: String,
    onBack: () -> Unit,
) {
    when (route) {
        Routes.HISTORY -> HistoryScreen(container, onBack)
        Routes.BOOKMARKS -> BookmarksScreen(container, onBack)
        Routes.SCRIPTS -> ScriptsScreen(container, onBack)
        Routes.HOOKS -> HooksScreen(container, onBack)
        Routes.BREAKPOINTS -> BreakpointsScreen(container, onBack)
        Routes.PERMISSIONS -> PermissionsScreen(container, onBack)
        Routes.LOGS -> LogsScreen(container, onBack)
        Routes.TERMINAL -> TerminalScreen(container)
        else -> {
            // 未知路由：显示提示而非立即返回
            Column(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("页面不存在", style = MaterialTheme.typography.titleLarge)
                Text(
                    "路由：$route",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp),
                )
                Button(
                    onClick = onBack,
                    modifier = Modifier.padding(top = 16.dp),
                ) {
                    Text("返回")
                }
            }
        }
    }
}

/** 判断是否为宽屏（平板/大屏/横屏） */
@Composable
private fun isExpandedWidth(): Boolean {
    val configuration = LocalConfiguration.current
    return configuration.screenWidthDp >= 600
}
