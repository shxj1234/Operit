package com.webreverse.mcp.javascript.runtime

import com.webreverse.mcp.browser.engine.BrowserEngine
import com.webreverse.mcp.browser.engine.util.JsScripts

/**
 * 动态调试追踪器 v1（v1.7.0 新增）。
 *
 * 与 HookEngine（规则生命周期）互补的运行时观测层，面向「动态调试」场景：
 * 1. **函数级 Trace**：包装目标函数，记录每次调用的参数/返回值/耗时/
 *    调用栈，形成时间线——比断点更轻量，适合分析签名/加密函数的输入输出。
 * 2. **对象属性监控**：Proxy 包装目标对象，读写属性即记录（配合堆栈），
 *    逆向「数据被谁改了」。
 * 3. **方法耗时剖析**：批量包装对象的所有方法，统计调用次数/总耗时/平均，
 *    定位性能热点函数（常是加密循环）。
 * 4. **trace 收集**：环形缓冲 + 一次性取回（JSON），支持过滤与清空。
 *
 * 所有观测默认脱敏（Authorization/Cookie/密码类字段替换为 [REDACTED]）。
 */
class DynamicTracer {

    companion object {
        private const val CAP = 2000
    }

    /** 初始化 trace 载体（幂等） */
    suspend fun install(engine: BrowserEngine) {
        engine.evaluateJavascript(
            """
            (function(){
              if (globalThis.__WRMCP_TRACE__) return;
              var T = {
                cap: $CAP,
                entries: [],
                n: 0,
                redact: function(s){
                  try {
                    var v = String(s);
                    if (v.length > 400) v = v.substring(0, 400) + '…';
                    return v.replace(/("(?:authorization|cookie|token|secret|password|passwd|pwd)"\s*[:=]\s*)"[^"]*"/gi, '$1"[REDACTED]"');
                  } catch(e){ return String(s); }
                },
                push: function(e){
                  e.seq = ++T.n;
                  if (T.entries.length >= T.cap) T.entries.shift();
                  T.entries.push(e);
                },
                stack: function(){
                  try {
                    return (new Error().stack || '').split('\n').slice(2, 8).map(function(l){ return l.trim(); }).join(' <- ');
                  } catch(e){ return ''; }
                }
              };
              globalThis.__WRMCP_TRACE__ = T;
            })()
            """.trimIndent(),
        )
    }

    // ---------------- 1. 函数级 Trace ----------------

    /**
     * 追踪目标函数（支持点路径，如 "window.sign" / "JSON.stringify"）。
     * [captureArgs]/[captureReturn] 控制参数与返回值记录（默认 true）。
     * 返回包装是否成功。
     */
    suspend fun traceFunction(
        engine: BrowserEngine,
        target: String,
        captureArgs: Boolean = true,
        captureReturn: Boolean = true,
        captureStack: Boolean = false,
    ): Boolean {
        install(engine)
        val script = """
            (function(){
              try {
                var T = globalThis.__WRMCP_TRACE__;
                var path = ${JsScripts.quote(target)}.split('.');
                var obj = globalThis;
                for (var i = 0; i < path.length - 1; i++) {
                  if (obj[path[i]] === undefined || obj[path[i]] === null) return false;
                  obj = obj[path[i]];
                }
                var name = path[path.length - 1];
                var orig = obj[name];
                if (typeof orig !== 'function') return false;
                if (orig.__wrmcp_traced__) return true;
                var wrapped = function(){
                  var t0 = performance.now();
                  var args = ${if (captureArgs) "Array.prototype.slice.call(arguments).map(function(a){ try { return T.redact(typeof a === 'object' && a !== null ? JSON.stringify(a) : a); } catch(e){ return String(a); } })" else "null"};
                  var ret, err = null;
                  try { ret = orig.apply(this, arguments); }
                  catch(e){ err = String(e && e.message || e); throw e; }
                  finally {
                    var e_ = {
                      type: 'call', target: ${JsScripts.quote(target)},
                      args: args,
                      ret: ${if (captureReturn) "function(){ try { return (typeof ret === 'object' && ret !== null) ? T.redact(JSON.stringify(ret)) : T.redact(ret); } catch(e2){ return String(ret); } }()" else "null"},
                      error: err,
                      ms: +(performance.now() - t0).toFixed(3),
                      ts: Date.now()
                    };
                    if (${if (captureStack) "true" else "false"}) e_.stack = T.stack();
                    T.push(e_);
                  }
                  return ret;
                };
                wrapped.__wrmcp_traced__ = true;
                wrapped.__wrmcp_orig__ = orig;
                try { Object.defineProperty(wrapped, 'length', { value: orig.length }); } catch(e){}
                obj[name] = wrapped;
                return true;
              } catch(e){ return false; }
            })()
        """.trimIndent()
        return engine.evaluateJavascript(script) == "true"
    }

    /** 取消追踪（恢复原函数） */
    suspend fun untraceFunction(engine: BrowserEngine, target: String): Boolean {
        val script = """
            (function(){
              try {
                var path = ${JsScripts.quote(target)}.split('.');
                var obj = globalThis;
                for (var i = 0; i < path.length - 1; i++) {
                  if (obj[path[i]] === undefined) return false;
                  obj = obj[path[i]];
                }
                var name = path[path.length - 1];
                var cur = obj[name];
                if (cur && cur.__wrmcp_traced__) { obj[name] = cur.__wrmcp_orig__; return true; }
                return false;
              } catch(e){ return false; }
            })()
        """.trimIndent()
        return engine.evaluateJavascript(script) == "true"
    }

    // ---------------- 2. 对象属性监控 ----------------

    /**
     * 用 Proxy 监控对象属性读写（如 "window.user" / "localStorage"）。
     * getter/setter 触发时记录值 + 堆栈。
     */
    suspend fun monitorObject(engine: BrowserEngine, target: String): Boolean {
        install(engine)
        val script = """
            (function(){
              try {
                var T = globalThis.__WRMCP_TRACE__;
                var path = ${JsScripts.quote(target)}.split('.');
                var holder = globalThis;
                for (var i = 0; i < path.length - 1; i++) {
                  if (holder[path[i]] === undefined || holder[path[i]] === null) return false;
                  holder = holder[path[i]];
                }
                var name = path[path.length - 1];
                var orig = holder[name];
                if (orig === null || typeof orig !== 'object') return false;
                if (orig.__wrmcp_monitored__) return true;
                var proxy = new Proxy(orig, {
                  get: function(o, prop){
                    var v = o[prop];
                    if (typeof prop === 'string' && prop !== '__wrmcp_monitored__' && prop !== 'then') {
                      T.push({ type:'prop.get', target: ${JsScripts.quote(target)}, prop: String(prop),
                               value: (typeof v === 'object' && v !== null) ? '[object]' : T.redact(v),
                               stack: T.stack(), ts: Date.now() });
                    }
                    return v;
                  },
                  set: function(o, prop, val){
                    if (typeof prop === 'string') {
                      T.push({ type:'prop.set', target: ${JsScripts.quote(target)}, prop: String(prop),
                               value: (typeof val === 'object' && val !== null) ? '[object]' : T.redact(val),
                               stack: T.stack(), ts: Date.now() });
                    }
                    o[prop] = val;
                    return true;
                  }
                });
                try { Object.defineProperty(proxy, '__wrmcp_monitored__', { value: true }); } catch(e){}
                holder[name] = proxy;
                return true;
              } catch(e){ return false; }
            })()
        """.trimIndent()
        return engine.evaluateJavascript(script) == "true"
    }

    /** 取消对象监控（Proxy 会被整体替换回原对象，尽力恢复） */
    suspend fun unmonitorObject(engine: BrowserEngine, target: String): Boolean {
        return untraceFunction(engine, target)
    }

    // ---------------- 3. 方法耗时剖析 ----------------

    /**
     * 批量剖析对象的所有方法（统计调用数/总耗时/平均耗时）。
     * 适合 "window.crypto" / 某命名空间对象。
     */
    suspend fun profileObject(engine: BrowserEngine, target: String, maxMethods: Int = 30): Int {
        install(engine)
        val script = """
            (function(){
              try {
                var T = globalThis.__WRMCP_TRACE__;
                var path = ${JsScripts.quote(target)}.split('.');
                var obj = globalThis;
                for (var i = 0; i < path.length - 1; i++) {
                  if (obj[path[i]] === undefined || obj[path[i]] === null) return 0;
                  obj = obj[path[i]];
                }
                var name = path[path.length - 1];
                var target2 = obj[name];
                if (!target2 || typeof target2 !== 'object') return 0;
                var count = 0;
                Object.getOwnPropertyNames(target2).slice(0, $maxMethods).forEach(function(k){
                  var fn = target2[k];
                  if (typeof fn !== 'function' || fn.__wrmcp_profiled__) return;
                  var stats = { calls: 0, totalMs: 0 };
                  var wrapped = function(){
                    var t0 = performance.now();
                    try { return fn.apply(this, arguments); }
                    finally {
                      stats.calls++;
                      stats.totalMs += performance.now() - t0;
                    }
                  };
                  wrapped.__wrmcp_profiled__ = true;
                  wrapped.__wrmcp_stats__ = stats;
                  wrapped.__wrmcp_orig__ = fn;
                  try { target2[k] = wrapped; count++; } catch(e){}
                });
                return count;
              } catch(e){ return 0; }
            })()
        """.trimIndent()
        return engine.evaluateJavascript(script)?.toDoubleOrNull()?.toInt() ?: 0
    }

    /** 取回剖析统计 */
    suspend fun collectProfile(engine: BrowserEngine): String? =
        engine.evaluateJavascript(
            """
            (function(){
              var out = [];
              try {
                var path = globalThis.__WRMCP_PROFILE_TARGET__;
              } catch(e){}
              function walk(obj, prefix, depth) {
                if (!obj || typeof obj !== 'object' || depth > 2 || out.length > 200) return;
                Object.getOwnPropertyNames(obj).forEach(function(k){
                  var fn = obj[k];
                  if (typeof fn === 'function' && fn.__wrmcp_stats__) {
                    out.push({ method: prefix + k, calls: fn.__wrmcp_stats__.calls,
                               totalMs: +fn.__wrmcp_stats__.totalMs.toFixed(2),
                               avgMs: +(fn.__wrmcp_stats__.totalMs / Math.max(1, fn.__wrmcp_stats__.calls)).toFixed(3) });
                  }
                });
              }
              walk(globalThis, '', 0);
              ['crypto','JSON','Math','Object','Array'].forEach(function(ns){
                try { walk(globalThis[ns], ns + '.', 1); } catch(e){}
              });
              return JSON.stringify(out.sort(function(a,b){ return b.totalMs - a.totalMs; }));
            })()
            """.trimIndent(),
        )

    // ---------------- 4. trace 收集 ----------------

    /** 取回 trace（JSON 字符串）；[filter] 过滤 target 包含关键字 */
    suspend fun collectTrace(engine: BrowserEngine, filter: String = "", limit: Int = 200): String? {
        val script = """
            (function(){
              var T = globalThis.__WRMCP_TRACE__;
              if (!T) return '[]';
              var arr = T.entries;
              ${if (filter.isNotBlank()) "arr = arr.filter(function(e){ return String(e.target||'').indexOf(${JsScripts.quote(filter)}) >= 0; });" else ""}
              return JSON.stringify({ total: T.n, buffered: T.entries.length, entries: arr.slice(-$limit) });
            })()
        """.trimIndent()
        return engine.evaluateJavascript(script)
    }

    /** 清空 trace */
    suspend fun clearTrace(engine: BrowserEngine) {
        engine.evaluateJavascript(
            "(function(){ var T = globalThis.__WRMCP_TRACE__; if (T) { T.entries = []; T.n = 0; } })()",
        )
    }
}
