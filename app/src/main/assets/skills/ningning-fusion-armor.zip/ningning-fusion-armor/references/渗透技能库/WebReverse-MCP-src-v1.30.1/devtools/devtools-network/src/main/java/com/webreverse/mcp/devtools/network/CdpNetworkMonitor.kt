package com.webreverse.mcp.devtools.network

import android.util.Base64
import com.webreverse.mcp.browser.engine.BrowserEngine
import com.webreverse.mcp.devtools.protocol.cdp.CdpEvent
import com.webreverse.mcp.devtools.protocol.cdp.CdpHub
import com.webreverse.mcp.devtools.protocol.cdp.CdpSession
import com.webreverse.mcp.devtools.protocol.cdp.CdpTransport
import com.webreverse.mcp.devtools.protocol.cdp.RawWebSocket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/**
 * CDP 网络监控（DevTools Network 面板语义）。
 *
 * 与注入式 Hook（fetch/XHR monkey patch）的差别：
 * - 覆盖所有请求（图片/字体/脚本/beacon/service worker），不仅是 JS 发起的
 * - 可回取任意已完成请求的响应体（Network.getResponseBody），含跨域资源
 * - 记录 fromCache / remoteIPAddress / 协议等元数据
 *
 * 连接策略：优先经 CDP 复用枢纽，与 CdpDebuggerSession 等进程内 MCP 会话
 * 共享同一条后端 CDP 会话——调试与网络监控同时接入同一页面互不踢线；
 * 枢纽不可用时回退直连（独立会话，Chromium 支持同 target 多客户端）。
 */
object CdpNetworkMonitor {

    /** 单条 CDP 网络请求 */
    data class CdpRequestInfo(
        val requestId: String,
        val url: String,
        val method: String = "",
        val resourceType: String = "",
        val status: Int = 0,
        val mimeType: String = "",
        val requestHeaders: Map<String, String> = emptyMap(),
        val responseHeaders: Map<String, String> = emptyMap(),
        val postData: String? = null,
        val finished: Boolean = false,
        val failed: Boolean = false,
        val errorText: String? = null,
        val size: Long = 0,
        val fromCache: Boolean = false,
        val remoteAddress: String? = null,
        val initiatorUrl: String = "",
    )

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    private var session: CdpSession? = null

    private var collector: kotlinx.coroutines.Job? = null

    private val _requests = MutableStateFlow<List<CdpRequestInfo>>(emptyList())
    val requests: StateFlow<List<CdpRequestInfo>> = _requests.asStateFlow()

    // ================= Fetch 域请求拦截（v1.13.0） =================

    /** 被拦截暂停中的请求（Fetch.requestPaused，等待 continue/mock/abort 决策） */
    data class PausedRequest(
        val fetchId: String,
        val networkRequestId: String,
        val url: String,
        val method: String,
        val headers: Map<String, String>,
        val postData: String?,
        val resourceType: String,
        val pausedAt: Long = System.currentTimeMillis(),
    )

    private val _pausedRequests = MutableStateFlow<List<PausedRequest>>(emptyList())
    val pausedRequests: StateFlow<List<PausedRequest>> = _pausedRequests.asStateFlow()

    // ================= WebSocket 帧捕获（v1.13.1） =================

    /** 一条 WS 数据帧（opcode 1=文本原样 / 2=二进制 payload 为 base64） */
    data class WsFrame(
        val requestId: String,
        val url: String,
        val direction: String, // send / receive
        val opcode: Int,
        val payload: String,
        val timestamp: Long = System.currentTimeMillis(),
    )

    /** requestId -> WS URL（webSocketCreated 登记，closed 移除） */
    private val wsUrls = java.util.concurrent.ConcurrentHashMap<String, String>()

    private val _wsFrames = MutableStateFlow<List<WsFrame>>(emptyList())
    val wsFrames: StateFlow<List<WsFrame>> = _wsFrames.asStateFlow()

    /** 附加页面的 tabId（attach 时记录，供事件转发） */
    @Volatile
    var attachedTabId: String? = null
        private set

    /**
     * WS 帧事件回调（宿主注册转发 EventBus → event.wait network.websocket 可用；
     * 未注册时仅内部列表，network.cdp_ws_frames 查询）。
     */
    @Volatile
    var wsFrameSink: ((tabId: String, url: String, direction: String, payload: String) -> Unit)? = null

    /** 查询 WS 帧（urlFilter 子串过滤，最新在前） */
    fun listWsFrames(urlFilter: String = "", limit: Int = 50): List<WsFrame> =
        _wsFrames.value
            .filter { urlFilter.isBlank() || it.url.contains(urlFilter, ignoreCase = true) }
            .asReversed()
            .take(limit)

    @Volatile
    private var intercepting = false

    /** 是否已开启拦截 */
    val isIntercepting: Boolean get() = intercepting && isAttached

    /**
     * 开启请求拦截（Fetch.enable）。
     * 匹配的请求在发出前暂停（不发网络），由 AI 决策：查看参数/改参数/模拟响应/放行。
     * @param urlPattern URL 通配（空=全部请求），如 通配符 "/api/sign"
     */
    suspend fun enableInterception(urlPattern: String = ""): Boolean {
        val s = session ?: return false
        val pattern = buildJsonObject {
            if (urlPattern.isNotBlank()) put("urlPattern", urlPattern)
            put("requestStage", "Request")
        }
        val ok = s.call(
            "Fetch.enable",
            buildJsonObject { put("patterns", kotlinx.serialization.json.JsonArray(listOf(pattern))) },
        ) != null
        if (ok) intercepting = true
        return ok
    }

    /** 关闭拦截（先放行全部暂停中的请求） */
    suspend fun disableInterception() {
        // 逐一放行，避免页面悬挂
        _pausedRequests.value.forEach { resumePaused(it.fetchId) }
        session?.call("Fetch.disable")
        intercepting = false
    }

    /** 放行指定暂停请求（可改写 url/headers/postData/method 后再放行） */
    suspend fun resumePaused(
        fetchId: String,
        url: String? = null,
        method: String? = null,
        headers: Map<String, String>? = null,
        postData: String? = null,
    ): Boolean {
        val s = session ?: return false
        val params = buildJsonObject {
            put("requestId", fetchId)
            url?.takeIf { it.isNotBlank() }?.let { put("url", it) }
            method?.takeIf { it.isNotBlank() }?.let { put("method", it) }
            headers?.let {
                put(
                    "headers",
                    kotlinx.serialization.json.buildJsonObject {
                        it.forEach { (k, v) -> put(k, v) }
                    },
                )
            }
            postData?.let { put("postData", it) }
        }
        val ok = s.call("Fetch.continueRequest", params) != null
        if (ok) _pausedRequests.value = _pausedRequests.value.filterNot { it.fetchId == fetchId }
        return ok
    }

    /** 以自定义响应直接回给页面（不发网络，Mock 服务器语义） */
    suspend fun mockPausedResponse(
        fetchId: String,
        body: String,
        status: Int = 200,
        mimeType: String = "application/json",
        headers: Map<String, String> = emptyMap(),
    ): Boolean {
        val s = session ?: return false
        val encoded = Base64.encodeToString(body.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val params = buildJsonObject {
            put("requestId", fetchId)
            put("responseCode", status)
            put(
                "responseHeaders",
                kotlinx.serialization.json.JsonArray(
                    (if (headers.containsKey("Content-Type")) headers else headers + ("Content-Type" to mimeType))
                        .map { (k, v) ->
                            buildJsonObject { put("name", k); put("value", v) }
                        },
                ),
            )
            put("body", encoded)
        }
        val ok = s.call("Fetch.fulfillRequest", params) != null
        if (ok) _pausedRequests.value = _pausedRequests.value.filterNot { it.fetchId == fetchId }
        return ok
    }

    /** 中止暂停请求（模拟失败） */
    suspend fun abortPaused(fetchId: String): Boolean {
        val s = session ?: return false
        val ok = s.call(
            "Fetch.failRequest",
            buildJsonObject {
                put("requestId", fetchId)
                put("errorReason", "Aborted")
            },
        ) != null
        if (ok) _pausedRequests.value = _pausedRequests.value.filterNot { it.fetchId == fetchId }
        return ok
    }

    // ================= 请求级仿真控制（v1.13.1 Emulation/Network 域） =================

    /** UA 覆盖（Emulation.setUserAgentOverride）：立即生效于 navigator.userAgent 与后续请求头 */
    suspend fun setUserAgentOverride(userAgent: String, acceptLanguage: String = "", platform: String = ""): Boolean {
        val s = session ?: return false
        val params = buildJsonObject {
            put("userAgent", userAgent)
            if (acceptLanguage.isNotBlank()) put("acceptLanguage", acceptLanguage)
            if (platform.isNotBlank()) put("platform", platform)
        }
        return s.call("Emulation.setUserAgentOverride", params) != null
    }

    /** 全局附加请求头（Network.setExtraHTTPHeaders）：空表清除。签名接口测试常用（注入 trace/debug 头观察服务端差异） */
    suspend fun setExtraHeaders(headers: Map<String, String>): Boolean {
        val s = session ?: return false
        return s.call(
            "Network.setExtraHTTPHeaders",
            buildJsonObject {
                put("headers", buildJsonObject { headers.forEach { (k, v) -> put(k, v) } })
            },
        ) != null
    }

    /** 禁用缓存（Network.setCacheDisabled）：true=强制走网络，分析时防缓存干扰（响应/请求才是真服务端数据） */
    suspend fun setCacheDisabled(disabled: Boolean): Boolean {
        val s = session ?: return false
        return s.call("Network.setCacheDisabled", buildJsonObject { put("cacheDisabled", disabled) }) != null
    }

    val isAttached: Boolean get() = session?.isConnected == true

    /** 附加到当前页面：Network.enable 后开始收集请求事件 */
    suspend fun attach(engine: BrowserEngine): Boolean {
        detach()
        clear()
        val pages = CdpTransport.listPages()
        if (pages == null) {
            if (CdpTransport.lastError == null) CdpTransport.lastError = "无法获取 DevTools 页面列表"
            return false
        }
        val targetUrl = engine.currentUrl()
        val pageCandidates = pages.filter { it.type == "page" }
        if (pageCandidates.isEmpty()) {
            CdpTransport.lastError = "DevTools 已连接但无 page 目标（页面可能尚未加载完成，稍后重试）"
            return false
        }
        val page = pageCandidates.firstOrNull { p ->
            !targetUrl.isNullOrBlank() && p.url.isNotBlank() &&
                (p.url == targetUrl || p.url.substringBefore('#').trimEnd('/').lowercase() ==
                    targetUrl.substringBefore('#').trimEnd('/').lowercase())
        } ?: pageCandidates.firstOrNull { p ->
            val host = targetUrl?.substringAfter("//")?.substringBefore('/').orEmpty()
            host.length > 3 && p.url.contains(host)
        } ?: pageCandidates.first()

        // 优先经 CDP 复用枢纽：与 CdpDebuggerSession 等进程内 MCP 会话共享
        // 同一条后端 CDP 会话，事件流互通不互踢；
        // 枢纽不可用时回退直连 unix socket（独立会话）
        val wsPath = CdpTransport.wsPathOf(page)
        val ws: RawWebSocket? = CdpHub.connectViaHub(wsPath)
            ?: CdpTransport.connectWebSocket(wsPath = wsPath)
        if (ws == null) {
            if (CdpTransport.lastError == null) CdpTransport.lastError = "WebSocket 升级失败"
            return false
        }
        val s = CdpSession(ws, scope)
        // 先启动接收循环再发域启用命令：CdpSession.isConnected 依赖 active 标志，
        // start() 之前调用 send() 会直接抛"CDP 会话未连接"（v1.15.1 修复：
        // 此前 Network.enable 在 start() 之前调用，attach_cdp 恒失败）
        s.start()
        val enableResult = s.callDetailed("Network.enable")
        if (enableResult.isFailure) {
            CdpTransport.lastError = "Network.enable 失败: ${enableResult.exceptionOrNull()?.message}"
            s.close()
            return false
        }
        session = s
        attachedTabId = engine.tabId
        collector?.cancel()
        collector = scope.launch { s.events.collect { onEvent(it) } }
        CdpTransport.lastError = null
        return true
    }

    fun detach() {
        collector?.cancel()
        collector = null
        session?.close()
        session = null
        intercepting = false
        _pausedRequests.value = emptyList()
        wsUrls.clear()
        _wsFrames.value = emptyList()
        attachedTabId = null
    }

    fun clear() {
        _requests.value = emptyList()
    }

    /** 仅清空 WS 帧缓冲 */
    fun clearWsFrames() {
        _wsFrames.value = emptyList()
    }

    fun list(urlFilter: String = "", limit: Int = 50): List<CdpRequestInfo> =
        _requests.value
            .filter { urlFilter.isBlank() || it.url.contains(urlFilter, ignoreCase = true) }
            .asReversed() // 插入序倒排 = 最新在前
            .take(limit)

    /** 回取响应体（DevTools Network 面板 Preview/Response 的能力） */
    suspend fun getResponseBody(requestId: String): JsonObject? {
        val s = session ?: return null
        val info = _requests.value.firstOrNull { it.requestId == requestId }
        val result = s.call(
            "Network.getResponseBody",
            buildJsonObject { put("requestId", requestId) },
        )
        val body = result?.get("body")?.jsonPrimitive?.contentOrNull
            ?: return buildJsonObject {
                put("requestId", requestId)
                put("url", info?.url ?: "")
                put("error", "响应体不可用（可能已被丢弃或非缓存资源），可尝试在请求完成后尽早获取")
            }
        val isBase64 = result["base64Encoded"]?.jsonPrimitive?.contentOrNull == "true"
        val decoded = if (isBase64) {
            runCatching { String(Base64.decode(body, Base64.DEFAULT), Charsets.UTF_8) }.getOrDefault(body)
        } else {
            body
        }
        return buildJsonObject {
            put("requestId", requestId)
            put("url", info?.url ?: "")
            put("status", info?.status ?: 0)
            put("mimeType", info?.mimeType ?: "")
            put("encoding", if (isBase64) "base64->utf8" else "utf8")
            put("length", decoded.length)
            put("body", decoded.take(500_000))
        }
    }

    // ---------------- 事件处理 ----------------

    private fun onEvent(event: CdpEvent) {
        when (event.method) {
            "Network.requestWillBeSent" -> onRequestWillBeSent(event.params)
            "Network.responseReceived" -> onResponseReceived(event.params)
            "Network.loadingFinished" -> onLoadingFinished(event.params)
            "Network.loadingFailed" -> onLoadingFailed(event.params)
            "Fetch.requestPaused" -> onRequestPaused(event.params)
            "Fetch.authRequired" -> onRequestAuthRequired(event.params)
            "Network.webSocketCreated" -> {
                val requestId = event.params["requestId"]?.jsonPrimitive?.contentOrNull ?: return
                val url = event.params["url"]?.jsonPrimitive?.contentOrNull ?: ""
                if (url.isNotBlank()) wsUrls[requestId] = url
            }
            "Network.webSocketFrameSent" -> onWsFrame(event.params, "send")
            "Network.webSocketFrameReceived" -> onWsFrame(event.params, "receive")
            "Network.webSocketClosed" ->
                event.params["requestId"]?.jsonPrimitive?.contentOrNull?.let { wsUrls.remove(it) }
        }
    }

    /** WS 数据帧入列 + 转发（opcode 1 文本原样 / 2 二进制 base64；跳过 ping/pong/close 控制帧） */
    private fun onWsFrame(params: JsonObject, direction: String) {
        val requestId = params["requestId"]?.jsonPrimitive?.contentOrNull ?: return
        val response = params["response"]?.jsonObject ?: return
        val opcode = response["opcode"]?.jsonPrimitive?.intOrNull ?: 1
        if (opcode != 1 && opcode != 2) return
        val payload = response["payloadData"]?.jsonPrimitive?.contentOrNull ?: ""
        if (payload.isBlank()) return
        val url = wsUrls[requestId] ?: ""
        val stored = if (opcode == 2 && !payload.startsWith("base64:")) "base64:$payload" else payload
        val frame = WsFrame(requestId, url, direction, opcode, stored.take(4096))
        _wsFrames.value = (_wsFrames.value + frame).takeLast(300)
        val tab = attachedTabId
        if (tab != null) wsFrameSink?.invoke(tab, url, direction, frame.payload)
    }

    /** 请求被拦截：入暂停表等待决策（AI 查看 → continue/mock/abort） */
    private fun onRequestPaused(params: JsonObject) {
        val fetchId = params["requestId"]?.jsonPrimitive?.contentOrNull ?: return
        val request = params["request"]?.jsonObject ?: return
        val url = request["url"]?.jsonPrimitive?.contentOrNull ?: return
        val paused = PausedRequest(
            fetchId = fetchId,
            networkRequestId = params["networkId"]?.jsonPrimitive?.contentOrNull ?: "",
            url = url,
            method = request["method"]?.jsonPrimitive?.contentOrNull ?: "GET",
            headers = headersOf(request["headers"]?.jsonObject),
            postData = request["postData"]?.jsonPrimitive?.contentOrNull,
            resourceType = params["resourceType"]?.jsonPrimitive?.contentOrNull ?: "",
        )
        _pausedRequests.value = (_pausedRequests.value + paused).takeLast(50)
    }

    /** 拦截触发的认证要求：默认不带凭据放行（保持流程可观察） */
    private fun onRequestAuthRequired(params: JsonObject) {
        val fetchId = params["requestId"]?.jsonPrimitive?.contentOrNull ?: return
        scope.launch {
            session?.call(
                "Fetch.continueWithAuth",
                buildJsonObject {
                    put("requestId", fetchId)
                    put("authChallengeResponse", buildJsonObject { put("response", "ProvideCredentials") })
                },
            )
        }
    }

    private fun onRequestWillBeSent(params: JsonObject) {
        val requestId = params["requestId"]?.jsonPrimitive?.contentOrNull ?: return
        val request = params["request"]?.jsonObject ?: return
        val url = request["url"]?.jsonPrimitive?.contentOrNull ?: return
        val info = CdpRequestInfo(
            requestId = requestId,
            url = url,
            method = request["method"]?.jsonPrimitive?.contentOrNull ?: "GET",
            resourceType = params["type"]?.jsonPrimitive?.contentOrNull ?: "",
            requestHeaders = headersOf(request["headers"]?.jsonObject),
            postData = request["postData"]?.jsonPrimitive?.contentOrNull,
            initiatorUrl = params["initiator"]?.jsonObject?.get("url")?.jsonPrimitive?.contentOrNull ?: "",
        )
        merge(requestId) { existing ->
            if (existing == null) info
            else existing.copy(
                url = url,
                method = info.method,
                resourceType = info.resourceType,
                requestHeaders = info.requestHeaders,
                postData = info.postData,
                initiatorUrl = info.initiatorUrl,
            )
        }
    }

    private fun onResponseReceived(params: JsonObject) {
        val requestId = params["requestId"]?.jsonPrimitive?.contentOrNull ?: return
        val response = params["response"]?.jsonObject ?: return
        merge(requestId) { existing ->
            val base = existing ?: CdpRequestInfo(requestId = requestId, url = response["url"]?.jsonPrimitive?.contentOrNull ?: "")
            base.copy(
                url = response["url"]?.jsonPrimitive?.contentOrNull ?: base.url,
                status = response["status"]?.jsonPrimitive?.contentOrNull?.toIntOrNull() ?: base.status,
                mimeType = response["mimeType"]?.jsonPrimitive?.contentOrNull ?: base.mimeType,
                responseHeaders = headersOf(response["headers"]?.jsonObject),
                fromCache = response["fromDiskCache"]?.jsonPrimitive?.contentOrNull == "true" ||
                    response["fromPrefetchCache"]?.jsonPrimitive?.contentOrNull == "true",
                remoteAddress = response["remoteIPAddress"]?.jsonPrimitive?.contentOrNull,
                resourceType = base.resourceType.ifBlank { params["type"]?.jsonPrimitive?.contentOrNull ?: "" },
            )
        }
    }

    private fun onLoadingFinished(params: JsonObject) {
        val requestId = params["requestId"]?.jsonPrimitive?.contentOrNull ?: return
        val size = params["encodedDataLength"]?.jsonPrimitive?.contentOrNull?.toLongOrNull() ?: 0L
        merge(requestId) { existing ->
            (existing ?: CdpRequestInfo(requestId = requestId, url = "")).copy(finished = true, size = size)
        }
    }

    private fun onLoadingFailed(params: JsonObject) {
        val requestId = params["requestId"]?.jsonPrimitive?.contentOrNull ?: return
        val error = params["errorText"]?.jsonPrimitive?.contentOrNull ?: "failed"
        val canceled = params["canceled"]?.jsonPrimitive?.contentOrNull == "true"
        merge(requestId) { existing ->
            (existing ?: CdpRequestInfo(requestId = requestId, url = ""))
                .copy(failed = true, errorText = if (canceled) "canceled" else error)
        }
    }

    private fun headersOf(headers: JsonObject?): Map<String, String> {
        headers ?: return emptyMap()
        val out = LinkedHashMap<String, String>()
        for ((k, v) in headers) {
            out[k] = v.jsonPrimitive.contentOrNull ?: v.toString()
        }
        return out
    }

    private fun merge(requestId: String, reducer: (CdpRequestInfo?) -> CdpRequestInfo) {
        val current = _requests.value.toList()
        val existing = current.firstOrNull { it.requestId == requestId }
        // 防重复（同一 redirect 链会复用 requestId 多次 requestWillBeSent）
        val updated = reducer(existing)
        val next = if (existing == null) {
            (current + updated).takeLast(MAX_ENTRIES)
        } else {
            current.map { if (it.requestId == requestId) updated else it }
        }
        _requests.value = next
    }

    private const val MAX_ENTRIES = 500
}
