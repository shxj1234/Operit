package com.webreverse.mcp.hook.rules

import com.webreverse.mcp.core.common.model.HookAction
import com.webreverse.mcp.core.common.model.HookMatch
import com.webreverse.mcp.core.common.model.HookRule
import com.webreverse.mcp.core.common.model.HookType
import com.webreverse.mcp.core.common.util.Ids

/** Hook 规则构建器 */
class HookRuleBuilder {
    private var name: String = ""
    private var type: HookType = HookType.FETCH
    private var match = HookMatch()
    private var action: HookAction = HookAction.LOG
    private var payload: String = ""
    private var description: String = ""
    private var enabled: Boolean = true

    fun name(value: String): HookRuleBuilder { name = value; return this }
    fun type(value: HookType): HookRuleBuilder { type = value; return this }
    fun action(value: HookAction): HookRuleBuilder { action = value; return this }
    fun payload(value: String): HookRuleBuilder { payload = value; return this }
    fun description(value: String): HookRuleBuilder { description = value; return this }
    fun enabled(value: Boolean): HookRuleBuilder { enabled = value; return this }

    fun matchUrl(pattern: String): HookRuleBuilder { match = match.copy(urlPattern = pattern); return this }
    fun matchHost(pattern: String): HookRuleBuilder { match = match.copy(hostPattern = pattern); return this }
    fun matchPath(pattern: String): HookRuleBuilder { match = match.copy(pathPattern = pattern); return this }
    fun matchMethod(method: String): HookRuleBuilder { match = match.copy(methodPattern = method); return this }
    fun matchHeader(pattern: String): HookRuleBuilder { match = match.copy(headerPattern = pattern); return this }
    fun matchBody(pattern: String): HookRuleBuilder { match = match.copy(bodyPattern = pattern); return this }
    fun matchResponse(pattern: String): HookRuleBuilder { match = match.copy(responsePattern = pattern); return this }
    fun matchRegex(pattern: String): HookRuleBuilder { match = match.copy(regexPattern = pattern); return this }
    fun matchTarget(target: String): HookRuleBuilder { match = match.copy(target = target); return this }

    fun build(): HookRule = HookRule(
        id = Ids.uuid(),
        name = name.ifBlank { "Untitled Rule" },
        type = type,
        match = match,
        action = action,
        payload = payload,
        enabled = enabled,
        description = description,
    )

    companion object {
        fun create(): HookRuleBuilder = HookRuleBuilder()

        /** 常用预设：Mock 响应 */
        fun mockResponse(urlPattern: String, responseJson: String): HookRule =
            create().name("Mock $urlPattern")
                .matchUrl(urlPattern)
                .action(HookAction.MOCK)
                .payload(responseJson)
                .build()

        /** 常用预设：拦截请求 */
        fun blockRequest(urlPattern: String): HookRule =
            create().name("Block $urlPattern")
                .matchUrl(urlPattern)
                .action(HookAction.BLOCK)
                .build()

        /** 常用预设：重定向 */
        fun redirect(from: String, to: String): HookRule =
            create().name("Redirect $from")
                .matchUrl(from)
                .action(HookAction.REDIRECT)
                .payload(to)
                .build()

        /** 常用预设：Fetch 监控 */
        fun monitorFetch(): HookRule =
            create().name("Fetch API Monitor")
                .type(HookType.FETCH)
                .action(HookAction.LOG)
                .description("记录 URL / Method / Headers 名称 / Body 类型 / Response Status / 调用堆栈")
                .build()

        /** 常用预设：Cookie 监控（脱敏） */
        fun monitorCookie(): HookRule =
            create().name("Cookie Monitor")
                .type(HookType.COOKIE)
                .action(HookAction.LOG)
                .description("监控 Cookie 读写，默认脱敏")
                .build()
    }
}
