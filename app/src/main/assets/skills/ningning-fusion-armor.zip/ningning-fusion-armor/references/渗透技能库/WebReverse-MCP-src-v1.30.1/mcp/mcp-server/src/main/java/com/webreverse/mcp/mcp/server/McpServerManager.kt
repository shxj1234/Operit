package com.webreverse.mcp.mcp.server

import android.content.Context
import com.webreverse.mcp.core.common.event.EventBus
import com.webreverse.mcp.core.common.model.McpClient
import com.webreverse.mcp.core.common.model.McpServerConfig
import com.webreverse.mcp.core.logging.AppLogger
import com.webreverse.mcp.core.logging.LogCategory
import com.webreverse.mcp.core.security.TokenManager
import com.webreverse.mcp.mcp.tools.ToolDependencies
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket

/**
 * MCP Server 管理器：负责 Server 生命周期、配置持久化、连接管理。
 * 提供给 UI 层（MCP Server 管理页面）使用。
 */
class McpServerManager(
    private val context: Context,
    private val deps: ToolDependencies,
    private val tokenManager: TokenManager,
    private val eventBus: EventBus,
    private val logger: AppLogger,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _config = MutableStateFlow(McpServerConfig())
    val config: StateFlow<McpServerConfig> = _config.asStateFlow()

    private val _serverState = MutableStateFlow(McpServerState.STOPPED)
    val serverState: StateFlow<McpServerState> = _serverState.asStateFlow()

    private val _clients = MutableStateFlow<List<McpClient>>(emptyList())
    val clients: StateFlow<List<McpClient>> = _clients.asStateFlow()

    private val _stats = MutableStateFlow(McpServerStats(McpServerState.STOPPED))
    val stats: StateFlow<McpServerStats> = _stats.asStateFlow()

    private var server: McpServer? = null

    /** 统计轮询任务：运行期间每秒从 Server 同步统计与客户端列表到 StateFlow */
    private var statsJob: Job? = null

    /** 启动 Server（端口检测等阻塞操作切换到 IO 线程，避免 UI 主线程调用时卡顿） */
    suspend fun start(): Boolean {
        if (_serverState.value == McpServerState.RUNNING) return true
        return withContext(Dispatchers.IO) {
            // 端口占用检测
            if (isPortInUse(_config.value.port)) {
                _serverState.value = McpServerState.ERROR
                logger.e(LogCategory.MCP, "端口 ${_config.value.port} 已被占用")
                return@withContext false
            }

            val cfg = _config.value.copy(enabled = true)
            _config.value = cfg

            val srv = McpServer(
                deps = deps,
                tokenManager = tokenManager,
                eventBus = eventBus,
                logger = logger,
                config = cfg,
            )
            val ok = srv.start()
            if (ok) {
                server = srv
                _serverState.value = McpServerState.RUNNING
                startStatsPolling()
                refreshStats()
                logger.i(LogCategory.MCP, "MCP Server 已启动")
            } else {
                _serverState.value = McpServerState.ERROR
            }
            ok
        }
    }

    /** 停止 Server（Netty 关闭为阻塞操作，切换到 IO 线程执行，避免 UI 主线程调用时卡顿） */
    suspend fun stop(): Boolean {
        val srv = server ?: return false
        return withContext(Dispatchers.IO) {
            val ok = srv.stop()
            if (ok) {
                server = null
                stopStatsPolling()
                _serverState.value = McpServerState.STOPPED
                _config.value = _config.value.copy(enabled = false)
                _stats.value = McpServerStats(McpServerState.STOPPED)
                _clients.value = emptyList()
                logger.i(LogCategory.MCP, "MCP Server 已停止")
            }
            ok
        }
    }

    /** 重启 Server */
    suspend fun restart(): Boolean {
        stop()
        return start()
    }

    /** 更新配置 */
    suspend fun updateConfig(config: McpServerConfig) {
        _config.value = config
        // 若正在运行则重启以应用新配置
        if (_serverState.value == McpServerState.RUNNING) {
            restart()
        }
    }

    /** 获取当前运行状态 */
    fun isRunning(): Boolean = _serverState.value == McpServerState.RUNNING

    /** 检查端口是否被占用（阻塞 socket 操作，仅供 IO 线程内部使用） */
    fun isPortInUse(port: Int): Boolean {
        return try {
            ServerSocket(port).use { socket ->
                socket.reuseAddress = true
                // 如果能绑定说明端口可用，绑定失败说明被占用
                false
            }
        } catch (e: Exception) {
            true
        }
    }

    /** 检查端口是否被占用（挂起版本，自动切换到 IO 线程，供 UI 安全调用） */
    suspend fun checkPort(port: Int): Boolean = withContext(Dispatchers.IO) { isPortInUse(port) }

    /** 获取本机局域网 IP 地址列表 */
    fun getLanAddresses(): List<String> {
        val addresses = mutableListOf<String>()
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            for (intf in interfaces) {
                // 跳过回环和未启用的接口
                if (intf.isLoopback || !intf.isUp) continue
                for (addr in intf.inetAddresses) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        addresses.add(addr.hostAddress ?: "")
                    }
                }
            }
        } catch (e: Exception) {
            logger.e(LogCategory.MCP, "获取局域网地址失败: ${e.message}")
        }
        return addresses.filter { it.isNotEmpty() }
    }

    /** 获取完整的 MCP 端点地址（本地） */
    fun mcpEndpoint(): String {
        val cfg = _config.value
        return "http://${cfg.host}:${cfg.port}/mcp"
    }

    /** 获取局域网 MCP 端点地址列表 */
    fun lanMcpEndpoints(): List<String> {
        val port = _config.value.port
        return getLanAddresses().map { "http://$it:$port/mcp" }
    }

    /** 获取服务器地址（供 UI 显示） */
    fun serverAddress(): String {
        val cfg = _config.value
        return "${cfg.host}:${cfg.port}"
    }

    /** 启动统计轮询 */
    private fun startStatsPolling() {
        statsJob?.cancel()
        statsJob = scope.launch {
            while (isActive) {
                try {
                    refreshStats()
                } catch (e: Exception) {
                    logger.e(LogCategory.MCP, "刷新统计失败: ${e.message}")
                }
                delay(1000)
            }
        }
    }

    /** 停止统计轮询 */
    private fun stopStatsPolling() {
        statsJob?.cancel()
        statsJob = null
    }

    /** 刷新统计 */
    private fun refreshStats() {
        val srv = server ?: return
        _stats.value = srv.stats()
        _clients.value = srv.connectedClients
    }
}
