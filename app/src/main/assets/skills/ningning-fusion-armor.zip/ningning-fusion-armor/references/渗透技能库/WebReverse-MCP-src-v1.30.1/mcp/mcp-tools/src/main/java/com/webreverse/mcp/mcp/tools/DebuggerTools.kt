package com.webreverse.mcp.mcp.tools

import com.webreverse.mcp.core.common.model.BreakpointType
import com.webreverse.mcp.core.common.model.DebuggerState
import com.webreverse.mcp.browser.engine.BrowserSession
import com.webreverse.mcp.core.common.event.DebuggerEvent
import com.webreverse.mcp.core.common.permission.PermissionScope
import com.webreverse.mcp.core.common.permission.RiskLevel
import com.webreverse.mcp.core.mcp.McpTool
import com.webreverse.mcp.core.mcp.McpToolResult
import com.webreverse.mcp.core.mcp.ToolCategory
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.coroutines.flow.first

/** Debugger Tools：断点、步进、调用栈、作用域、Watch（CDP 优先 + 注入式降级） */
object DebuggerTools {

    /** 未附加时自动 attach（幂等，CDP 优先） */
    private suspend fun ensureAttached(deps: ToolDependencies) {
        if (deps.debuggerManager.backend == "none") {
            deps.debuggerManager.attach(debugSession(deps).engine)
        }
    }

    /**
     * 调试目标会话：优先已建立 CDP 会话的 Tab（最近 attach 优先）。
     * 不随"活跃 Tab"漂移——多 Tab 场景下切换活跃 Tab 后，调试工具仍应
     * 作用于 attach 的目标页，否则断点列表为空、设置也打不到目标页面。
     */
    private suspend fun debugSession(deps: ToolDependencies): BrowserSession {
        for (tabId in deps.debuggerManager.connectedTabIds()) {
            deps.browserService.getSession(tabId)?.let { return it }
        }
        return deps.activeSession()
    }

    /** CDP 复用枢纽状态（AI 据此判断会话共享/暂停情况） */
    private fun linkageInfo(): JsonObject = buildJsonObject {
        val status = com.webreverse.mcp.devtools.protocol.cdp.CdpHub.linkageStatus()
        val mcpClients = status.sumOf { (it["mcpClients"] as? Int) ?: 0 }
        put("hubTargets", status.size)
        put("mcpClients", mcpClients)
        put(
            "hint",
            if (mcpClients > 0) {
                "CDP 复用枢纽工作中：调试与网络会话共享后端连接，互不踢线"
            } else {
                "尚无 MCP 会话接入 CDP 枢纽；debugger.attach / network.attach 后此处应有计数"
            },
        )
    }

    fun all(deps: ToolDependencies): List<McpTool> {
        val f = ToolFactory(deps)
        return listOf(
            f.tool(
                "debugger.attach", "附加调试器（优先建立 CDP 会话，获得真实 V8 断点/单步/调用栈能力）", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
            ) { _ ->
                val session = debugSession(deps)
                val result = deps.debuggerManager.attach(session.engine)
                result.fold(
                    onSuccess = {
                        McpToolResult.json(
                            buildJsonObject {
                                put("backend", JsonPrimitive(deps.debuggerManager.backend))
                                put("state", JsonPrimitive(deps.debuggerManager.state.value.name))
                                put("debugTabId", JsonPrimitive(session.tabId))
                                if (deps.debuggerManager.backend == "cdp") put("linkage", linkageInfo())
                                put(
                                    "hint",
                                    JsonPrimitive(
                                        if (deps.debuggerManager.backend == "cdp") {
                                            "CDP 已连接：断点/单步/调用栈/作用域为 V8 原生语义；注入的 debugger; 语句同样会真实暂停"
                                        } else {
                                            val reason = com.webreverse.mcp.devtools.protocol.cdp.CdpTransport.lastError
                                            "CDP 不可用，已降级注入式后端：仅支持函数断点/异常断点，步进与暂停态变量不可用" +
                                                (reason?.let { "。原因：$it" } ?: "")
                                        },
                                    ),
                                )
                            },
                        )
                    },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.detach", "分离调试器（断开 CDP 会话）", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
            ) { _ ->
                deps.debuggerManager.detach()
                McpToolResult.text("调试器已分离")
            },
            f.tool(
                "debugger.pause", "暂停 JavaScript 执行", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
            ) { _ ->
                val session = debugSession(deps)
                ensureAttached(deps)
                val result = deps.debuggerManager.pause(session.engine)
                result.fold(
                    onSuccess = { McpToolResult.text("已暂停") },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.resume", "恢复 JavaScript 执行", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
            ) { _ ->
                val session = debugSession(deps)
                val result = deps.debuggerManager.resume(session.engine)
                result.fold(
                    onSuccess = { McpToolResult.text("已恢复") },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.step_into", "单步进入", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
            ) { _ ->
                val session = debugSession(deps)
                val result = deps.debuggerManager.stepInto(session.engine)
                result.fold(
                    onSuccess = { McpToolResult.text("已单步进入") },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.step_over", "单步跳过", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
            ) { _ ->
                val session = debugSession(deps)
                val result = deps.debuggerManager.stepOver(session.engine)
                result.fold(
                    onSuccess = { McpToolResult.text("已单步跳过") },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.step_out", "单步跳出", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
            ) { _ ->
                val session = debugSession(deps)
                val result = deps.debuggerManager.stepOut(session.engine)
                result.fold(
                    onSuccess = { McpToolResult.text("已单步跳出") },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.restart_frame", "重启当前帧", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
            ) { _ ->
                val session = debugSession(deps)
                val result = deps.debuggerManager.restartFrame(session.engine)
                result.fold(
                    onSuccess = { McpToolResult.text("已重启帧") },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.set_breakpoint", "设置断点", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "type" to Schemas.strSchema("line/function/exception/xhr/dom/event"),
                    "url" to Schemas.strSchema("源码 URL"),
                    "line" to Schemas.intSchema("行号"),
                    "target" to Schemas.strSchema("目标（函数名/URL 片段）"),
                ),
            ) { args ->
                val type = ToolArgs.str(args, "type", "line")
                val url = ToolArgs.str(args, "url")
                var line = ToolArgs.int(args, "line")
                val target = ToolArgs.str(args, "target")
                val session = debugSession(deps)
                ensureAttached(deps)
                val bpType = when (type.lowercase()) {
                    "function" -> BreakpointType.FUNCTION
                    "exception" -> BreakpointType.EXCEPTION
                    "xhr" -> BreakpointType.XHR
                    "dom" -> BreakpointType.DOM
                    "event" -> BreakpointType.EVENT
                    "logpoint" -> BreakpointType.LOGPOINT
                    else -> BreakpointType.LINE
                }
                // LINE 断点失败时自动校准行号：V8 要求断在语句起点，
                // 猜测的行号（尤其 minified）常落在表达式中间导致未命中。
                // 用 getPossibleBreakpoints 找最近可断位置重试一次。
                var corrected = false
                var result = if (bpType == BreakpointType.FUNCTION && target.isNotBlank()) {
                    deps.debuggerManager.setFunctionBreakpoint(session.engine, target)
                } else {
                    deps.debuggerManager.setBreakpoint(session.engine, bpType, url, line, target = target)
                }
                if (result.isFailure && bpType == BreakpointType.LINE && url.isNotBlank() && line > 0) {
                    val correctedLine = deps.debuggerManager
                        .getBreakableLocations(session.engine, url, line, null, 1)
                        .getOrNull()
                        ?.firstOrNull()
                        ?.let { loc -> (loc as? JsonObject)?.get("lineNumber")?.jsonPrimitive?.intOrNull }
                    if (correctedLine != null && correctedLine > 0 && correctedLine != line) {
                        line = correctedLine
                        corrected = true
                        result = deps.debuggerManager.setBreakpoint(session.engine, bpType, url, line, target = target)
                    }
                }
                result.fold(
                    onSuccess = { bp ->
                        McpToolResult.json(
                            buildJsonObject {
                                put("id", JsonPrimitive(bp.id))
                                put("type", JsonPrimitive(bp.type.name))
                                put("url", JsonPrimitive(bp.url))
                                put("line", JsonPrimitive(bp.lineNumber))
                                put("target", JsonPrimitive(bp.target ?: ""))
                                if (corrected) put(
                                    "note",
                                    JsonPrimitive("原行号不可断，已自动校准到最近的语句起点（$line）"),
                                )
                                put(
                                    "hint",
                                    JsonPrimitive("event.wait eventType=debugger.breakpoint 阻塞等待命中；命中后 debugger.snapshot 一次取全现场"),
                                )
                            },
                        )
                    },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.remove_breakpoint", "移除断点", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema("breakpointId" to Schemas.strSchema("断点 ID")),
            ) { args ->
                val id = ToolArgs.str(args, "breakpointId")
                val session = debugSession(deps)
                val result = deps.debuggerManager.removeBreakpoint(session.engine, id)
                result.fold(
                    onSuccess = { McpToolResult.text("已移除断点: $id") },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.list_breakpoints", "列出所有断点（含外部调试客户端设置的断点，source 字段区分 mcp/devtools）", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.LOW,
            ) { _ ->
                val session = debugSession(deps)
                val breakpoints = deps.debuggerManager.listAllBreakpoints(session.engine)
                McpToolResult.json(
                    buildJsonObject {
                        put(
                            "breakpoints",
                            JsonArray(breakpoints),
                        )
                        if (deps.debuggerManager.backend == "cdp") put("linkage", linkageInfo())
                        put(
                            "hint",
                            JsonPrimitive("source=mcp 的用 remove_breakpoint(id) 移除；source=devtools 的 id 即 CDP breakpointId"),
                        )
                    },
                )
            },
            f.tool(
                "debugger.set_conditional_breakpoint", "设置条件断点", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "url" to Schemas.strSchema("源码 URL"),
                    "line" to Schemas.intSchema("行号"),
                    "condition" to Schemas.strSchema("条件表达式"),
                ),
            ) { args ->
                val url = ToolArgs.str(args, "url")
                val line = ToolArgs.int(args, "line")
                val condition = ToolArgs.str(args, "condition")
                val session = debugSession(deps)
                val result = deps.debuggerManager.setBreakpoint(session.engine, BreakpointType.LINE, url, line, condition = condition)
                result.fold(
                    onSuccess = { bp -> McpToolResult.text("已设置条件断点: ${bp.id}") },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.set_logpoint", "设置日志断点（Logpoint）", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "url" to Schemas.strSchema("源码 URL"),
                    "line" to Schemas.intSchema("行号"),
                    "expression" to Schemas.strSchema("日志表达式"),
                ),
            ) { args ->
                val url = ToolArgs.str(args, "url")
                val line = ToolArgs.int(args, "line")
                val expression = ToolArgs.str(args, "expression")
                val session = debugSession(deps)
                val result = deps.debuggerManager.setLogpoint(session.engine, url, line, expression)
                result.fold(
                    onSuccess = { bp -> McpToolResult.text("已设置 Logpoint: ${bp.id}") },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.watch", "添加 Watch 表达式", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema("expression" to Schemas.strSchema("Watch 表达式")),
            ) { args ->
                val expression = ToolArgs.str(args, "expression")
                val session = debugSession(deps)
                val result = deps.debuggerManager.addWatch(session.engine, expression)
                result.fold(
                    onSuccess = { w -> McpToolResult.text("已添加 Watch: ${w.id}") },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.unwatch", "移除 Watch 表达式", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema("watchId" to Schemas.strSchema("Watch ID")),
            ) { args ->
                val id = ToolArgs.str(args, "watchId")
                val result = deps.debuggerManager.removeWatch(id)
                result.fold(
                    onSuccess = { McpToolResult.text("已移除 Watch: $id") },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.evaluate_watch", "求值 Watch 表达式", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema("expression" to Schemas.strSchema("表达式")),
            ) { args ->
                val expression = ToolArgs.str(args, "expression")
                val session = debugSession(deps)
                val result = deps.debuggerManager.evaluateWatch(session.engine, expression)
                result.fold(
                    onSuccess = { McpToolResult.text(it) },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.call_stack", "获取当前调用栈", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
            ) { _ ->
                val session = debugSession(deps)
                val result = deps.debuggerManager.getCallStack(session.engine)
                result.fold(
                    onSuccess = { frames ->
                        McpToolResult.json(
                            buildJsonObject {
                                put(
                                    "callFrames",
                                    JsonArray(
                                        frames.map { fr ->
                                            buildJsonObject {
                                                put("functionName", JsonPrimitive(fr.functionName))
                                                put("url", JsonPrimitive(fr.url))
                                                put("lineNumber", JsonPrimitive(fr.lineNumber))
                                                put("columnNumber", JsonPrimitive(fr.columnNumber))
                                            }
                                        },
                                    ),
                                )
                            },
                        )
                    },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.scopes", "获取作用域", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
            ) { _ ->
                val session = debugSession(deps)
                val result = deps.debuggerManager.getScopes(session.engine)
                result.fold(
                    onSuccess = { scopes ->
                        McpToolResult.json(
                            buildJsonObject {
                                put(
                                    "scopes",
                                    JsonArray(
                                        scopes.map { s ->
                                            buildJsonObject {
                                                put("type", JsonPrimitive(s.type.name))
                                                put("name", JsonPrimitive(s.name))
                                            }
                                        },
                                    ),
                                )
                            },
                        )
                    },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.locals", "获取局部变量", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
            ) { _ ->
                val session = debugSession(deps)
                val result = deps.debuggerManager.getLocals(session.engine)
                result.fold(
                    onSuccess = { locals ->
                        McpToolResult.json(buildJsonObject { locals.forEach { (k, v) -> put(k, JsonPrimitive(v)) } })
                    },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.exceptions", "设置异常断点", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema("enabled" to Schemas.boolSchema("是否启用")),
            ) { args ->
                val enabled = ToolArgs.bool(args, "enabled", true)
                val session = debugSession(deps)
                if (deps.debuggerManager.backend != "cdp") {
                    ensureAttached(deps)
                }
                val result = deps.debuggerManager.setExceptionBreakpoints(session.engine, enabled)
                result.fold(
                    onSuccess = { McpToolResult.text(if (enabled) "已启用异常断点（V8 暂停于所有异常）" else "已禁用异常断点") },
                    onFailure = { McpToolResult.error("DEBUGGER_UNAVAILABLE", it.message) },
                )
            },
            f.tool(
                "debugger.list_scripts", "列出页面已解析脚本（CDP scriptParsed 流；含 scriptId/url/sourceMapUrl）", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema(
                    "urlFilter" to Schemas.strSchema("按 URL 子串过滤（可选）"),
                ),
            ) { args ->
                if (deps.debuggerManager.backend != "cdp") {
                    ensureAttached(deps)
                }
                if (deps.debuggerManager.backend != "cdp") {
                    return@tool McpToolResult.error("CDP_NOT_ATTACHED", "需要 CDP 会话，debugger.attach 失败（DevTools socket 不可用）")
                }
                val urlFilter = ToolArgs.str(args, "urlFilter")
                val session = debugSession(deps)
                val scripts = deps.debuggerManager.listScripts(session.engine)
                    .filter { urlFilter.isBlank() || it.url.contains(urlFilter) }
                McpToolResult.json(
                    buildJsonObject {
                        put("count", JsonPrimitive(scripts.size))
                        put(
                            "scripts",
                            JsonArray(
                                scripts.take(300).map { s ->
                                    buildJsonObject {
                                        put("scriptId", JsonPrimitive(s.scriptId))
                                        put("url", JsonPrimitive(s.url))
                                        put("length", JsonPrimitive(s.length))
                                        put("sourceMapUrl", JsonPrimitive(s.sourceMapUrl ?: ""))
                                    }
                                },
                            ),
                        )
                    },
                )
            },
            f.tool(
                "debugger.get_script_source", "获取脚本源码（配合 list_scripts 的 scriptId；可用于定位真实断点行号）", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "scriptId" to Schemas.strSchema("脚本 ID（来自 debugger.list_scripts）"),
                    "maxChars" to Schemas.intSchema("最大返回字符数（默认 100000）"),
                ),
            ) { args ->
                val scriptId = ToolArgs.str(args, "scriptId")
                val maxChars = ToolArgs.int(args, "maxChars", 100_000)
                if (scriptId.isBlank()) return@tool McpToolResult.error("INVALID_ARGS", "scriptId 不能为空")
                val session = debugSession(deps)
                val result = deps.debuggerManager.getScriptSource(session.engine, scriptId, maxChars)
                result.fold(
                    onSuccess = { src ->
                        McpToolResult.json(
                            buildJsonObject {
                                put("scriptId", JsonPrimitive(scriptId))
                                put("length", JsonPrimitive(src.length))
                                put("source", JsonPrimitive(src))
                            },
                        )
                    },
                    onFailure = { McpToolResult.error("SCRIPT_NOT_FOUND", it.message) },
                )
            },
            f.tool(
                "debugger.evaluate_on_call_frame", "暂停态在指定调用帧上求值（可读取断点处局部变量/闭包变量）", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "expression" to Schemas.strSchema("JS 表达式（如变量名 token）"),
                    "frame" to Schemas.intSchema("调用帧序号（默认 0，即栈顶）"),
                ),
            ) { args ->
                val expression = ToolArgs.str(args, "expression")
                val frame = ToolArgs.int(args, "frame", 0)
                if (expression.isBlank()) return@tool McpToolResult.error("INVALID_ARGS", "expression 不能为空")
                val session = debugSession(deps)
                val result = deps.debuggerManager.evaluateOnCallFrame(session.engine, expression, frame)
                result.fold(
                    onSuccess = { McpToolResult.text(it) },
                    onFailure = { McpToolResult.error("EVALUATE_FAILED", it.message) },
                )
            },
            f.tool(
                "debugger.set_source_breakpoint",
                "原始源码断点：src/api/sign.ts:87 -> 自动下载 sourcemap 反查 bundle 位置 -> V8 setBreakpointByUrl（DevTools Sources 面板语义）",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "sourceFile" to Schemas.strSchema("原始源文件路径（如 src/api/sign.ts，可用 debugger.list_source_maps 查看）"),
                    "line" to Schemas.intSchema("源文件行号（1-based）"),
                    "condition" to Schemas.strSchema("条件表达式（在断点位置由 V8 执行，可引用局部变量）"),
                ),
            ) { args ->
                val sourceFile = ToolArgs.str(args, "sourceFile")
                val line = ToolArgs.int(args, "line", 0)
                val condition = ToolArgs.str(args, "condition")
                if (sourceFile.isBlank() || line <= 0) {
                    return@tool McpToolResult.error("INVALID_ARGS", "sourceFile 与 line(>=1) 必填")
                }
                if (deps.debuggerManager.backend != "cdp") {
                    ensureAttached(deps)
                }
                val session = debugSession(deps)
                val result = deps.debuggerManager.setSourceBreakpoint(session.engine, sourceFile, line, condition.ifBlank { null })
                result.fold(
                    onSuccess = { bp ->
                        McpToolResult.json(
                            buildJsonObject {
                                put("breakpointId", JsonPrimitive(bp.id))
                                put("sourceFile", JsonPrimitive("$sourceFile:$line"))
                                put("bundleUrl", JsonPrimitive(bp.url))
                                put("bundleLine", JsonPrimitive(bp.lineNumber))
                                put("cdpBreakpointId", JsonPrimitive(bp.scriptId ?: ""))
                                put("hint", JsonPrimitive("断点已映射到 bundle 并由 V8 生效；触发对应代码后用 debugger.call_stack 查看"))
                            },
                        )
                    },
                    onFailure = { McpToolResult.error(it.code, it.message) },
                )
            },
            f.tool(
                "debugger.resolve_position", "bundle 位置 -> 原始源码位置（sourcemap 反查；用于把断点调用栈映射回源码）", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema(
                    "url" to Schemas.strSchema("脚本 URL（来自 list_scripts / call_stack）"),
                    "line" to Schemas.intSchema("bundle 行号（1-based）"),
                    "column" to Schemas.intSchema("列号（可选，默认 1）"),
                ),
            ) { args ->
                val url = ToolArgs.str(args, "url")
                val line = ToolArgs.int(args, "line", 0)
                val column = ToolArgs.int(args, "column", 1)
                if (url.isBlank() || line <= 0) return@tool McpToolResult.error("INVALID_ARGS", "url 与 line 必填")
                val session = debugSession(deps)
                val result = deps.debuggerManager.resolveOriginalPosition(session.engine, url, line, column)
                result.fold(
                    onSuccess = { loc ->
                        McpToolResult.json(
                            buildJsonObject {
                                put("source", JsonPrimitive(loc.source))
                                put("line", JsonPrimitive(loc.line))
                                put("column", JsonPrimitive(loc.column))
                                loc.name?.let { put("name", JsonPrimitive(it)) }
                            },
                        )
                    },
                    onFailure = { McpToolResult.error(it.code, it.message) },
                )
            },
            f.tool(
                "debugger.list_source_maps", "列出带 sourcemap 的脚本及原始源文件清单（下载解析后返回，供选择断点目标）", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.LOW,
            ) { _ ->
                if (deps.debuggerManager.backend != "cdp") {
                    ensureAttached(deps)
                }
                if (deps.debuggerManager.backend != "cdp") {
                    return@tool McpToolResult.error("CDP_NOT_ATTACHED", "需要 CDP 会话")
                }
                val session = debugSession(deps)
                val entries = deps.debuggerManager.listSourceMappedScripts(session.engine)
                McpToolResult.json(
                    buildJsonObject {
                        put("count", JsonPrimitive(entries.size))
                        put(
                            "scripts",
                            JsonArray(
                                entries.take(50).map { e ->
                                    buildJsonObject {
                                        put("scriptUrl", JsonPrimitive(e.scriptUrl))
                                        put("sourceMapUrl", JsonPrimitive(e.sourceMapUrl))
                                        put("parsed", JsonPrimitive(e.info?.parsed == true))
                                        e.error?.let { put("error", JsonPrimitive(it)) }
                                        put(
                                            "sources",
                                            JsonArray(e.sources.take(200).map { JsonPrimitive(it) }),
                                        )
                                    }
                                },
                            ),
                        )
                    },
                )
            },
            f.tool(
                "debugger.runtime_evaluate", "CDP Runtime.evaluate：支持 await/Promise，返回异常详情与 objectId（DevTools Console 语义）", ToolCategory.DEBUGGER,
                PermissionScope.EXECUTE_JS, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "expression" to Schemas.strSchema("JS 表达式（如 await fetch('/api/user').then(r=>r.json())）"),
                    "awaitPromise" to Schemas.boolSchema("是否等待 Promise（默认 true）"),
                ),
            ) { args ->
                val expression = ToolArgs.str(args, "expression")
                val awaitPromise = ToolArgs.bool(args, "awaitPromise", true)
                if (expression.isBlank()) return@tool McpToolResult.error("INVALID_ARGS", "expression 必填")
                if (deps.debuggerManager.backend != "cdp") {
                    ensureAttached(deps)
                }
                if (deps.debuggerManager.backend != "cdp") {
                    return@tool McpToolResult.error("CDP_NOT_ATTACHED", "需要 CDP 会话")
                }
                val session = debugSession(deps)
                val result = deps.debuggerManager.runtimeEvaluate(session.engine, expression, awaitPromise)
                result.fold(
                    onSuccess = { McpToolResult.json(it) },
                    onFailure = { McpToolResult.error(it.code, it.message) },
                )
            },
            f.tool(
                "debugger.get_object_properties", "按 objectId 展开远程对象属性（配合 runtime_evaluate 返回的 objectId 深入检查对象）", ToolCategory.DEBUGGER,
                PermissionScope.EXECUTE_JS, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema(
                    "objectId" to Schemas.strSchema("对象 ID（来自 runtime_evaluate / get_object_properties 的嵌套值）"),
                ),
            ) { args ->
                val objectId = ToolArgs.str(args, "objectId")
                if (objectId.isBlank()) return@tool McpToolResult.error("INVALID_ARGS", "objectId 必填")
                if (deps.debuggerManager.backend != "cdp") {
                    return@tool McpToolResult.error("CDP_NOT_ATTACHED", "需要 CDP 会话")
                }
                val session = debugSession(deps)
                val result = deps.debuggerManager.getObjectProperties(session.engine, objectId)
                result.fold(
                    onSuccess = { props ->
                        McpToolResult.json(
                            buildJsonObject {
                                put("count", JsonPrimitive(props.size))
                                put("properties", props)
                            },
                        )
                    },
                    onFailure = { McpToolResult.error(it.code, it.message) },
                )
            },
            f.tool(
                "debugger.detect_vmp",
                "静态探测 JSVMP 解释器 Dispatch 循环（while+大 switch+0x 密度特征），返回候选行号与疑似 opcode/pc 变量名",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema(
                    "scriptId" to Schemas.strSchema("脚本 ID（来自 debugger.list_scripts；留空则扫描最大脚本）"),
                ),
            ) { args ->
                if (deps.debuggerManager.backend != "cdp") {
                    ensureAttached(deps)
                }
                if (deps.debuggerManager.backend != "cdp") {
                    return@tool McpToolResult.error("CDP_NOT_ATTACHED", "需要 CDP 会话")
                }
                val scriptId = ToolArgs.str(args, "scriptId")
                val session = debugSession(deps)
                val scripts = deps.debuggerManager.listScripts(session.engine)
                    .filter { it.url.isNotBlank() && it.length > 1000 }
                val target = if (scriptId.isNotBlank()) {
                    scripts.firstOrNull { it.scriptId == scriptId }
                } else {
                    scripts.maxByOrNull { it.length }
                } ?: return@tool McpToolResult.error("SCRIPT_NOT_FOUND", "未找到可分析脚本")
                val source = deps.debuggerManager.getScriptSource(session.engine, target.scriptId, 2_000_000).getOrNull()
                    ?: return@tool McpToolResult.error("SOURCE_UNAVAILABLE", "源码获取失败")
                val detector = com.webreverse.mcp.javascript.analysis.VmpDetector()
                val candidates = detector.detect(source)
                McpToolResult.json(
                    buildJsonObject {
                        put("scriptUrl", JsonPrimitive(target.url))
                        put("scriptId", JsonPrimitive(target.scriptId))
                        put("candidateCount", JsonPrimitive(candidates.size))
                        put(
                            "candidates",
                            JsonArray(
                                candidates.map { c ->
                                    buildJsonObject {
                                        put("line", JsonPrimitive(c.line))
                                        put("column", JsonPrimitive(c.column))
                                        put("switchLine", JsonPrimitive(c.switchLine))
                                        put("switchColumn", JsonPrimitive(c.switchColumn))
                                        put("score", JsonPrimitive(c.score))
                                        put("caseCount", JsonPrimitive(c.caseCount))
                                        put("reasons", JsonPrimitive(c.reasons.joinToString("; ")))
                                        put("suggestedOps", JsonPrimitive(c.suggestedOps.joinToString(",")))
                                        if (c.handlers.isNotEmpty()) {
                                            put(
                                                "handlers",
                                                JsonArray(
                                                    c.handlers.take(20).map { h ->
                                                        buildJsonObject {
                                                            put("op", JsonPrimitive(h.key))
                                                            put("at", JsonPrimitive("${h.line}:${h.column}"))
                                                            put("code", JsonPrimitive(h.snippet.take(200)))
                                                        }
                                                    },
                                                ),
                                            )
                                        }
                                        put(
                                            "hint",
                                            JsonPrimitive(
                                                "下一步：debugger.trace_vmp url=<scriptUrl> line=${c.line} column=${c.column} expression=<opcode变量或其[pc]取值表达式>（minified 必须带 column）",
                                            ),
                                        )
                                    }
                                },
                            ),
                        )
                        if (candidates.isEmpty()) put("hint", JsonPrimitive("未发现典型 JSVMP 特征（可能是普通混淆或无保护）"))
                    },
                )
            },
            f.tool(
                "debugger.trace_vmp",
                "在 Dispatch 循环行设采样断点（条件恒 false 零暂停），每次执行记录表达式值到内存缓冲；运行目标操作后用 debugger.get_vmp_trace 取回",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "url" to Schemas.strSchema("脚本 URL"),
                    "line" to Schemas.intSchema("dispatch 循环行号（detect_vmp 的候选行）"),
                    "column" to Schemas.intSchema("dispatch 循环列号（detect_vmp 候选列；minified 单行脚本必填，否则断点打不进循环）"),
                    "expression" to Schemas.strSchema("采样表达式（如 opcode 变量名，或 code[pc] 取下条指令；可用 {op:x,pc:y} 对象采样多个值）"),
                    "sampleRate" to Schemas.intSchema("采样率：每 N 次执行记录 1 次（默认 1 全采；高频 dispatch 建议 10~100 降开销）"),
                ),
            ) { args ->
                val url = ToolArgs.str(args, "url")
                val line = ToolArgs.int(args, "line", 0)
                val column = ToolArgs.optInt(args, "column")
                val sampleRate = ToolArgs.int(args, "sampleRate", 1)
                val expression = ToolArgs.str(args, "expression")
                if (url.isBlank() || line <= 0 || expression.isBlank()) {
                    return@tool McpToolResult.error("INVALID_ARGS", "url / line / expression 必填")
                }
                if (deps.debuggerManager.backend != "cdp") {
                    ensureAttached(deps)
                }
                val session = debugSession(deps)
                val result = deps.debuggerManager.setTraceBreakpoint(session.engine, url, line, expression, column, sampleRate)
                result.fold(
                    onSuccess = { bp ->
                        McpToolResult.json(
                            buildJsonObject {
                                put("breakpointId", JsonPrimitive(bp.id))
                                put("url", JsonPrimitive(url))
                                put("line", JsonPrimitive(line))
                                put("column", JsonPrimitive(column ?: 0))
                                put("sampleRate", JsonPrimitive(sampleRate))
                                put("expression", JsonPrimitive(expression))
                                put(
                                    "hint",
                                    JsonPrimitive(
                                        "已开始采样（环形缓冲 5 万条上限）。触发目标操作（点击/请求），随后调用 debugger.get_vmp_trace 获取折叠分析；对照组实验先 baseline=true 快照，操作后 diff_vmp_trace",
                                    ),
                                )
                            },
                        )
                    },
                    onFailure = { McpToolResult.error(it.code, it.message) },
                )
            },
            f.tool(
                "debugger.get_vmp_trace",
                "取回 VMP 采样并输出折叠摘要（opcode 频次 + 循环块识别 + RLE 序列），数万条样本压缩为数百 token",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema(
                    "maxSamples" to Schemas.intSchema("最多取回样本数（默认 5000）"),
                    "clear" to Schemas.boolSchema("取回后是否清空缓冲（默认 true）"),
                    "baseline" to Schemas.boolSchema("是否同时把当前采样保存为对照组快照（供 diff_vmp_trace 差分；默认 false，置 true 时不清空）"),
                ),
            ) { args ->
                val maxSamples = ToolArgs.int(args, "maxSamples", 5000)
                val baseline = ToolArgs.bool(args, "baseline", false)
                val clear = if (baseline) false else ToolArgs.bool(args, "clear", true)
                val session = debugSession(deps)
                if (baseline) {
                    deps.debuggerManager.snapshotVmpBaseline(session.engine)
                }
                val result = deps.debuggerManager.collectVmpTrace(session.engine, maxSamples)
                if (clear) deps.debuggerManager.clearVmpTrace(session.engine)
                result.fold(
                    onSuccess = { report ->
                        McpToolResult.json(
                            buildJsonObject {
                                put("totalSamples", JsonPrimitive(report.totalSamples))
                                put("uniqueOpcodes", JsonPrimitive(report.uniqueOpcodes))
                                put(
                                    "topOpcodes",
                                    JsonArray(
                                        report.topOpcodes.take(20).map { s ->
                                            buildJsonObject {
                                                put("opcode", JsonPrimitive(s.opcode.take(120)))
                                                put("count", JsonPrimitive(s.count))
                                            }
                                        },
                                    ),
                                )
                                put(
                                    "loops",
                                    JsonArray(
                                        report.loops.map { l ->
                                            buildJsonObject {
                                                put("sequence", JsonPrimitive(l.sequence))
                                                put("repeats", JsonPrimitive(l.repeats))
                                            }
                                        },
                                    ),
                                )
                                put("sequenceSummary", JsonPrimitive(report.sequenceSummary))
                                if (baseline) {
                                    put(
                                        "baselineSaved",
                                        JsonPrimitive("对照组已保存；触发对照操作（如登录/签名请求）后调用 debugger.diff_vmp_trace"),
                                    )
                                }
                            },
                        )
                    },
                    onFailure = { McpToolResult.error(it.code, it.message) },
                )
            },
            f.tool(
                "debugger.diff_vmp_trace",
                "对照组差分：把当前采样与 baseline 快照做 LCS 对齐，新增/缺失的 opcode 块即疑似签名生成路径（实战最快定位法）",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.LOW,
            ) { _ ->
                val session = debugSession(deps)
                val result = deps.debuggerManager.diffVmpTrace(session.engine)
                result.fold(
                    onSuccess = { d ->
                        McpToolResult.json(
                            buildJsonObject {
                                put("baselineLen", JsonPrimitive(d.baselineLen))
                                put("testLen", JsonPrimitive(d.testLen))
                                put("commonRatio", JsonPrimitive("%.3f".format(d.commonRatio)))
                                put(
                                    "addedBlocks",
                                    JsonArray(d.addedBlocks.take(40).map { JsonPrimitive(it.take(160)) }),
                                )
                                put(
                                    "removedBlocks",
                                    JsonArray(d.removedBlocks.take(20).map { JsonPrimitive(it.take(160)) }),
                                )
                                put(
                                    "hint",
                                    JsonPrimitive(
                                        "addedBlocks 是对照组没有、本次新增的 opcode 块——疑似目标操作（登录/签名）专属执行路径；配合 detect_vmp 的 handlers 映射定位语义",
                                    ),
                                )
                            },
                        )
                    },
                    onFailure = { McpToolResult.error(it.code, it.message) },
                )
            },
            f.tool(
                "debugger.state", "获取调试器状态", ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.LOW,
            ) { _ ->
                McpToolResult.json(
                    buildJsonObject {
                        put("state", JsonPrimitive(deps.debuggerManager.state.value.name))
                        put("backend", JsonPrimitive(deps.debuggerManager.backend))
                        put("breakpointCount", JsonPrimitive(deps.debuggerManager.breakpoints.value.size))
                        put("watchCount", JsonPrimitive(deps.debuggerManager.watchExpressions.value.size))
                    },
                )
            },

            // ==================== v1.7.0 断点增强 ====================

            f.tool(
                "debugger.set_dom_breakpoint",
                "DOM 断点（DevTools Elements 断点语义）：subtree-modified / attribute-modified / node-removed；基于 MutationObserver，无需 CDP；命中记录变更详情+堆栈，pause=true 时在变更处暂停",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "selector" to Schemas.strSchema("CSS 选择器（如 #app 或 div.login-form）"),
                    "kind" to Schemas.strSchema("断点类型：subtree/attribute/removed/all（默认 all）"),
                    "pause" to Schemas.boolSchema("命中时是否 debugger 暂停（CDP attach 后为真实暂停；默认 false 仅记录）"),
                ),
            ) { args ->
                val selector = ToolArgs.str(args, "selector")
                if (selector.isBlank()) return@tool McpToolResult.error("INVALID_ARGS", "selector 必填")
                val kind = ToolArgs.str(args, "kind", "all")
                val pause = ToolArgs.bool(args, "pause", false)
                val session = debugSession(deps)
                val script = com.webreverse.mcp.browser.engine.util.JsScripts
                    .domBreakpointScript(selector, kind, pause)
                val raw = session.engine.evaluateJavascript(script) ?: "null"
                val ok = raw.contains("\"ok\":true")
                if (!ok) {
                    return@tool McpToolResult.error(
                        "SELECTOR_NOT_FOUND",
                        "选择器未匹配到元素（页面可能未就绪，先 browser.wait 或 dom.query 确认）",
                    )
                }
                McpToolResult.json(
                    buildJsonObject {
                        put("installed", JsonPrimitive(true))
                        put("selector", JsonPrimitive(selector))
                        put("kind", JsonPrimitive(kind))
                        put("pause", JsonPrimitive(pause))
                        put("hint", JsonPrimitive("触发 DOM 变化后调用 debugger.get_dom_hits 取回命中记录"))
                    },
                )
            },

            f.tool(
                "debugger.get_dom_hits",
                "取回 DOM 断点命中记录（变更类型/目标/属性/旧值/堆栈）",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema(
                    "limit" to Schemas.intSchema("最多返回条数（默认 100）"),
                    "clear" to Schemas.boolSchema("取回后清空（默认 false）"),
                ),
            ) { args ->
                val session = debugSession(deps)
                val raw = deps.debuggerManager.collectBreakpointHits(
                    session.engine, "dom", ToolArgs.int(args, "limit", 100),
                ) ?: return@tool McpToolResult.error("EVALUATE_FAILED", "取回失败")
                if (ToolArgs.bool(args, "clear", false)) {
                    deps.debuggerManager.clearBreakpointHits(session.engine, "dom")
                }
                McpToolResult.text(raw)
            },

            f.tool(
                "debugger.set_event_breakpoint",
                "事件监听断点（DevTools Event Listener Breakpoints）：指定事件类型（click/keydown/submit/...；control=控件类全集，all=常见交互全集）在监听器执行前暂停/记录",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "eventType" to Schemas.strSchema("事件类型：click/keydown/submit/mousemove... 或 control/all"),
                    "pause" to Schemas.boolSchema("命中时是否 debugger 暂停（默认 false 仅记录）"),
                    "captureStack" to Schemas.boolSchema("记录调用堆栈（默认 true）"),
                ),
            ) { args ->
                val eventType = ToolArgs.str(args, "eventType")
                if (eventType.isBlank()) return@tool McpToolResult.error("INVALID_ARGS", "eventType 必填")
                val pause = ToolArgs.bool(args, "pause", false)
                val captureStack = ToolArgs.bool(args, "captureStack", true)
                val session = debugSession(deps)
                val script = com.webreverse.mcp.browser.engine.util.JsScripts
                    .eventBreakpointScript(eventType, pause, captureStack)
                session.engine.evaluateJavascript(script)
                McpToolResult.json(
                    buildJsonObject {
                        put("installed", JsonPrimitive(true))
                        put("eventType", JsonPrimitive(eventType))
                        put("pause", JsonPrimitive(pause))
                        put("hint", JsonPrimitive("触发事件后调用 debugger.get_event_hits 取回命中记录"))
                    },
                )
            },

            f.tool(
                "debugger.get_event_hits",
                "取回事件断点命中记录（事件/目标/键值/堆栈）",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema(
                    "limit" to Schemas.intSchema("最多返回条数（默认 100）"),
                    "clear" to Schemas.boolSchema("取回后清空（默认 false）"),
                ),
            ) { args ->
                val session = debugSession(deps)
                val raw = deps.debuggerManager.collectBreakpointHits(
                    session.engine, "event", ToolArgs.int(args, "limit", 100),
                ) ?: return@tool McpToolResult.error("EVALUATE_FAILED", "取回失败")
                if (ToolArgs.bool(args, "clear", false)) {
                    deps.debuggerManager.clearBreakpointHits(session.engine, "event")
                }
                McpToolResult.text(raw)
            },

            f.tool(
                "debugger.set_promise_breakpoint",
                "Promise 断点：捕获 unhandledrejection（含 reason 与堆栈），pause=true 时暂停",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "pause" to Schemas.boolSchema("命中时是否 debugger 暂停（默认 false 仅记录）"),
                ),
            ) { args ->
                val session = debugSession(deps)
                val script = com.webreverse.mcp.browser.engine.util.JsScripts
                    .promiseBreakpointScript(ToolArgs.bool(args, "pause", false))
                session.engine.evaluateJavascript(script)
                McpToolResult.json(
                    buildJsonObject {
                        put("installed", JsonPrimitive(true))
                        put("hint", JsonPrimitive("Promise 拒绝发生后调用 debugger.get_promise_hits 取回"))
                    },
                )
            },

            f.tool(
                "debugger.get_promise_hits",
                "取回 Promise 断点命中记录（reason/堆栈）",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.LOW,
            ) { _ ->
                val session = debugSession(deps)
                val raw = deps.debuggerManager.collectBreakpointHits(session.engine, "promise", 100)
                    ?: return@tool McpToolResult.error("EVALUATE_FAILED", "取回失败")
                McpToolResult.text(raw)
            },

            // ================= v1.13.0 CDP 增强 =================

            f.tool(
                "debugger.snapshot",
                "暂停现场一键快照：断点命中后一次返回 调用栈+每帧局部变量+this+命中断点+原因（免多次调 call_stack/scopes/locals）",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.LOW,
            ) { _ ->
                val session = debugSession(deps)
                ensureAttached(deps)
                deps.debuggerManager.snapshotPausedState(session.engine).fold(
                    onSuccess = { McpToolResult.json(it) },
                    onFailure = { McpToolResult.error(it.code, it.message) },
                )
            },
            f.tool(
                "debugger.wait_breakpoint",
                "等待断点命中并直接返回暂停现场快照（= event.wait debugger.paused + snapshot 一步到位）：设好断点、触发操作后调用，命中即返回调用栈+局部变量；已暂停态立即返回",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema(
                    "timeoutMs" to Schemas.intSchema("等待毫秒（默认 30000）"),
                ),
            ) { args ->
                val timeoutMs = ToolArgs.long(args, "timeoutMs", 30_000L)
                ensureAttached(deps)
                val session = debugSession(deps)
                if (deps.debuggerManager.state.value != DebuggerState.PAUSED) {
                    val hit = kotlinx.coroutines.withTimeoutOrNull(timeoutMs) {
                        deps.eventBus.events.first { it is DebuggerEvent.Paused }
                    }
                    if (hit == null) {
                        return@tool McpToolResult.error(
                            "TIMEOUT",
                            "等待断点命中超时：确认断点位置可达（get_breakable_locations 校准行号）、触发对应操作，或改用 XHR/事件断点",
                        )
                    }
                }
                deps.debuggerManager.snapshotPausedState(session.engine).fold(
                    onSuccess = { McpToolResult.json(it) },
                    onFailure = { McpToolResult.error(it.code, it.message) },
                )
            },
            f.tool(
                "debugger.search_script",
                "在脚本内容中搜索（CDP Debugger.searchInContent，不拉全量源码，返回行号+命中行）：定位加密函数/关键字出现位置",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema(
                    "scriptIdOrUrl" to Schemas.strSchema("脚本 scriptId 或 URL（list_scripts 获取）"),
                    "query" to Schemas.strSchema("搜索文本（正则语法）"),
                    "caseSensitive" to Schemas.boolSchema("区分大小写（默认 false）"),
                    "limit" to Schemas.intSchema("最多返回条数（默认 50）"),
                ),
            ) { args ->
                val scriptIdOrUrl = ToolArgs.str(args, "scriptIdOrUrl")
                val query = ToolArgs.str(args, "query")
                if (scriptIdOrUrl.isBlank() || query.isBlank()) {
                    return@tool McpToolResult.error("INVALID_ARGS", "scriptIdOrUrl 与 query 必填")
                }
                ensureAttached(deps)
                val session = debugSession(deps)
                deps.debuggerManager.searchScriptContent(
                    session.engine, scriptIdOrUrl, query,
                    ToolArgs.bool(args, "caseSensitive", false),
                    ToolArgs.int(args, "limit", 50),
                ).fold(
                    onSuccess = { matches ->
                        McpToolResult.json(
                            buildJsonObject {
                                put("matches", matches)
                                put("count", JsonPrimitive(matches.size))
                            },
                        )
                    },
                    onFailure = { McpToolResult.error(it.code, it.message) },
                )
            },
            f.tool(
                "debugger.get_breakable_locations",
                "查询可断点位置（CDP getPossibleBreakpoints）：V8 行号自动对齐到语句起点，打断点前先查可精确命中（minified 必用）",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema(
                    "url" to Schemas.strSchema("脚本 URL"),
                    "line" to Schemas.intSchema("行号（1-based）"),
                    "column" to Schemas.intSchema("列号（可选，1-based）"),
                    "limit" to Schemas.intSchema("最多返回条数（默认 20）"),
                ),
            ) { args ->
                val url = ToolArgs.str(args, "url")
                val line = ToolArgs.int(args, "line", 0)
                if (url.isBlank() || line <= 0) {
                    return@tool McpToolResult.error("INVALID_ARGS", "url 与 line(>=1) 必填")
                }
                ensureAttached(deps)
                val session = debugSession(deps)
                deps.debuggerManager.getBreakableLocations(
                    session.engine, url, line,
                    ToolArgs.int(args, "column", 0).takeIf { it > 0 },
                    ToolArgs.int(args, "limit", 20),
                ).fold(
                    onSuccess = { McpToolResult.json(buildJsonObject { put("locations", it) }) },
                    onFailure = { McpToolResult.error(it.code, it.message) },
                )
            },
            f.tool(
                "debugger.set_variable",
                "暂停态修改局部变量（CDP setVariableValue）：改完单步即可观察加密逻辑走向",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "name" to Schemas.strSchema("变量名"),
                    "value" to Schemas.strSchema("新值（JS 表达式，如 'abc' / 123 / {a:1}）"),
                    "frameIndex" to Schemas.intSchema("调用帧序号（默认 0，顶部帧）"),
                    "scopeNumber" to Schemas.intSchema("作用域序号（默认 0，从 scopes 结果取）"),
                ),
            ) { args ->
                val name = ToolArgs.str(args, "name")
                val value = ToolArgs.str(args, "value")
                if (name.isBlank() || value.isBlank()) {
                    return@tool McpToolResult.error("INVALID_ARGS", "name 与 value 必填")
                }
                val session = debugSession(deps)
                deps.debuggerManager.setVariableValue(
                    session.engine,
                    ToolArgs.int(args, "frameIndex", 0),
                    ToolArgs.int(args, "scopeNumber", 0),
                    name, value,
                ).fold(
                    onSuccess = { McpToolResult.json(buildJsonObject { put("ok", JsonPrimitive(true)); put("variable", JsonPrimitive(name)); put("value", JsonPrimitive(value)) }) },
                    onFailure = { McpToolResult.error(it.code, it.message) },
                )
            },
            f.tool(
                "debugger.query_objects",
                "构造器实例查询（CDP Runtime.queryObjects）：找出某类（加密器/签名器）现存全部实例，逐一 dump 找密钥与配置",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema(
                    "constructor" to Schemas.strSchema("构造器表达式，如 window.JSEncrypt / Object.getPrototypeOf(obj)"),
                    "limit" to Schemas.intSchema("最多返回实例数（默认 20）"),
                ),
            ) { args ->
                val ctor = ToolArgs.str(args, "constructor")
                if (ctor.isBlank()) return@tool McpToolResult.error("INVALID_ARGS", "constructor 必填")
                ensureAttached(deps)
                val session = debugSession(deps)
                deps.debuggerManager.queryObjects(session.engine, ctor, ToolArgs.int(args, "limit", 20))
                    .fold(
                        onSuccess = { McpToolResult.json(it) },
                        onFailure = { McpToolResult.error(it.code, it.message) },
                    )
            },
            f.tool(
                "debugger.call_on_object",
                "在远程对象上调用方法（CDP Runtime.callFunctionOn）：配合 get_object_properties 的 objectId，读加密器内部状态/调用实例方法",
                ToolCategory.DEBUGGER,
                PermissionScope.EXECUTE_JS, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "objectId" to Schemas.strSchema("对象 objectId（get_object_properties / runtime_evaluate 获取）"),
                    "functionDeclaration" to Schemas.strSchema("函数声明，如 function(){ return this.key; }"),
                    "arguments" to Schemas.strSchema("参数（JSON 数组字符串，每项为 JS 表达式；省略=无参）"),
                ),
            ) { args ->
                val objectId = ToolArgs.str(args, "objectId")
                val fn = ToolArgs.str(args, "functionDeclaration")
                if (objectId.isBlank() || fn.isBlank()) {
                    return@tool McpToolResult.error("INVALID_ARGS", "objectId 与 functionDeclaration 必填")
                }
                val argsJson = ToolArgs.str(args, "arguments").takeIf { it.isNotBlank() }
                val argv: List<String> = if (argsJson == null) {
                    emptyList()
                } else {
                    runCatching {
                        kotlinx.serialization.json.Json.parseToJsonElement(argsJson).jsonArray
                            .mapNotNull { el -> el.jsonPrimitive.contentOrNull }
                    }.getOrDefault(emptyList())
                }
                ensureAttached(deps)
                val session = debugSession(deps)
                deps.debuggerManager.callFunctionOn(session.engine, objectId, fn, argv).fold(
                    onSuccess = { McpToolResult.json(it) },
                    onFailure = { McpToolResult.error(it.code, it.message) },
                )
            },
            f.tool(
                "debugger.set_xhr_breakpoint",
                "CDP 原生 XHR/fetch 断点（DOMDebugger.setXHRBreakpoint）：请求发起前真实暂停（与 DevTools XHR breakpoints 同源），栈底即签名函数",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "urlPattern" to Schemas.strSchema("URL 子串匹配，空串=全部请求"),
                    "enabled" to Schemas.boolSchema("true 设置 / false 移除（默认 true）"),
                ),
            ) { args ->
                val pattern = ToolArgs.str(args, "urlPattern")
                val enabled = ToolArgs.bool(args, "enabled", true)
                val session = debugSession(deps)
                deps.debuggerManager.setXhrBreakpoint(session.engine, pattern, enabled).fold(
                    onSuccess = {
                        McpToolResult.json(
                            buildJsonObject {
                                put("ok", JsonPrimitive(true))
                                put("urlPattern", JsonPrimitive(pattern))
                                put("enabled", JsonPrimitive(enabled))
                                if (enabled) put(
                                    "hint",
                                    JsonPrimitive("触发请求后将暂停：先 debugger.snapshot 看现场，再 debugger.call_stack 找签名函数"),
                                )
                            },
                        )
                    },
                    onFailure = { McpToolResult.error(it.code, it.message) },
                )
            },
            f.tool(
                "debugger.set_listener_breakpoint",
                "CDP 原生事件监听断点（DOMDebugger.setEventListenerBreakpoint）：监听器执行前真实暂停，比注入式断点更准（含第三方框架委托）",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "eventName" to Schemas.strSchema("事件名：click / keydown / submit / mouseover ..."),
                    "enabled" to Schemas.boolSchema("true 设置 / false 移除（默认 true）"),
                ),
            ) { args ->
                val eventName = ToolArgs.str(args, "eventName")
                if (eventName.isBlank()) return@tool McpToolResult.error("INVALID_ARGS", "eventName 必填")
                val enabled = ToolArgs.bool(args, "enabled", true)
                val session = debugSession(deps)
                deps.debuggerManager.setEventListenerBreakpoint(session.engine, eventName, enabled).fold(
                    onSuccess = {
                        McpToolResult.json(
                            buildJsonObject {
                                put("ok", JsonPrimitive(true))
                                put("eventName", JsonPrimitive(eventName))
                                put("enabled", JsonPrimitive(enabled))
                            },
                        )
                    },
                    onFailure = { McpToolResult.error(it.code, it.message) },
                )
            },
            f.tool(
                "debugger.set_script_breakpoint",
                "脚本执行前断点（beforeScriptExecution）：任何新脚本执行前暂停，拦截加密初始化/JSVMP 加载时机（enabled=false 移除）",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.MEDIUM,
                inputSchema = Schemas.objectSchema(
                    "enabled" to Schemas.boolSchema("true 设置 / false 移除（默认 true）"),
                ),
            ) { args ->
                val enabled = ToolArgs.bool(args, "enabled", true)
                val session = debugSession(deps)
                deps.debuggerManager.setInstrumentationBreakpoint(session.engine, enabled).fold(
                    onSuccess = {
                        McpToolResult.json(
                            buildJsonObject {
                                put("ok", JsonPrimitive(true))
                                put("enabled", JsonPrimitive(enabled))
                                if (enabled) put("hint", JsonPrimitive("刷新页面（browser.reload）或等待动态加载即会在每个新脚本前暂停"))
                            },
                        )
                    },
                    onFailure = { McpToolResult.error(it.code, it.message) },
                )
            },
            f.tool(
                "debugger.cpu_profile",
                "CPU 性能分析（CDP Profiler）：start=true 开始采样，操作页面跑加密流程后 start=false 停止，返回 selfTime 热点函数（加密/签名计算通常霸榜，url:line 直接可断点）",
                ToolCategory.DEBUGGER,
                PermissionScope.DEBUG_SCRIPT, RiskLevel.LOW,
                inputSchema = Schemas.objectSchema(
                    "start" to Schemas.boolSchema("true=开始录制 / false=停止并返回热点（必填）"),
                    "topN" to Schemas.intSchema("热点函数数量（默认 25）"),
                ),
            ) { args ->
                val start = ToolArgs.bool(args, "start", false)
                ensureAttached(deps)
                val session = debugSession(deps)
                deps.debuggerManager.cpuProfile(session.engine, start, ToolArgs.int(args, "topN", 25)).fold(
                    onSuccess = { McpToolResult.json(it) },
                    onFailure = { McpToolResult.error(it.code, it.message) },
                )
            },
        )
    }
}
