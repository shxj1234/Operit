package com.webreverse.mcp.mcp.server

import com.webreverse.mcp.core.common.event.EventBus
import com.webreverse.mcp.core.logging.LogCategory
import com.webreverse.mcp.core.common.model.McpClient
import com.webreverse.mcp.core.common.model.McpServerConfig
import com.webreverse.mcp.core.common.model.McpSession
import com.webreverse.mcp.core.common.model.McpSessionStatus
import com.webreverse.mcp.core.common.util.Ids
import com.webreverse.mcp.core.logging.AppLogger
import com.webreverse.mcp.core.mcp.*
import com.webreverse.mcp.core.security.TokenManager
import com.webreverse.mcp.mcp.prompts.McpPromptProvider
import com.webreverse.mcp.mcp.prompts.Prompts
import com.webreverse.mcp.mcp.resources.BrowserResources
import com.webreverse.mcp.mcp.resources.McpResourceProvider
import com.webreverse.mcp.mcp.tools.InvestigationPersistenceBridge
import com.webreverse.mcp.mcp.tools.NetworkPersistenceBridge
import com.webreverse.mcp.mcp.tools.ToolDependencies
import com.webreverse.mcp.mcp.tools.ToolModule
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.*
import io.ktor.server.plugins.calllogging.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.server.plugins.cors.routing.*
import io.ktor.server.plugins.statuspages.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.server.websocket.*
import io.ktor.utils.io.*
import io.ktor.websocket.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.*
import java.net.InetSocketAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlin.time.Duration.Companion.seconds

/**
 * MCP Server 状态
 */
enum class McpServerState {
    STOPPED, STARTING, RUNNING, STOPPING, ERROR,
}

/**
 * MCP Server 统计
 */
data class McpServerStats(
    val state: McpServerState,
    val uptimeMs: Long = 0,
    val connectionCount: Int = 0,
    val toolCallCount: Int = 0,
    val clientCount: Int = 0,
    val sessionCount: Int = 0,
)

/**
 * MCP Server：基于 Ktor 的 HTTP + WebSocket 服务。
 * 处理 JSON-RPC 请求、管理会话、认证、Tool/Resource/Prompt 分发。
 *
 * 架构：
 * AI Agent (Claude/GPT/Cursor)  --HTTP/WS-->  MCP Server (Ktor)
 *                                               |
 *                                        ToolRegistry (100+ Tools)
 *                                               |
 *                                        ToolDependencies (Browser/Debugger/Hook/...)
 *                                               |
 *                                        BrowserService (WebView/Chromium)
 */
class McpServer(
    private val deps: ToolDependencies,
    private val tokenManager: TokenManager,
    private val eventBus: EventBus,
    private val logger: AppLogger,
    private val config: McpServerConfig = McpServerConfig(),
) {
    /**
     * 协议 JSON 实例：
     * - encodeDefaults=true：确保 "jsonrpc":"2.0" 等默认字段一定出现在响应里（MCP 客户端强校验）
     * - explicitNulls=false：null 字段完全不输出。关键点——MCP SDK 用多态反序列化器
     *   区分响应类型，若输出 "error": null，客户端会按错误响应解析并在 RPCError 处崩溃
     * - ignoreUnknownKeys=true：容忍客户端请求中的未知字段
     */
    private val protocolJson = Json {
        encodeDefaults = true
        explicitNulls = false
        ignoreUnknownKeys = true
        isLenient = true
    }

    private var server: EmbeddedServer<*, *>? = null
    private val _state = MutableStateFlow(McpServerState.STOPPED)
    val state: StateFlow<McpServerState> = _state.asStateFlow()

    private val clients = ConcurrentHashMap<String, McpClient>()
    private val sessions = ConcurrentHashMap<String, McpSession>()
    private val toolCallCounter = AtomicInteger(0)
    private val connectionCounter = AtomicInteger(0)
    private val mutex = Mutex()
    private var startedAt = 0L

    /** 当前连接的客户端（供 UI 展示） */
    val connectedClients: List<McpClient>
        get() = clients.values.toList()

    // Tool Registry
    val toolRegistry = ToolRegistry()
    // Resource Provider
    val resourceProvider = McpResourceProvider()
    // Prompt Provider
    val promptProvider = McpPromptProvider()

    // WebSocket sessions
    private val wsSessions = ConcurrentHashMap<String, WebSocketSession>()

    /** P0-1 安全守卫：HTTP/SSE/WS 统一入口 Token 认证 + 速率限制 + IP 白名单 */
    private val authGuard by lazy { AuthGuard(tokenManager, config) }

    /** P0-6 网络持久化桥：把 EventBus 网络事件写入 Room */
    private var networkPersistence: NetworkPersistenceBridge? = null

    /** P1-14 调查持久化桥：把内存调查定期同步到 Room（支持重启恢复） */
    private var investigationPersistence: InvestigationPersistenceBridge? = null

    /** 本次绑定是否需强制认证（非回环地址出于安全必须强制） */
    val authRequired: Boolean get() = authGuard.isAuthRequired()

    /**
     * 统一认证入口。失败时按结果返回对应状态码并发射安全审计事件。
     * 返回 true 表示放行。
     */
    private suspend fun ApplicationCall.authorize(identity: String): Boolean = try {
        when (val result = authGuard.authenticate(request, request.origin.remoteHost, identity)) {
            is AuthGuard.AuthResult.Allowed -> true
            is AuthGuard.AuthResult.Unauthorized -> {
                eventBus.tryEmit(com.webreverse.mcp.core.common.event.McpEvent.AuthFailed(request.origin.remoteHost, result.reason))
                logger.w(LogCategory.MCP, "认证失败: ${result.reason} from ${request.origin.remoteHost}")
                respondText("""{"jsonrpc":"2.0","error":{"code":-32001,"message":"${result.reason}"}}""", ContentType.Application.Json, HttpStatusCode.Unauthorized)
                false
            }
            is AuthGuard.AuthResult.RateLimited -> {
                logger.w(LogCategory.MCP, "速率限制: $identity")
                respondText("""{"error":"rate_limited","retry_after_ms":${result.retryAfterMs}}""", ContentType.Application.Json, HttpStatusCode.TooManyRequests)
                false
            }
            is AuthGuard.AuthResult.Rejected -> {
                eventBus.tryEmit(com.webreverse.mcp.core.common.event.McpEvent.AuthFailed(request.origin.remoteHost, result.reason))
                logger.w(LogCategory.MCP, "请求被拒: ${result.reason}")
                respondText("""{"error":"forbidden"}""", ContentType.Application.Json, HttpStatusCode.Forbidden)
                false
            }
        }
    } catch (e: Exception) {
        logger.e(LogCategory.MCP, "认证异常: ${e.message}")
        respondText("""{"error":"auth_error"}""", ContentType.Application.Json, HttpStatusCode.Unauthorized)
        false
    }

    /** 启动 Server */
    suspend fun start(): Boolean = mutex.withLock {
        if (_state.value == McpServerState.RUNNING) return false
        _state.value = McpServerState.STARTING
        logger.i(LogCategory.MCP, "MCP Server 启动中...")

        try {
            // 注册 Tools
            ToolModule.registerAll(deps, toolRegistry)
            logger.i(LogCategory.MCP, "已注册 ${toolRegistry.count()} 个 Tools")

            // 注册 Resources
            resourceProvider.registerAll(BrowserResources(deps.browserService).all())
            promptsTemplates().forEach { resourceProvider.registerTemplate(it) }
            logger.i(LogCategory.MCP, "已注册 ${resourceProvider.count()} 个 Resources")

            // 注册 Prompts
            promptProvider.registerAll(Prompts.all())
            logger.i(LogCategory.MCP, "已注册 ${promptProvider.count()} 个 Prompts")

            startedAt = System.currentTimeMillis()

            server = embeddedServer(Netty, port = config.port, host = config.host) {
                install(ContentNegotiation) { json(Json { ignoreUnknownKeys = true }) }
                install(CallLogging)
                install(StatusPages) {
                    exception<Throwable> { call, cause ->
                        logger.e(LogCategory.MCP, "Server error: ${cause.message}", cause)
                        call.respondText(
                            """{"jsonrpc":"2.0","error":{"code":-32603,"message":"Internal error: ${cause.message}"}}""",
                            ContentType.Application.Json,
                            HttpStatusCode.InternalServerError,
                        )
                    }
                }
                install(CORS) {
                    // P0-1 安全：不再 anyHost()。仅允许回环与本机访问，避免浏览器在局域网内被
                    // 恶意页面跨域调用 MCP（配合非回环绑定时的强制 Token 认证共同兜底）。
                    allowHost("127.0.0.1")
                    allowHost("localhost")
                    allowHost("::1")
                    allowHost(config.host)
                    allowMethod(HttpMethod.Options)
                    allowMethod(HttpMethod.Post)
                    allowMethod(HttpMethod.Get)
                    allowHeader(HttpHeaders.ContentType)
                    allowHeader(HttpHeaders.Authorization)
                    allowHeader("X-MCP-Token")
                }
                install(WebSockets) {
                    pingPeriod = 15.seconds
                    timeout = 15.seconds
                    maxFrameSize = Long.MAX_VALUE
                }

                routing {
                    // HTTP JSON-RPC endpoint
                    post("/mcp") { handleJsonRpc(call) }
                    // 按 MCP Streamable HTTP 规范：不支持服务端主动推送流时，GET 返回 405
                    get("/mcp") {
                        call.respond(HttpStatusCode.MethodNotAllowed)
                    }

                    // SSE endpoint
                    get("/mcp/sse") {
                        handleSse(call)
                    }

                    // WebSocket endpoint
                    webSocket("/mcp/ws") { handleWebSocket() }

                    // Health check
                    get("/health") {
                        call.respondText(
                            """{"status":"${_state.value.name}","uptime":${System.currentTimeMillis() - startedAt},"tools":${toolRegistry.count()},"clients":${clients.size}}""",
                            ContentType.Application.Json,
                        )
                    }

                    // Stats
                    get("/mcp/stats") {
                        call.respond(stats())
                    }
                }
            }.start(wait = false)

            _state.value = McpServerState.RUNNING
            logger.i(LogCategory.MCP, "MCP Server 已启动: ${config.host}:${config.port}")
            // P0-6 启动网络事件 → Room 持久化链路
            networkPersistence = NetworkPersistenceBridge(deps).also { it.start() }
            // P1-14 启动调查内存 → Room 持久化链路
            investigationPersistence = InvestigationPersistenceBridge(deps).also { it.start() }
            eventBus.tryEmit(com.webreverse.mcp.core.common.event.McpEvent.ServerStarted(config.host, config.port))
            true
        } catch (e: Exception) {
            _state.value = McpServerState.ERROR
            logger.e(LogCategory.MCP, "MCP Server 启动失败: ${e.message}", e)
            false
        }
    }

    /** 停止 Server */
    suspend fun stop(): Boolean = mutex.withLock {
        if (_state.value != McpServerState.RUNNING) return false
        _state.value = McpServerState.STOPPING
        logger.i(LogCategory.MCP, "MCP Server 停止中...")

        try {
            // P0-6 停止网络持久化订阅
            networkPersistence?.stop()
            networkPersistence = null
            // P1-14 停止调查持久化
            investigationPersistence?.stop()
            investigationPersistence = null
            // 关闭所有 WebSocket 连接
            wsSessions.values.forEach { s ->
                try { s.close(CloseReason(CloseReason.Codes.NORMAL, "Server stopping")) } catch (_: Exception) {}
            }
            wsSessions.clear()
            server?.stop(500, 1000)
            server = null
            _state.value = McpServerState.STOPPED
            logger.i(LogCategory.MCP, "MCP Server 已停止")
            eventBus.tryEmit(com.webreverse.mcp.core.common.event.McpEvent.ServerStopped())
            true
        } catch (e: Exception) {
            _state.value = McpServerState.ERROR
            logger.e(LogCategory.MCP, "MCP Server 停止失败: ${e.message}", e)
            false
        }
    }

    /** 获取统计 */
    fun stats(): McpServerStats = McpServerStats(
        state = _state.value,
        uptimeMs = if (startedAt > 0) System.currentTimeMillis() - startedAt else 0,
        // 累计连接次数（HTTP initialize + WebSocket 握手均计入）
        connectionCount = connectionCounter.get(),
        toolCallCount = toolCallCounter.get(),
        clientCount = clients.size,
        sessionCount = sessions.size,
    )

    /** 获取当前配置 */
    fun currentConfig(): McpServerConfig = config

    private fun promptsTemplates(): List<com.webreverse.mcp.core.mcp.ResourceTemplate> = listOf(
        com.webreverse.mcp.core.mcp.ResourceTemplate(
            uriTemplate = "browser://page/{tabId}",
            name = "指定标签页",
            description = "通过 tabId 读取指定标签页信息",
            mimeType = "application/json",
        ),
        com.webreverse.mcp.core.mcp.ResourceTemplate(
            uriTemplate = "browser://network/{tabId}",
            name = "指定标签页网络",
            description = "读取指定标签页的网络请求",
            mimeType = "application/json",
        ),
    )

    // ==================== JSON-RPC 处理 ====================

    private suspend fun handleJsonRpc(call: ApplicationCall) {
        try {
            val body = call.receiveText()

            // P0-1 认证：在解析/处理之前于传输层统一拒绝未授权请求
            val preRemote = call.request.origin.remoteHost
            val preIdentity = "http:${call.request.header("Mcp-Session-Id") ?: "anon:$preRemote"}"
            if (!call.authorize(preIdentity)) return

            val request = protocolJson.decodeFromString<JsonRpcRequest>(body)

            // 通知类消息（notifications/* 或无 id）：按 MCP Streamable HTTP 规范返回 202 Accepted，无响应体
            if (request.method.startsWith("notifications/") || request.id is JsonNull) {
                call.respond(HttpStatusCode.Accepted)
                return
            }

            val remoteHost = call.request.origin.remoteHost

            // 注册/更新 HTTP 客户端与统计。每个非通知请求都计入：
            // 客户端在服务重启后通常不会重新 initialize，而是带着旧会话头直接调用工具，
            // 若只在 initialize 时注册，连接数/客户端/会话/已连接 Agent 将恒为 0
            val clientKey = registerHttpClient(call, request, remoteHost) ?: "http:$remoteHost"

            val agentName = request.params["clientInfo"]?.let { it as? JsonObject }
                ?.stringField("name")?.ifBlank { null }
                ?: clients[clientKey]?.name ?: "AI Agent"

            val response = processRequest(request, clientKey, agentName)

            eventBus.tryEmit(com.webreverse.mcp.core.common.event.McpEvent.ToolInvoked(request.method, "http", false))

            call.respondText(
                protocolJson.encodeToString(JsonRpcResponse.serializer(), response),
                ContentType.Application.Json,
            )
        } catch (e: Exception) {
            logger.e(LogCategory.MCP, "JSON-RPC 处理错误: ${e.message}", e)
            call.respondText(
                """{"jsonrpc":"2.0","id":null,"error":{"code":-32603,"message":"${e.message}"}}""",
                ContentType.Application.Json,
                HttpStatusCode.InternalServerError,
            )
        }
    }

    /**
     * 注册/更新 HTTP 客户端（Streamable HTTP 无状态，按请求跟踪）：
     * - initialize：生成新 sessionId（经 Mcp-Session-Id 响应头返回给客户端）并以此注册，
     *   同时清理同主机残留的旧 HTTP 客户端/会话（服务重启后的过期会话）
     * - 其他请求：优先按客户端回传的 Mcp-Session-Id 请求头识别同一客户端；
     *   未携带时（客户端从未 initialize 或会话已丢失）退化为按来源主机识别
     */
    private fun registerHttpClient(call: ApplicationCall, request: JsonRpcRequest, remoteHost: String): String? {
        val now = System.currentTimeMillis()
        val sessionHeader = call.request.header("Mcp-Session-Id")

        if (request.method == McpMethod.INITIALIZE) {
            val sessionId = Ids.uuid()
            call.response.header("Mcp-Session-Id", sessionId)

            val clientInfo = request.params["clientInfo"] as? JsonObject
            val clientName = clientInfo?.stringField("name")
                ?: request.params.stringField("clientName")
                ?: "Unknown"
            val clientVersion = clientInfo?.stringField("version").orEmpty()
            val displayName = if (clientVersion.isNotEmpty()) "$clientName $clientVersion" else clientName

            // 清理同主机残留的旧 HTTP 客户端与对应会话，避免重复计数
            clients.entries
                .filter { it.value.transport == "HTTP" && it.value.remoteAddress == remoteHost }
                .map { it.key }
                .forEach { key ->
                    clients.remove(key)
                    sessions.remove(key)
                }

            val key = "http:$sessionId"
            clients[key] = McpClient(
                id = sessionId,
                name = displayName,
                transport = "HTTP",
                remoteAddress = remoteHost,
                connectedAt = now,
                lastActiveAt = now,
            )
            connectionCounter.incrementAndGet()
            sessions[key] = McpSession(
                id = sessionId,
                clientId = key,
                clientName = clientName,
                startedAt = now,
            )
            return key
        }

        val identity = sessionHeader ?: remoteHost
        val key = "http:$identity"
        val existing = clients[key]
        if (existing == null) {
            val userAgent = call.request.header(HttpHeaders.UserAgent)?.takeIf { it.isNotBlank() }
            val displayName = userAgent ?: "HTTP-Client ($remoteHost)"
            clients[key] = McpClient(
                id = identity,
                name = displayName,
                transport = "HTTP",
                remoteAddress = remoteHost,
                connectedAt = now,
                lastActiveAt = now,
            )
            connectionCounter.incrementAndGet()
            sessions[key] = McpSession(
                id = identity,
                clientId = key,
                clientName = displayName,
                startedAt = now,
            )
        } else {
            clients[key] = existing.copy(lastActiveAt = now)
        }
        return key
    }

    private suspend fun handleSse(call: ApplicationCall) {
        val clientId = Ids.short()
        val remoteHost = call.request.origin.remoteHost

        // P0-1 认证：SSE 常走 URL query token
        if (!call.authorize("sse:$clientId@$remoteHost")) return
        logger.i(LogCategory.MCP, "SSE 连接: $clientId from $remoteHost")

        // 注册客户端
        clients[clientId] = McpClient(
            id = clientId,
            name = "SSE-Client-$clientId",
            transport = "SSE",
            remoteAddress = remoteHost,
        )
        connectionCounter.incrementAndGet()

        call.respondBytesWriter(contentType = ContentType.Text.EventStream) {
            // 发送初始连接事件
            writeStringUtf8("event: connected\ndata: {\"clientId\":\"$clientId\"}\n\n")
            flush()

            try {
                // 保持连接，监听事件
                eventBus.events
                    .filterIsInstance<com.webreverse.mcp.core.common.event.McpEvent>()
                    .collect { event ->
                        val data = when (event) {
                            is com.webreverse.mcp.core.common.event.McpEvent.ServerStarted -> """{"event":"server_started","port":${event.port}}"""
                            is com.webreverse.mcp.core.common.event.McpEvent.ServerStopped -> """{"event":"server_stopped"}"""
                            is com.webreverse.mcp.core.common.event.McpEvent.ToolInvoked -> """{"event":"tool_called","tool":"${event.toolName}","isError":${event.isError}}"""
                            else -> null
                        }
                        if (data != null) {
                            try {
                                writeStringUtf8("event: message\ndata: $data\n\n")
                                flush()
                            } catch (_: Exception) {
                                throw java.util.concurrent.CancellationException("SSE client disconnected")
                            }
                        }
                    }
            } catch (e: java.util.concurrent.CancellationException) {
                // 正常断开
            } finally {
                clients.remove(clientId)
            }
        }
    }

    private suspend fun WebSocketServerSession.handleWebSocket() {
        val clientId = Ids.short()
        val remoteHost = call.request.origin.remoteHost

        // P0-1 认证：WS 握手阶段校验（URL 可携带 ?token=）
        if (!call.authorize("ws:$clientId@$remoteHost")) return
        logger.i(LogCategory.MCP, "WebSocket 连接: $clientId from $remoteHost")

        clients[clientId] = McpClient(
            id = clientId,
            name = "WS-Client-$clientId",
            transport = "WebSocket",
            remoteAddress = remoteHost,
        )
        connectionCounter.incrementAndGet()
        wsSessions[clientId] = this

        // 创建会话
        val session = McpSession(
            id = Ids.uuid(),
            clientId = clientId,
            clientName = "WS-Client-$clientId",
        )
        sessions[session.id] = session

        try {
            for (frame in incoming) {
                when (frame) {
                    is Frame.Text -> {
                        val text = frame.readText()
                        val startTime = System.currentTimeMillis()
                        try {
                            val request = protocolJson.decodeFromString<JsonRpcRequest>(text)

                            // 通知类消息不产生响应（JSON-RPC 2.0 规范）
                            val isNotification = request.method.startsWith("notifications/") || request.id is JsonNull
                            if (!isNotification) {
                                val response = processRequest(request, session.id, session.clientName.ifBlank { "WS-Client-$clientId" })
                                val responseJson = protocolJson.encodeToString(JsonRpcResponse.serializer(), response)
                                outgoing.send(Frame.Text(responseJson))

                                val duration = System.currentTimeMillis() - startTime
                                eventBus.tryEmit(com.webreverse.mcp.core.common.event.McpEvent.ToolInvoked(request.method, session.id, false))
                            }
                        } catch (e: Exception) {
                            val errorResponse = """{"jsonrpc":"2.0","id":null,"error":{"code":-32700,"message":"Parse error: ${e.message}"}}"""
                            outgoing.send(Frame.Text(errorResponse))
                        }
                    }
                    is Frame.Close -> {
                        val closeReason = CloseReason(CloseReason.Codes.NORMAL, "Client closed")
                        close(closeReason)
                    }
                    else -> {}
                }
            }
        } catch (e: Exception) {
            logger.w(LogCategory.MCP, "WebSocket error: ${e.message}")
        } finally {
            wsSessions.remove(clientId)
            clients.remove(clientId)
            sessions[session.id]?.let { s ->
                sessions[s.id] = s.copy(status = McpSessionStatus.CLOSED, endedAt = System.currentTimeMillis())
            }
        }
    }

    /** 处理 JSON-RPC 请求 → 分发到 Tools/Resources/Prompts */
    private suspend fun processRequest(
        request: JsonRpcRequest,
        sessionId: String = "unknown",
        agentName: String = "AI Agent",
    ): JsonRpcResponse {
        val id = request.id
        return when (request.method) {
            McpMethod.INITIALIZE -> handleInitialize(request)
            // ping 结果按规范为空对象
            McpMethod.PING -> JsonRpcResponse.success(id, JsonObject(emptyMap()))
            McpMethod.TOOLS_LIST -> handleToolsList(id)
            McpMethod.TOOLS_CALL -> handleToolsCall(id, request.params, sessionId, agentName)
            McpMethod.RESOURCES_LIST -> handleResourcesList(id)
            McpMethod.RESOURCES_READ -> handleResourcesRead(id, request.params)
            McpMethod.RESOURCES_TEMPLATES_LIST -> handleResourcesTemplatesList(id)
            McpMethod.PROMPTS_LIST -> handlePromptsList(id)
            McpMethod.PROMPTS_GET -> handlePromptsGet(id, request.params)
            McpMethod.COMPLETION_COMPLETE -> handleCompletion(id, request.params)
            McpMethod.LOGGING_SET_LEVEL -> JsonRpcResponse.success(id, JsonObject(emptyMap()))
            McpMethod.NOTIFICATIONS_INITIALIZED -> JsonRpcResponse.success(id, JsonObject(emptyMap()))
            else -> JsonRpcResponse.error(id, JsonRpcErrorCode.METHOD_NOT_FOUND, "Unknown method: ${request.method}")
        }
    }

    private fun handleInitialize(request: JsonRpcRequest): JsonRpcResponse {
        // 客户端注册与会话创建由 registerHttpClient 统一处理
        // 回显客户端请求的协议版本；未指定时使用默认版本
        val protocolVersion = request.params.stringField("protocolVersion") ?: "2025-03-26"

        // MCP 标准 InitializeResult：protocolVersion + capabilities + serverInfo（必需）
        return JsonRpcResponse.success(
            id = request.id,
            result = buildJsonObject {
                put("protocolVersion", JsonPrimitive(protocolVersion))
                put("capabilities", buildJsonObject {
                    put("tools", buildJsonObject {
                        put("listChanged", JsonPrimitive(true))
                    })
                    put("resources", buildJsonObject {
                        put("listChanged", JsonPrimitive(true))
                        put("subscribe", JsonPrimitive(true))
                    })
                    put("prompts", buildJsonObject {
                        put("listChanged", JsonPrimitive(true))
                    })
                    put("logging", buildJsonObject {})
                })
                put("serverInfo", buildJsonObject {
                    put("name", JsonPrimitive("WebReverseMCP"))
                    put("version", JsonPrimitive("1.0.0"))
                })
                put("instructions", JsonPrimitive("WebReverse MCP Server：提供浏览器自动化、页面逆向分析、网络抓包、Hook 等工具集。"))
            },
        )
    }

    /** 从 JsonObject 安全读取字符串字段 */
    private fun JsonObject?.stringField(key: String): String? =
        (this?.get(key) as? JsonPrimitive)?.contentOrNull

    private fun handleToolsList(id: JsonElement): JsonRpcResponse {
        // MCP 标准 Tool 字段：name + description + inputSchema（额外字段可能导致严格解析的客户端失败）
        val tools = toolRegistry.listMetadata().map { meta ->
            buildJsonObject {
                put("name", JsonPrimitive(meta.name))
                put("description", JsonPrimitive(meta.description))
                put("inputSchema", meta.inputSchema)
            }
        }
        return JsonRpcResponse.success(
            id = id,
            result = buildJsonObject {
                put("tools", JsonArray(tools))
            },
        )
    }

    private suspend fun handleToolsCall(id: JsonElement, params: JsonObject, sessionId: String, agentName: String): JsonRpcResponse {
        val name = params["name"]?.let { (it as? JsonPrimitive)?.content } ?: ""
        val arguments = params["arguments"] as? JsonObject ?: JsonObject(emptyMap())

        if (name.isBlank()) {
            return JsonRpcResponse.error(id, JsonRpcErrorCode.INVALID_PARAMS, "Missing tool name")
        }

        val tool = toolRegistry.get(name)
        if (tool == null) {
            return JsonRpcResponse.error(id, JsonRpcErrorCode.TOOL_NOT_FOUND, "Tool not found: $name")
        }

        toolCallCounter.incrementAndGet()
        logger.i(LogCategory.MCP, "调用 Tool: $name (session=$sessionId, agent=$agentName)")

        // 构建工具执行上下文：显式 tabId 参数优先（用于「分析指定标签页」类工具），
        // 缺省则为空，由 ToolDependencies.activeSession() 按固定 Tab 绑定/活动 Tab 解析。
        val tabId = (arguments["tabId"] as? JsonPrimitive)?.content
            ?: arguments["targetTabId"]?.let { (it as? JsonPrimitive)?.content }
        val context = com.webreverse.mcp.core.mcp.ToolContext(
            sessionId = sessionId,
            clientId = sessionId,
            tabId = tabId,
            agentName = agentName,
            deadline = System.currentTimeMillis() + tool.metadata.timeoutMs,
        )

        return try {
            val result = withTimeout(tool.metadata.timeoutMs) {
                tool.execute(context, arguments)
            }

            if (result.isError) {
                // 标准 CallToolResult：content + isError（错误详情通过 content 文本传达）
                JsonRpcResponse.success(
                    id = id,
                    result = buildJsonObject {
                        put("isError", JsonPrimitive(true))
                        put("content", JsonArray(result.content.map { c ->
                            buildJsonObject {
                                put("type", JsonPrimitive(c.type))
                                val t = c.text
                                if (t != null) put("text", JsonPrimitive(t))
                                val mt = c.mimeType
                                if (mt != null) put("mimeType", JsonPrimitive(mt))
                                val d = c.data
                                if (d != null) put("data", JsonPrimitive(d))
                            }
                        }))
                    },
                )
            } else {
                JsonRpcResponse.success(
                    id = id,
                    result = buildJsonObject {
                        put("content", JsonArray(result.content.map { c ->
                            buildJsonObject {
                                put("type", JsonPrimitive(c.type))
                                val t = c.text
                                if (t != null) put("text", JsonPrimitive(t))
                                val mt = c.mimeType
                                if (mt != null) put("mimeType", JsonPrimitive(mt))
                                val d = c.data
                                if (d != null) put("data", JsonPrimitive(d))
                            }
                        }))
                        val structured = result.structuredContent
                        if (structured != null) {
                            put("structuredContent", structured)
                        }
                    },
                )
            }
        } catch (e: TimeoutCancellationException) {
            JsonRpcResponse.error(id, JsonRpcErrorCode.TIMEOUT, "Tool execution timed out: $name")
        } catch (e: Exception) {
            logger.e(LogCategory.MCP, "Tool 执行失败: $name - ${e.message}", e)
            JsonRpcResponse.error(id, JsonRpcErrorCode.TOOL_EXECUTION_ERROR, e.message ?: "Unknown error")
        }
    }

    private fun handleResourcesList(id: JsonElement): JsonRpcResponse {
        val resources = resourceProvider.list().map { r ->
            buildJsonObject {
                put("uri", JsonPrimitive(r.uri))
                put("name", JsonPrimitive(r.name))
                put("description", JsonPrimitive(r.description))
                put("mimeType", JsonPrimitive(r.mimeType))
            }
        }
        return JsonRpcResponse.success(
            id = id,
            result = buildJsonObject {
                put("resources", JsonArray(resources))
            },
        )
    }

    private suspend fun handleResourcesRead(id: JsonElement, params: JsonObject): JsonRpcResponse {
        val uri = params["uri"]?.let { (it as? JsonPrimitive)?.content } ?: ""
        if (uri.isBlank()) {
            return JsonRpcResponse.error(id, JsonRpcErrorCode.INVALID_PARAMS, "Missing resource uri")
        }

        val resource = resourceProvider.get(uri)
        if (resource == null) {
            return JsonRpcResponse.error(id, JsonRpcErrorCode.METHOD_NOT_FOUND, "Resource not found: $uri")
        }

        return try {
            val content = resource.read()
            JsonRpcResponse.success(
                id = id,
                result = buildJsonObject {
                    put("contents", JsonArray(listOf(
                        buildJsonObject {
                            put("uri", JsonPrimitive(content.uri))
                            put("mimeType", JsonPrimitive(content.mimeType))
                            val text = content.text
                            if (text != null) put("text", JsonPrimitive(text))
                            val blob = content.blob
                            if (blob != null) put("blob", JsonPrimitive(blob))
                        },
                    )))
                },
            )
        } catch (e: Exception) {
            JsonRpcResponse.error(id, JsonRpcErrorCode.INTERNAL_ERROR, "Failed to read resource: ${e.message}")
        }
    }

    private fun handleResourcesTemplatesList(id: JsonElement): JsonRpcResponse {
        val templates = resourceProvider.listTemplates().map { t ->
            buildJsonObject {
                put("uriTemplate", JsonPrimitive(t.uriTemplate))
                put("name", JsonPrimitive(t.name))
                put("description", JsonPrimitive(t.description))
                put("mimeType", JsonPrimitive(t.mimeType))
            }
        }
        return JsonRpcResponse.success(
            id = id,
            result = buildJsonObject {
                put("resourceTemplates", JsonArray(templates))
            },
        )
    }

    private fun handlePromptsList(id: JsonElement): JsonRpcResponse {
        val prompts = promptProvider.list().map { p ->
            buildJsonObject {
                put("name", JsonPrimitive(p.name))
                put("description", JsonPrimitive(p.description))
                put("arguments", JsonArray(p.arguments.map { a ->
                    buildJsonObject {
                        put("name", JsonPrimitive(a.name))
                        put("description", JsonPrimitive(a.description))
                        put("required", JsonPrimitive(a.required))
                    }
                }))
            }
        }
        return JsonRpcResponse.success(
            id = id,
            result = buildJsonObject {
                put("prompts", JsonArray(prompts))
            },
        )
    }

    private suspend fun handlePromptsGet(id: JsonElement, params: JsonObject): JsonRpcResponse {
        val name = params["name"]?.let { (it as? JsonPrimitive)?.content } ?: ""
        val arguments = params["arguments"] as? JsonObject
        val args = arguments?.entries?.associate { (k, v) -> k to (v as? JsonPrimitive)?.content.orEmpty() } ?: emptyMap()

        if (name.isBlank()) {
            return JsonRpcResponse.error(id, JsonRpcErrorCode.INVALID_PARAMS, "Missing prompt name")
        }

        val prompt = promptProvider.get(name)
        if (prompt == null) {
            return JsonRpcResponse.error(id, JsonRpcErrorCode.METHOD_NOT_FOUND, "Prompt not found: $name")
        }

        return try {
            val result = prompt.get(args)
            JsonRpcResponse.success(
                id = id,
                result = buildJsonObject {
                    put("description", JsonPrimitive(result.description))
                    put("messages", JsonArray(result.messages.map { m ->
                        buildJsonObject {
                            put("role", JsonPrimitive(m.role))
                            put("content", buildJsonObject {
                                put("type", JsonPrimitive(m.content.type))
                                put("text", JsonPrimitive(m.content.text))
                            })
                        }
                    }))
                },
            )
        } catch (e: Exception) {
            JsonRpcResponse.error(id, JsonRpcErrorCode.INTERNAL_ERROR, "Failed to get prompt: ${e.message}")
        }
    }

    private fun handleCompletion(id: JsonElement, params: JsonObject): JsonRpcResponse {
        // 简易 completion 实现
        return JsonRpcResponse.success(id, buildJsonObject {
            put("completion", buildJsonObject {
                put("values", JsonArray(emptyList()))
                put("total", JsonPrimitive(0))
            })
        })
    }
}