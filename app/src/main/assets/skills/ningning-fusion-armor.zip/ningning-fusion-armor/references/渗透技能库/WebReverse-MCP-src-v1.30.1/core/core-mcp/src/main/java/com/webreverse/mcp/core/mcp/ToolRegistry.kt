package com.webreverse.mcp.core.mcp

/** MCP 工具注册表 */
class ToolRegistry {
    private val tools = LinkedHashMap<String, McpTool>()

    @Synchronized
    fun register(tool: McpTool): ToolRegistry {
        tools[tool.metadata.name] = tool
        return this
    }

    @Synchronized
    fun registerAll(tools: List<McpTool>): ToolRegistry {
        tools.forEach { register(it) }
        return this
    }

    @Synchronized
    fun unregister(name: String): Boolean = tools.remove(name) != null

    @Synchronized
    fun get(name: String): McpTool? = tools[name]

    @Synchronized
    fun list(): List<McpTool> = tools.values.toList()

    @Synchronized
    fun listMetadata(): List<ToolMetadata> = tools.values.map { it.metadata }

    @Synchronized
    fun count(): Int = tools.size

    @Synchronized
    fun clear() = tools.clear()

    @Synchronized
    fun byCategory(category: ToolCategory): List<McpTool> =
        tools.values.filter { it.metadata.category == category }
}
