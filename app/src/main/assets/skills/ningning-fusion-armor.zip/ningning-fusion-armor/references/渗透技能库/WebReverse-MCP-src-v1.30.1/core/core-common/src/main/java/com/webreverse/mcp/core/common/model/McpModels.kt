package com.webreverse.mcp.core.common.model

import kotlinx.serialization.Serializable

/** MCP 客户端 */
@Serializable
data class McpClient(
    val id: String,
    val name: String,
    val transport: String,
    val remoteAddress: String,
    val connectedAt: Long = System.currentTimeMillis(),
    val lastActiveAt: Long = System.currentTimeMillis(),
    val protocolVersion: String = "2025-03-26",
    val capabilities: List<String> = emptyList(),
)

/** MCP 会话 */
@Serializable
data class McpSession(
    val id: String,
    val clientId: String,
    val clientName: String,
    val startedAt: Long = System.currentTimeMillis(),
    val endedAt: Long? = null,
    val toolCallCount: Int = 0,
    val status: McpSessionStatus = McpSessionStatus.ACTIVE,
)

@Serializable
enum class McpSessionStatus { ACTIVE, CLOSED, ERROR }

/** Tool 调用记录 */
@Serializable
data class ToolCallRecord(
    val id: String,
    val sessionId: String,
    val toolName: String,
    val arguments: String = "",
    val result: String = "",
    val isError: Boolean = false,
    val errorCode: String? = null,
    val durationMs: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
)

/** MCP Server 配置 */
@Serializable
data class McpServerConfig(
    val host: String = "127.0.0.1",
    val port: Int = 8787,
    val enabled: Boolean = false,
    val lanOnly: Boolean = true,
    val ipAllowlist: List<String> = emptyList(),
    val maxConnections: Int = 16,
    val transportHttp: Boolean = true,
    val transportWebSocket: Boolean = true,
    val transportSse: Boolean = true,
    val transportStdio: Boolean = false,
    /**
     * 是否强制 Token 认证（P0-1 安全）。
     * - true：所有 HTTP / SSE / WS 入口必须携带合法 Token，否则 401，防止局域网暴露
     *   Browser / Debugger / Hook / Filesystem 权限链。
     * - false：仅当请求携带 Token 时校验（兼容不支持的客户端）。
     * 若此字段为 null，则根据 host 自动决定：绑定非回环地址（0.0.0.0 / 192.* 等）时默认要求认证。
     */
    val requireAuth: Boolean? = null,
    /** 每客户端每分钟最大请求数（P0-1 速率限制，0 表示不限制） */
    val rateLimitPerMinute: Int = 0,
)
