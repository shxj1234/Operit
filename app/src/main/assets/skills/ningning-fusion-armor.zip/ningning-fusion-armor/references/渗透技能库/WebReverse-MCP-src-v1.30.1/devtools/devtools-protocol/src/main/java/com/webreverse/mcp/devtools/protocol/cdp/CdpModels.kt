package com.webreverse.mcp.devtools.protocol.cdp

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject

/**
 * Chrome DevTools Protocol 基础模型。
 *
 * 本模块提供真实 CDP 接入能力：
 * WebView.setWebContentsDebuggingEnabled(true) 后，Chromium 会在进程内创建
 * abstract unix socket `webview_devtools_remote_<pid>`，通过该 socket 可完成
 * HTTP /json/list 发现页面，再升级为 WebSocket 会话，收发 CDP JSON-RPC 消息。
 * 这是真实 V8 Debugger 能力（而非 evaluateJavascript 模拟）的传输基础。
 */

/** CDP 事件（method + params） */
data class CdpEvent(
    val method: String,
    val params: JsonObject,
)

/** CDP 会话异常 */
class CdpException(message: String) : Exception(message)

/** DevTools /json/list 返回的页面描述符 */
@Serializable
data class DevToolsPageInfo(
    val id: String = "",
    val type: String = "page",
    val title: String = "",
    val url: String = "",
    val webSocketDebuggerUrl: String = "",
    val description: String = "",
    val faviconUrl: String = "",
    val devtoolsFrontendUrl: String = "",
)

/** 已解析脚本（Debugger.scriptParsed） */
@Serializable
data class CdpScript(
    val scriptId: String,
    val url: String,
    val startLine: Int = 0,
    val endLine: Int = 0,
    val sourceMapUrl: String? = null,
    val hasSourceURL: Boolean = false,
    val length: Long = 0,
)
