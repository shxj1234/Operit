package com.webreverse.mcp.javascript.analysis

import com.webreverse.mcp.core.common.model.ApiEndpoint
import com.webreverse.mcp.javascript.parser.JsParser
import kotlinx.serialization.Serializable

/** API 发现结果 */
@Serializable
data class ApiDiscoveryResult(
    val endpoints: List<ApiEndpoint> = emptyList(),
    val totalSources: Int = 0,
    val totalStrings: Int = 0,
)

/**
 * API Discovery Engine：
 * 从 HTML / JS / SourceMap / Network / Runtime 提取 API Endpoint、Method、调用者等。
 */
class ApiDiscoveryEngine(private val parser: JsParser = JsParser()) {

    private val apiPathPattern = Regex("""["'](/[A-Za-z0-9_\-./{}?=&%]+)["']""")
    private val apiUrlPattern = Regex("""(https?://[A-Za-z0-9_.\-]+(?::\d+)?(/[A-Za-z0-9_\-./{}?=&%]*))""")

    /** 从 JS 源码中发现 API */
    fun discoverFromJs(source: String, sourceName: String = "inline"): ApiDiscoveryResult {
        val endpoints = mutableListOf<ApiEndpoint>()
        val strings = parser.extractStrings(source)
        val calls = parser.extractCallExpressions(source)

        // 从字符串字面量中发现路径
        strings.forEach { s ->
            val pathMatch = apiPathPattern.find("\"$s\"")
            if (pathMatch != null) {
                val path = pathMatch.groupValues[1]
                if (looksLikeApiPath(path)) {
                    endpoints.add(
                        ApiEndpoint(
                            method = inferMethod(s, calls),
                            url = path,
                            source = sourceName,
                            caller = findCallerForString(source, s),
                            confidence = 0.7,
                        )
                    )
                }
            }
        }

        // 从 fetch/XHR/axios 调用中发现
        calls.forEach { call ->
            val callee = call.callee.lowercase()
            if (callee.contains("fetch") || callee.contains("axios") ||
                callee.contains("request") || callee.contains("post") ||
                callee.contains("get") || callee.contains("put") ||
                callee.contains("delete") || callee.contains("patch")
            ) {
                call.arguments.forEach { arg ->
                    val clean = arg.trim('"', '\'', '`')
                    if (clean.startsWith("/") || clean.startsWith("http")) {
                        endpoints.add(
                            ApiEndpoint(
                                method = inferMethodFromCallee(callee),
                                url = clean,
                                source = sourceName,
                                line = call.line,
                                caller = callee,
                                confidence = 0.85,
                            )
                        )
                    }
                }
            }
        }

        // 去重
        val deduped = endpoints
            .groupBy { "${it.method} ${it.url}" }
            .map { (_, list) -> list.maxBy { it.confidence } }
            .sortedBy { it.url }

        return ApiDiscoveryResult(
            endpoints = deduped,
            totalSources = 1,
            totalStrings = strings.size,
        )
    }

    /** 从 HTML 源码中发现 */
    fun discoverFromHtml(html: String, sourceName: String = "html"): ApiDiscoveryResult {
        val endpoints = mutableListOf<ApiEndpoint>()
        apiUrlPattern.findAll(html).forEach { m ->
            val url = m.groupValues[1]
            if (looksLikeApiPath(url)) {
                endpoints.add(
                    ApiEndpoint(method = "GET", url = url, source = sourceName, confidence = 0.5)
                )
            }
        }
        val deduped = endpoints.groupBy { it.url }.map { (_, list) -> list.first() }
        return ApiDiscoveryResult(endpoints = deduped, totalSources = 1)
    }

    /** 从网络条目中发现 */
    fun discoverFromNetwork(entries: List<com.webreverse.mcp.core.common.model.NetworkEntry>): ApiDiscoveryResult {
        val endpoints = entries
            .filter { it.resourceType == com.webreverse.mcp.core.common.model.ResourceType.XHR ||
                it.resourceType == com.webreverse.mcp.core.common.model.ResourceType.FETCH }
            .map { entry ->
                ApiEndpoint(
                    method = entry.method.wire,
                    url = entry.url,
                    source = entry.initiator,
                    requestBody = entry.requestBody.orEmpty(),
                    responseBody = entry.responseBody.orEmpty(),
                    confidence = 0.9,
                )
            }
            .groupBy { "${it.method} ${it.url}" }
            .map { (_, list) -> list.first() }
        return ApiDiscoveryResult(endpoints = endpoints, totalSources = entries.size)
    }

    /** 合并多个来源 */
    fun merge(vararg results: ApiDiscoveryResult): ApiDiscoveryResult {
        val all = results.flatMap { it.endpoints }
        val deduped = all
            .groupBy { "${it.method} ${it.url}" }
            .map { (_, list) -> list.maxBy { it.confidence } }
            .sortedBy { it.url }
        return ApiDiscoveryResult(
            endpoints = deduped,
            totalSources = results.sumOf { it.totalSources },
            totalStrings = results.sumOf { it.totalStrings },
        )
    }

    private fun looksLikeApiPath(path: String): Boolean {
        if (path.length < 4) return false
        if (path.contains(".js") || path.contains(".css") || path.contains(".png") ||
            path.contains(".jpg") || path.contains(".svg") || path.contains(".ico") ||
            path.contains(".woff") || path.contains(".gif") || path.contains(".webp")
        ) return false
        return path.startsWith("/api") || path.contains("/api/") ||
            path.contains("login") || path.contains("auth") || path.contains("token") ||
            path.contains("user") || path.contains("config") || path.contains("v1/") ||
            path.contains("v2/") || path.contains("graphql") || path.contains("query")
    }

    private fun inferMethod(string: String, calls: List<com.webreverse.mcp.javascript.parser.CallExpressionInfo>): String {
        val lower = string.lowercase()
        return when {
            lower.contains("login") || lower.contains("register") || lower.contains("submit") -> "POST"
            lower.contains("delete") || lower.contains("remove") -> "DELETE"
            lower.contains("update") || lower.contains("edit") || lower.contains("save") -> "PUT"
            lower.contains("create") || lower.contains("add") -> "POST"
            else -> "GET"
        }
    }

    private fun inferMethodFromCallee(callee: String): String {
        val lower = callee.lowercase()
        return when {
            lower.contains("post") -> "POST"
            lower.contains("put") -> "PUT"
            lower.contains("delete") -> "DELETE"
            lower.contains("patch") -> "PATCH"
            else -> "GET"
        }
    }

    private fun findCallerForString(source: String, target: String): String {
        val idx = source.indexOf(target)
        if (idx < 0) return ""
        val start = maxOf(0, idx - 200)
        val context = source.substring(start, idx)
        val funcRegex = Regex("""(?:function\s+([A-Za-z_$][A-Za-z0-9_$]*)|([A-Za-z_$][A-Za-z0-9_$]*)\s*=\s*(?:async\s*)?(?:function|\([^)]*\)\s*=>))""")
        val matches = funcRegex.findAll(context).toList()
        return matches.lastOrNull()?.groupValues?.firstOrNull { it.isNotBlank() } ?: ""
    }
}
