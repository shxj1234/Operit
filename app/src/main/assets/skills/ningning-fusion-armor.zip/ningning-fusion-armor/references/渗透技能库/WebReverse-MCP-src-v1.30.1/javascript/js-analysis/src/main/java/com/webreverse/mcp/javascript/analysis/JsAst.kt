package com.webreverse.mcp.javascript.analysis

/**
 * JS 结构化 AST 模型（面向逆向的轻量级递归下降产物）。
 *
 * 覆盖逆向分析最常用的一批语法：
 * 函数声明/表达式、var/let/const 声明、if/for/while/switch/return、调用、成员访问、
 * 赋值（含复合赋值）、二元/一元运算。全部纯 Kotlin、无第三方依赖，供
 * [JsAstParser]（解析）、[JsCfgBuilder]（控制流图）与 [JsDfgAnalyzer]（数据流）共用。
 */

/** 源码位置（1 基行/列 + 字符偏移） */
data class SourcePos(val line: Int, val col: Int, val offset: Int) {
    companion object {
        val NONE = SourcePos(0, 0, -1)
    }
}

/** 表达式基类 */
sealed class Expr {
    abstract val pos: SourcePos

    data class Identifier(val name: String, override val pos: SourcePos) : Expr()
    data class Number(val value: String, override val pos: SourcePos) : Expr()
    data class StringLit(val value: String, override val pos: SourcePos) : Expr()
    data class BoolLit(val value: Boolean, override val pos: SourcePos) : Expr()
    data class NullLit(override val pos: SourcePos) : Expr()
    data class UndefinedLit(override val pos: SourcePos) : Expr()
    data class ThisRef(override val pos: SourcePos) : Expr()

    /** 函数表达式：function (name)?(params){body} 或 (params)=>body */
    data class FunctionExpr(
        val name: String?,
        val params: List<String>,
        val body: Stmt.Block,
        val isArrow: Boolean = false,
        override val pos: SourcePos,
    ) : Expr()

    /** 成员访问：obj.prop / obj[expr] */
    data class Member(val obj: Expr, val property: String?, val computed: Expr?, override val pos: SourcePos) : Expr()

    /** 调用：callee(args) */
    data class Call(val callee: Expr, val args: List<Expr>, override val pos: SourcePos) : Expr()

    /** 赋值：target (=|+=|...) value */
    data class Assign(val target: Expr, val op: String, val value: Expr, override val pos: SourcePos) : Expr()

    /** 二元运算 */
    data class Binary(val left: Expr, val op: String, val right: Expr, override val pos: SourcePos) : Expr()

    /** 条件（三元）运算 cond ? a : b */
    data class Conditional(val test: Expr, val consequent: Expr, val alternate: Expr, override val pos: SourcePos) : Expr()

    /** 一元运算 */
    data class Unary(val op: String, val operand: Expr, override val pos: SourcePos) : Expr()

    /** 数组字面量 [a, b] */
    data class ArrayLit(val elements: List<Expr>, override val pos: SourcePos) : Expr()

    /** 对象字面量 {k:v, ...} */
    data class ObjectLit(val props: List<ObjectProperty>, override val pos: SourcePos) : Expr()
}

/** 对象属性 {k: v} */
data class ObjectProperty(val key: String, val value: Expr?, val pos: SourcePos)

/** 语句基类 */
sealed class Stmt {
    abstract val pos: SourcePos

    /** 变量声明 var/let/const name = init */
    data class VarDecl(val kind: String, val name: String, val init: Expr?, override val pos: SourcePos) : Stmt()

    /** 表达式语句 */
    data class ExprStmt(val expr: Expr, override val pos: SourcePos) : Stmt()

    /** if (cond) then [else elseStmt] */
    data class If(val cond: Expr, val thenBody: Stmt, val elseBody: Stmt?, override val pos: SourcePos) : Stmt()

    /** for(init; cond; update) body */
    data class For(
        val init: Stmt?,
        val cond: Expr?,
        val update: Expr?,
        val body: Stmt,
        override val pos: SourcePos,
    ) : Stmt()

    /** for(left in/of obj) body */
    data class ForEach(
        val left: Expr,
        val obj: Expr,
        val body: Stmt,
        val of: Boolean = false,
        override val pos: SourcePos,
    ) : Stmt()

    /** while(cond) body */
    data class While(val cond: Expr, val body: Stmt, override val pos: SourcePos) : Stmt()

    /** do body while(cond); */
    data class DoWhile(val body: Stmt, val cond: Expr, override val pos: SourcePos) : Stmt()

    /** switch(disc){ cases } */
    data class Switch(val disc: Expr, val cases: List<SwitchCase>, override val pos: SourcePos) : Stmt()

    /** return [arg] */
    data class Return(val arg: Expr?, override val pos: SourcePos) : Stmt()

    /** { stmts } */
    data class Block(val stmts: List<Stmt>, override val pos: SourcePos) : Stmt()

    data class Break(override val pos: SourcePos) : Stmt()
    data class Continue(override val pos: SourcePos) : Stmt()
    data class Throw(val arg: Expr?, override val pos: SourcePos) : Stmt()
    data class EmptyStmt(override val pos: SourcePos) : Stmt()
}

/** switch 的 case 分支 */
data class SwitchCase(val test: Expr?, val body: List<Stmt>, val pos: SourcePos)

/** 函数（含箭头/异步） */
data class JsFunction(
    val name: String,
    val params: List<String>,
    val body: Stmt.Block,
    val pos: SourcePos,
    val isArrow: Boolean = false,
    val isAsync: Boolean = false,
)

/** 顶层基类 */
sealed class TopLevel {
    abstract val pos: SourcePos

    /** 顶层函数声明 */
    data class Function(val fn: JsFunction, override val pos: SourcePos) : TopLevel()

    /** 顶层普通语句 */
    data class Statement(val stmt: Stmt, override val pos: SourcePos) : TopLevel()
}

/** 整个源码程序 */
data class Program(val body: List<TopLevel>, val source: String)

/** 程序辅助工具：以字符串形式渲染表达式/语句（供 CFG/DFG 输出可读标签） */
object AstRender {
    fun expr(e: Expr?): String = when (e) {
        null -> ""
        is Expr.Identifier -> e.name
        is Expr.Number -> e.value
        is Expr.StringLit -> "\"${e.value}\""
        is Expr.BoolLit -> e.value.toString()
        is Expr.NullLit -> "null"
        is Expr.UndefinedLit -> "undefined"
        is Expr.ThisRef -> "this"
        is Expr.FunctionExpr -> (e.name ?: "function") + "()"
        is Expr.Member -> when {
            e.computed != null -> "${expr(e.obj)}[${expr(e.computed)}]"
            else -> "${expr(e.obj)}.${e.property ?: "?"}"
        }
        is Expr.Call -> "${expr(e.callee)}(${e.args.joinToString(", ") { expr(it) }})"
        is Expr.Assign -> "${expr(e.target)} ${e.op} ${expr(e.value)}"
        is Expr.Binary -> "${expr(e.left)} ${e.op} ${expr(e.right)}"
        is Expr.Conditional -> "${expr(e.test)} ? ${expr(e.consequent)} : ${expr(e.alternate)}"
        is Expr.Unary -> "${e.op}${expr(e.operand)}"
        is Expr.ArrayLit -> "[${e.elements.joinToString(", ") { expr(it) }}]"
        is Expr.ObjectLit -> "{${e.props.joinToString(", ") { "${it.key}${if (it.value != null) ":${expr(it.value)}" else ""}" }}}"
    }

    fun stmt(s: Stmt?): String = when (s) {
        null -> ""
        is Stmt.VarDecl -> "${s.kind} ${s.name}${if (s.init != null) " = ${expr(s.init)}" else ""}"
        is Stmt.ExprStmt -> expr(s.expr)
        is Stmt.If -> "if (${expr(s.cond)})"
        is Stmt.For -> "for (...)"
        is Stmt.ForEach -> "for (${expr(s.left)} ${if (s.of) "of" else "in"} ${expr(s.obj)})"
        is Stmt.While -> "while (${expr(s.cond)})"
        is Stmt.DoWhile -> "do"
        is Stmt.Switch -> "switch (${expr(s.disc)})"
        is Stmt.Return -> if (s.arg != null) "return ${expr(s.arg)}" else "return"
        is Stmt.Block -> "{...}"
        is Stmt.Break -> "break"
        is Stmt.Continue -> "continue"
        is Stmt.Throw -> "throw ${if (s.arg != null) expr(s.arg) else ""}"
        is Stmt.EmptyStmt -> ";"
    }
}