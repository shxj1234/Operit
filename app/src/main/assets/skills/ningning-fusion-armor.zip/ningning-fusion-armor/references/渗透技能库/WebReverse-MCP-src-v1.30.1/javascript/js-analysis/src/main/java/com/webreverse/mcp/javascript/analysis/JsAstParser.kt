package com.webreverse.mcp.javascript.analysis

/**
 * 递归下降 JavaScript 解析器。
 *
 * 输出与 [JsAst.kt] 匹配的 [Program]（[TopLevel] 序列）。
 * 已覆盖语法：
 *  - 函数：`function 声明`、`function 表达式`、`箭头函数`（含 async）
 *  - 声明：`var/let/const`
 *  - 流程：`if/else`、`for`、`for-in/of`、`while`、`do-while`、`switch-case`、`return`
 *  - 表达式：调用、成员访问（`.` / `[]`）、赋值（含复合）、二元/一元运算、数组/对象字面量
 *
 * 纯 Kotlin、零依赖；遇无法识别的方言时采用「尽量恢复」策略（跳过括号到可恢复点），
 * 不追求 100% 合规，面向逆向足够稳定。
 */
class JsAstParser {

    // ---------------- 词法 ----------------

    private enum class Tk { IDENT, NUMBER, STRING, OP, EOF }

    private data class Tok(val kind: Tk, val text: String, val line: Int, val col: Int, val off: Int)

    private val keywords = setOf(
        "var", "let", "const", "function", "return", "if", "else", "for", "while",
        "do", "switch", "case", "default", "break", "continue", "new", "this", "typeof",
        "in", "of", "instanceof", "try", "catch", "finally", "throw", "class", "extends", "super",
        "import", "export", "async", "await", "yield", "delete", "void", "null", "true", "false",
        "undefined", "debugger",
    )

    private val multiOps = listOf(
        ">>>=", "===", "!==", ">>>", "<<=", ">>=", "**=", "&&=", "||=", "??=",
        "=>", "==", "!=", "<=", ">=", "&&", "||", "++", "--", "+=", "-=", "*=", "/=",
        "**", "??", "?.", "<<", ">>", "&=", "|=", "^=", "%=",
    )

    private fun tokenize(source: String): List<Tok> {
        val out = mutableListOf<Tok>()
        var i = 0
        var line = 1
        var col = 1
        val n = source.length
        while (i < n) {
            val c = source[i]
            when {
                c == '\n' -> { i++; line++; col = 1 }
                c.isWhitespace() -> { i++; col++ }
                c == '/' && i + 1 < n && source[i + 1] == '/' -> {
                    while (i < n && source[i] != '\n') { i++; col++ }
                }
                c == '/' && i + 1 < n && source[i + 1] == '*' -> {
                    i += 2; col += 2
                    while (i + 1 < n && !(source[i] == '*' && source[i + 1] == '/')) {
                        if (source[i] == '\n') { line++; col = 1 } else col++
                        i++
                    }
                    if (i + 1 < n) { i += 2; col += 2 }
                }
                c == '"' || c == '\'' || c == '`' -> {
                    val sep = c
                    val startOff = i; val startLine = line; val startCol = col
                    i++; col++
                    val sb = StringBuilder()
                    while (i < n && source[i] != sep) {
                        if (source[i] == '\\' && i + 1 < n) {
                            sb.append(source[i]).append(source[i + 1]); i += 2; col += 2
                        } else {
                            if (source[i] == '\n') { line++; col = 1 } else col++
                            sb.append(source[i]); i++
                        }
                    }
                    if (i < n) { i++; col++ }
                    out.add(Tok(Tk.STRING, sb.toString(), startLine, startCol, startOff))
                }
                c.isLetter() || c == '_' || c == '$' -> {
                    val startOff = i; val startLine = line; val startCol = col
                    val sb = StringBuilder()
                    while (i < n && (source[i].isLetterOrDigit() || source[i] == '_' || source[i] == '$')) {
                        sb.append(source[i]); i++; col++
                    }
                    out.add(Tok(Tk.IDENT, sb.toString(), startLine, startCol, startOff))
                }
                c.isDigit() || (c == '.' && i + 1 < n && source[i + 1].isDigit()) -> {
                    val startOff = i; val startLine = line; val startCol = col
                    val sb = StringBuilder()
                    while (i < n && (source[i].isDigit() || source[i] == '.' ||
                                source[i].let { it in 'a'..'f' || it in 'A'..'F' || it == 'x' || it == 'X' || it == 'b' || it == 'B' || it == 'e' || it == 'E' })
                    ) { sb.append(source[i]); i++; col++ }
                    out.add(Tok(Tk.NUMBER, sb.toString(), startLine, startCol, startOff))
                }
                else -> {
                    // 运算符 / 标点
                    var matched = false
                    for (op in multiOps) {
                        if (source.startsWith(op, i)) {
                            out.add(Tok(Tk.OP, op, line, col, i))
                            i += op.length; col += op.length
                            matched = true
                            break
                        }
                    }
                    if (!matched) {
                        out.add(Tok(Tk.OP, c.toString(), line, col, i))
                        i++; col++
                    }
                }
            }
        }
        out.add(Tok(Tk.EOF, "", line, col, n))
        return out
    }

    // ---------------- 解析器 ----------------

    private class Parser(private val toks: List<Tok>, private val source: String) {
        private var p = 0

        fun peek() = toks[p]
        fun next() = toks[p++]
        fun at(text: String): Boolean = peek().text == text
        fun eat(text: String): Boolean = if (at(text)) { next(); true } else false

        fun expect(text: String): Tok {
            if (!at(text)) throw IllegalStateException("期望 '$text'，实际 '${peek().text}' @${peek().line}")
            return next()
        }

        fun pos(t: Tok) = SourcePos(t.line, t.col, t.off)

        // ---- 顶层 ----
        fun parseProgram(): Program {
            val items = mutableListOf<TopLevel>()
            while (peek().kind != Tk.EOF) {
                val tl = try {
                    parseTopLevel()
                } catch (e: Exception) {
                    recoverStatement()
                    null
                }
                if (tl != null) items.add(tl)
            }
            return Program(items, source)
        }

        private fun recoverStatement() {
            // 跳过到下一个可恢复点（; 或成对闭合的 }）
            var depth = 0
            while (peek().kind != Tk.EOF) {
                val t = next()
                when (t.text) {
                    "{", "(", "[" -> depth++
                    "}", ")", "]" -> if (depth > 0) depth-- else { p--; return }
                    ";" -> if (depth == 0) return
                }
            }
        }

        private fun parseTopLevel(): TopLevel {
            val t = peek()
            if (at("function")) {
                val fn = parseFunctionDecl()
                return TopLevel.Function(fn, fn.pos)
            }
            if (at("async") && toks[p + 1].text == "function") {
                val fn = parseFunctionDecl()
                return TopLevel.Function(fn, fn.pos)
            }
            val stmt = parseStatement()
            return TopLevel.Statement(stmt, stmt.pos)
        }

        fun parseFunctionDecl(): JsFunction {
            val start = pos(peek())
            var isAsync = false
            if (eat("async")) isAsync = true
            expect("function")
            val name = if (peek().kind == Tk.IDENT) next().text else ""
            val params = parseParams()
            val body = parseBlock()
            return JsFunction(name, params, body, start, isArrow = false, isAsync = isAsync)
        }

        private fun parseParams(): List<String> {
            expect("(")
            val out = mutableListOf<String>()
            while (!at(")")) {
                if (peek().kind == Tk.IDENT) out.add(next().text)
                else if (at("...")) { next(); if (peek().kind == Tk.IDENT) out.add(next().text) }
                else if (peek().kind == Tk.OP) next() // 跳过 {a,b} / default 等干扰
                if (!eat(",")) break
            }
            expect(")")
            return out
        }

        private fun parseBlock(): Stmt.Block {
            val bpos = pos(peek())
            expect("{")
            val stmts = mutableListOf<Stmt>()
            while (!at("}")) {
                if (peek().kind == Tk.EOF) break
                try {
                    stmts.add(parseStatement())
                } catch (e: Exception) {
                    recoverStatement()
                }
            }
            expect("}")
            return Stmt.Block(stmts, bpos)
        }

        // ---- 语句 ----
        fun parseStatement(): Stmt {
            val t = peek()
            return when {
                at(";") -> { next(); Stmt.EmptyStmt(pos(t)) }
                at("{") -> parseBlock()
                at("var") || at("let") || at("const") -> parseVarDecl()
                at("function") -> {
                    val fn = parseFunctionDecl()
                    Stmt.ExprStmt(Expr.FunctionExpr(fn.name.ifEmpty { null }, fn.params, fn.body, false, funExprPos(fn)), fn.pos)
                }
                at("if") -> parseIf()
                at("for") -> parseFor()
                at("while") -> parseWhile()
                at("do") -> parseDoWhile()
                at("switch") -> parseSwitch()
                at("return") -> parseReturn()
                at("break") -> { next(); eat(";"); Stmt.Break(pos(t)) }
                at("continue") -> { next(); eat(";"); Stmt.Continue(pos(t)) }
                at("throw") -> { val r = next(); val arg = if (at(";") || at("}")) null else parseExpr(); eat(";"); Stmt.Throw(arg, pos(r)) }
                at("debugger") -> { next(); eat(";"); Stmt.EmptyStmt(pos(t)) }
                at("async") && toks[p + 1].text == "function" -> {
                    val fn = parseFunctionDecl()
                    Stmt.ExprStmt(Expr.FunctionExpr(fn.name.ifEmpty { null }, fn.params, fn.body, false, funExprPos(fn)), fn.pos)
                }
                else -> {
                    val e = parseExpr()
                    eat(";")
                    Stmt.ExprStmt(e, e.pos)
                }
            }
        }

        private fun funExprPos(fn: JsFunction) = fn.pos

        private fun parseVarDecl(): Stmt {
            val kindTok = next() // var/let/const
            val kind = kindTok.text
            val vpos = pos(kindTok)
            // 支持多声明符，取第一个即可
            val name = if (peek().kind == Tk.IDENT) next().text else "?"
            var init: Expr? = null
            if (eat("=")) init = parseExpr()
            // 跳过其余声明符 , name = ...
            while (eat(",")) {
                if (peek().kind == Tk.IDENT) next()
                if (eat("=")) parseExpr()
            }
            eat(";")
            return Stmt.VarDecl(kind, name, init, vpos)
        }

        private fun parseIf(): Stmt {
            val start = pos(peek())
            expect("if")
            expect("(")
            val cond = parseExpr()
            expect(")")
            val thenBody = parseStatement()
            var elseBody: Stmt? = null
            if (eat("else")) elseBody = parseStatement()
            return Stmt.If(cond, thenBody, elseBody, start)
        }

        private fun parseFor(): Stmt {
            val start = pos(peek())
            expect("for")
            expect("(")
            // for-in/of
            if (at("var") || at("let") || at("const")) {
                val k = peek().text
                val saved = p
                next()
                if (peek().kind == Tk.IDENT) next()
                if (at("in") || at("of")) {
                    val op = next().text
                    p = saved
                    // 重新解析左值
                    next() // var/let/const
                    val lname = if (peek().kind == Tk.IDENT) next().text else "?"
                    val left = Expr.Identifier(lname, pos(toks[p - 1]))
                    next() // 消费 in/of
                    val obj = parseExpr()
                    expect(")")
                    val body = parseStatement()
                    return Stmt.ForEach(left, obj, body, of = op == "of", pos = start)
                }
                p = saved
            }
            var init: Stmt? = null
            if (!at(";")) {
                init = if (at("var") || at("let") || at("const")) parseVarDecl() else {
                    val e = parseExpr()
                    Stmt.ExprStmt(e, e.pos)
                }
            }
            eat(";")
            var cond: Expr? = null
            if (!at(";")) cond = parseExpr()
            expect(";")
            var update: Expr? = null
            if (!at(")")) update = parseExpr()
            expect(")")
            val body = parseStatement()
            return Stmt.For(init, cond, update, body, start)
        }

        private fun parseWhile(): Stmt {
            val start = pos(peek())
            expect("while")
            expect("(")
            val cond = parseExpr()
            expect(")")
            val body = parseStatement()
            return Stmt.While(cond, body, start)
        }

        private fun parseDoWhile(): Stmt {
            val start = pos(peek())
            expect("do")
            val body = parseStatement()
            expect("while")
            expect("(")
            val cond = parseExpr()
            expect(")")
            eat(";")
            return Stmt.DoWhile(body, cond, start)
        }

        private fun parseSwitch(): Stmt {
            val start = pos(peek())
            expect("switch")
            expect("(")
            val disc = parseExpr()
            expect(")")
            val cases = mutableListOf<SwitchCase>()
            var cpos = pos(peek())
            expect("{")
            var current = mutableListOf<Stmt>()
            while (!at("}")) {
                if (peek().kind == Tk.EOF) break
                if (at("case")) {
                    val c = next()
                    cases.add(SwitchCase(parseExpr(), current.toList(), cpos))
                    current = mutableListOf()
                    expect(":")
                    cpos = pos(toks[p - 1])
                } else if (at("default")) {
                    val c = next()
                    cases.add(SwitchCase(null, current.toList(), cpos))
                    current = mutableListOf()
                    expect(":")
                    cpos = pos(c)
                } else {
                    try {
                        current.add(parseStatement())
                    } catch (e: Exception) {
                        recoverStatement()
                    }
                }
            }
            cases.add(SwitchCase(null, current.toList(), cpos))
            expect("}")
            return Stmt.Switch(disc, cases, start)
        }

        private fun parseReturn(): Stmt {
            val start = pos(peek())
            expect("return")
            var arg: Expr? = null
            if (!at(";") && !at("}") && peek().kind != Tk.EOF) arg = parseExpr()
            eat(";")
            return Stmt.Return(arg, start)
        }

        // ---- 表达式（优先级爬升）----
        fun parseExpr() = parseAssign()

        private fun parseAssign(): Expr {
            val left = parseConditional()
            val t = peek()
            val assignOps = setOf("=", "+=", "-=", "*=", "/=", "%=", "**=", "<<=", ">>=", ">>>=", "&=", "|=", "^=", "&&=", "||=", "??=")
            if (t.kind == Tk.OP && t.text in assignOps) {
                next()
                val right = parseAssign()
                return Expr.Assign(left, t.text, right, left.pos)
            }
            return left
        }

        private fun parseConditional(): Expr {
            val c = parseOr()
            if (at("?")) {
                next()
                val t = parseAssign()
                expect(":")
                val f = parseAssign()
                return Expr.Conditional(c, t, f, c.pos)
            }
            return c
        }

        private fun parseOr(): Expr {
            val left = parseAnd()
            if (at("||") || at("??")) { val op = next().text; return Expr.Binary(left, op, parseOr(), left.pos) }
            return left
        }

        private fun parseAnd(): Expr {
            val left = parseBitOr()
            if (at("&&")) { next(); return Expr.Binary(left, "&&", parseAnd(), left.pos) }
            return left
        }

        private fun parseBitOr(): Expr {
            var left = parseBitXor()
            while (at("|")) { next(); val r = parseBitXor(); left = Expr.Binary(left, "|", r, left.pos) }
            return left
        }

        private fun parseBitXor(): Expr {
            var left = parseBitAnd()
            while (at("^")) { next(); val r = parseBitAnd(); left = Expr.Binary(left, "^", r, left.pos) }
            return left
        }

        private fun parseBitAnd(): Expr {
            var left = parseEquality()
            while (at("&")) { next(); val r = parseEquality(); left = Expr.Binary(left, "&", r, left.pos) }
            return left
        }

        private fun parseEquality(): Expr {
            var left = parseRelational()
            while (at("==") || at("!=") || at("===") || at("!==")) { val op = next().text; val r = parseRelational(); left = Expr.Binary(left, op, r, left.pos) }
            return left
        }

        private fun parseRelational(): Expr {
            var left = parseShift()
            while (at("<") || at(">") || at("<=") || at(">=") || at("instanceof") || at("in")) {
                val op = next().text; val r = parseShift(); left = Expr.Binary(left, op, r, left.pos)
            }
            return left
        }

        private fun parseShift(): Expr {
            var left = parseAdditive()
            while (at("<<") || at(">>") || at(">>>")) { val op = next().text; val r = parseAdditive(); left = Expr.Binary(left, op, r, left.pos) }
            return left
        }

        private fun parseAdditive(): Expr {
            var left = parseMultiplicative()
            while (at("+") || at("-")) { val op = next().text; val r = parseMultiplicative(); left = Expr.Binary(left, op, r, left.pos) }
            return left
        }

        private fun parseMultiplicative(): Expr {
            var left = parseUnary()
            while (at("*") || at("/") || at("%")) { val op = next().text; val r = parseUnary(); left = Expr.Binary(left, op, r, left.pos) }
            return left
        }

        private fun parseUnary(): Expr {
            val unaryOps = setOf("!", "~", "+", "-", "typeof", "void", "delete", "++", "--", "await")
            val t = peek()
            if (t.kind == Tk.OP && t.text in unaryOps) {
                next()
                val operand = parseUnary()
                return Expr.Unary(t.text, operand, pos(t))
            }
            if (t.kind == Tk.IDENT && t.text in unaryOps) {
                next()
                val operand = parseUnary()
                return Expr.Unary(t.text, operand, pos(t))
            }
            return parsePostfix()
        }

        private fun parsePostfix(): Expr {
            var left = parsePrimary()
            // 单参数箭头函数 x => ...
            if (left is Expr.Identifier && at("=>")) {
                next() // =>
                val body = if (at("{")) parseBlock() else Stmt.Block(listOf(Stmt.Return(parseAssign(), left.pos)), left.pos)
                return Expr.FunctionExpr(null, listOf(left.name), body, true, left.pos)
            }
            while (true) {
                when {
                    at(".") -> {
                        next()
                        val prop = if (peek().kind == Tk.IDENT) { val p = next().text; p } else if (peek().kind == Tk.STRING) next().text else { if (peek().kind != Tk.EOF) next().text else "" }
                        left = Expr.Member(left, prop, null, left.pos)
                    }
                    at("[") -> {
                        next()
                        val idx = parseExpr()
                        expect("]")
                        left = Expr.Member(left, null, idx, left.pos)
                    }
                    at("(") -> {
                        val args = parseArgs()
                        left = Expr.Call(left, args, left.pos)
                    }
                    at("++") || at("--") -> {
                        val op = next().text
                        left = Expr.Unary(op, left, left.pos)
                    }
                    else -> return left
                }
            }
        }

        private fun parseArgs(): List<Expr> {
            expect("(")
            val out = mutableListOf<Expr>()
            while (!at(")")) {
                if (peek().kind == Tk.EOF) break
                if (at("...")) next()
                try {
                    out.add(parseAssign())
                } catch (e: Exception) {
                    recoverToCommaOrParen()
                }
                if (eat(",")) continue else break
            }
            expect(")")
            return out
        }

        private fun recoverToCommaOrParen() {
            var depth = 0
            while (peek().kind != Tk.EOF) {
                val t = next()
                when (t.text) {
                    "(", "[", "{" -> depth++
                    "]", "}" -> if (depth > 0) depth-- else return
                    "," -> if (depth == 0) return
                    ")" -> if (depth == 0) { p--; return }
                }
            }
        }

        /** 前瞻：自 p（已消费 '('）起，判断以 ')' 收尾且紧跟 '=>'，即为箭头函数形参 */
        private fun looksLikeArrowParams(): Boolean {
            var i = p
            if (i >= toks.size || toks[i].kind == Tk.EOF) return false
            var depth = 0
            while (i < toks.size) {
                val tk = toks[i]
                when (tk.text) {
                    "(", "[", "{" -> depth++
                    "}", "]" -> if (depth > 0) depth--
                    ")" -> {
                        if (depth == 0) {
                            val nxt = if (i + 1 < toks.size) toks[i + 1].text else ""
                            return nxt == "=>"
                        }
                        if (depth > 0) depth--
                    }
                    else -> { /* 继续 */ }
                }
                if (depth < 0) return false
                i++
            }
            return false
        }

        private fun parsePrimary(): Expr {
            val t = peek()
            return when (t.kind) {
                Tk.NUMBER -> { next(); Expr.Number(t.text, pos(t)) }
                Tk.STRING -> { next(); Expr.StringLit(t.text, pos(t)) }
                Tk.IDENT -> {
                    next()
                    when (t.text) {
                        "true" -> Expr.BoolLit(true, pos(t))
                        "false" -> Expr.BoolLit(false, pos(t))
                        "null" -> Expr.NullLit(pos(t))
                        "undefined" -> Expr.UndefinedLit(pos(t))
                        "this" -> Expr.ThisRef(pos(t))
                        "function" -> {
                            // 函数表达式 function name(params){...}
                            val name = if (peek().kind == Tk.IDENT) next().text else ""
                            val params = parseParams()
                            val body = parseBlock()
                            Expr.FunctionExpr(name.ifEmpty { null }, params, body, false, pos(t))
                        }
                        else -> Expr.Identifier(t.text, pos(t))
                    }
                }
                Tk.OP -> {
                    when (t.text) {
                        "(" -> {
                            next() // 消费 (
                            if (looksLikeArrowParams()) {
                                // 箭头函数形参 (a, b) => {...}
                                val params = mutableListOf<String>()
                                while (!at(")")) {
                                    if (peek().kind == Tk.IDENT) params.add(next().text)
                                    else if (at("...")) { next(); if (peek().kind == Tk.IDENT) params.add(next().text) }
                                    else { if (peek().kind != Tk.EOF) next() }
                                    if (!eat(",")) break
                                }
                                expect(")")
                                if (at("=>")) {
                                    next()
                                    val body = if (at("{")) parseBlock() else Stmt.Block(listOf(Stmt.Return(parseAssign(), pos(t))), pos(t))
                                    Expr.FunctionExpr(null, params, body, true, pos(t))
                                } else Expr.UndefinedLit(pos(t))
                            } else {
                                val inner = parseAssign()
                                expect(")")
                                inner
                            }
                        }
                        "[" -> {
                            next()
                            val elems = mutableListOf<Expr>()
                            while (!at("]")) {
                                if (peek().kind == Tk.EOF) break
                                elems.add(parseAssign())
                                if (!eat(",")) break
                            }
                            expect("]")
                            Expr.ArrayLit(elems, pos(t))
                        }
                        "{" -> {
                            next()
                            val props = mutableListOf<ObjectProperty>()
                            while (!at("}")) {
                                if (peek().kind == Tk.EOF) break
                                val key = if (peek().kind == Tk.IDENT || peek().kind == Tk.STRING) next().text else "?"
                                var value: Expr? = null
                                if (eat(":")) value = parseAssign()
                                props.add(ObjectProperty(key, value, pos(toks[p - 1])))
                                if (!eat(",")) break
                            }
                            expect("}")
                            Expr.ObjectLit(props, pos(t))
                        }
                        else -> { next(); Expr.Identifier("?", pos(t)) }
                    }
                }
                Tk.EOF -> Expr.UndefinedLit(pos(t))
            }
        }
    }

    // ---------------- 入口 ----------------

    fun parse(source: String): Program {
        val toks = tokenize(source)
        return Parser(toks, source).parseProgram()
    }
}