---
name: webreverse-reverse-engineering
description: "Playbook for WebReverse MCP: 378 tools for web debugging, network interception, hooking, JSVMP/WASM analysis, and evidence graph. Invoke when reverse-engineering or analyzing any web page via the WebReverse MCP server."
---

# WebReverse MCP — AI Web Reverse Engineering Playbook

Professional operating guide for AI agents (Claude, GPT, Gemini, Cursor, etc.) connected to **WebReverse MCP** — an Android browser with a built-in MCP server (JSON-RPC 2.0, MCP 2025-03-26) exposing **378 tools** across 18 categories: real CDP debugging, full-payload network capture, runtime hooking, JSVMP bytecode analysis, WASM disassembly, and an Evidence Graph that accumulates findings across the whole session.

Use this skill whenever the task involves analyzing, debugging, instrumenting, or reverse-engineering a web page through the WebReverse MCP server.

---

## 1. System Architecture

### 1.1 Execution layers (auto-negotiated per capability)

| Layer | Mechanism | When used |
|---|---|---|
| **CDP (Chrome DevTools Protocol)** | Direct connection to the WebView's DevTools unix socket, multiplexed through an in-process **CDP reuse hub** on `127.0.0.1:9222+` | `debugger.attach`, `network.attach_cdp` establish it. Real V8 breakpoints, call stacks, scopes, request bodies, WS frames |
| **Injected JS** | `evaluateJavascript` + pre-injected hook framework (`__WRMCP_HOOK__`) | Fallback when CDP is unavailable; also powers DOM breakpoints, dynamic tracing, deobfuscation sandbox |
| **Static analysis** | Pure Kotlin parsers (JS AST, WASM binary, sourcemaps) | `js.*`, `static.*`, `wasm.*` — no page interaction needed |

**CDP reuse hub semantics**: all in-process MCP clients (debugger session, network monitor, script tools) share ONE backend CDP connection per target. Breakpoints, pauses, and network events broadcast to every session — the debugger and network tools never kick each other off. Session multiplexing is automatic; you never manage it explicitly.

### 1.2 Connection

- Transports: `POST /mcp` (HTTP), `WS /mcp/ws` (WebSocket), `GET /mcp/sse` (SSE); `GET /mcp/stats` for monitoring
- Default listen address `127.0.0.1:8787` on the device; for desktop AI access use `adb reverse tcp:8787 tcp:8787` then `http://127.0.0.1:8787/mcp`
- Token authentication via `TokenManager` (configured in-app; include token as configured by your client setup)
- Sanity check after connecting: call `mcp.status` — it reports tool count, debugger backend/state, CDP hub sessions, paused state, and an operational hint string

### 1.3 Tooling philosophy

Tools are fine-grained on purpose. The intended pattern is **pipeline first, manual chaining second**:

1. `pipeline.run` (5 built-in pipelines) already orchestrates the common end-to-end chains
2. For everything else, this skill's playbooks (Section 4) define the proven tool sequences
3. Results accumulate automatically in the **Evidence Store + Reverse Graph** (Section 3) — query it before re-collecting data you may already have

---

## 2. Risk & Permission Model

Every tool carries a risk level; prefer the lowest-risk tool that answers the question.

| Risk | Meaning | Guidance |
|---|---|---|
| **LOW** | Read-only / passive | Default choice; freely chainable |
| **MEDIUM** | Mutates page state, attaches debug sessions, or costs setup | Verify preconditions first; clean up after (`detach`, `disable`) |
| **HIGH** | Executes JS, modifies storage/network/DOM, or is hard to undo | Batch deliberately, re-verify assumptions before each call |

Permission scopes (`READ_PAGE`, `READ_DOM`, `MODIFY_PAGE`, `DEBUG_SCRIPT`, `EXECUTE_JS`, `READ_NETWORK`, `MODIFY_NETWORK`, `INSTALL_HOOK`, `READ_COOKIES`, `READ_STORAGE`, `MODIFY_STORAGE`, `READ_FILE`, `WRITE_FILE`, `SCREENSHOT`, `DOWNLOAD`, `UPLOAD`) are enforced server-side per grant. Check `mcp.permissions` if a call fails with a permission error.

**Session hygiene rules**:

- After `debugger.attach`, always `debugger.detach` when done debugging, or at minimum `debugger.resume` if paused — a paused page blocks timers, animations, and every subsequent evaluate
- Intercepted requests (`network.intercept`) pause at the network boundary: every matched request MUST be resolved (`network.resume_request` / `network.mock_response` / `network.abort_request`) or the page hangs
- Temporary hooks (`hook.*`, `dynamic.*`) should be removed after use (`hook.remove`, `dynamic.untrace_function`) to avoid contaminating later observations

---

## 3. Core Concepts

### 3.1 Evidence Store & Reverse Graph (session memory)

The EventBus automatically deposits evidence from five sources: **Network** requests, **Hook** hits, **Debugger** breakpoint pauses, **Console** errors, and **Pipeline** conclusions. Evidence feeds a persistent directed graph whose nodes are reverse-engineering subjects (ENDPOINT, FUNCTION, SCRIPT, TOKEN, CRYPTO, STORAGE, COOKIE, WEBSOCKET) connected by typed edges (CALLS, REQUESTS, GENERATES, WRITES, SIGNS, ...).

- `evidence.stats` — inventory: evidence counts by source, node/edge distribution, time range
- `evidence.query` — filter evidence by source / keyword / time window
- `graph.stats` — high-weight hub nodes = the most valuable reverse-engineering entry points
- `graph.query` — node lookup by type/keyword, or the neighborhood subgraph around a node
- `graph.link` / `evidence.record` — record YOUR inferred relationships and manual conclusions so they survive context compaction

**Always check the graph before launching new collection** — earlier steps in the session may have already answered the question.

### 3.2 Analysis Pipelines (one-call orchestration)

`pipeline.list` enumerates; `pipeline.run name=<pipeline>` executes. All results auto-write to the Evidence Store and graph.

| Pipeline | What it does | When to run |
|---|---|---|
| `recon` | Full-page reconnaissance: framework ID + API discovery + script inventory + obfuscation scan + storage census, all into the graph | First contact with any page |
| `api_trace` | Endpoint call-chain: network request → initiator stack functions → referencing scripts → obfuscation flags | "How is this API called?" |
| `token_trace` | Token provenance: scans localStorage/sessionStorage/cookies for token-like keys → referencing scripts → suggested watch points (values redacted, keys only) | Session/token lifecycle analysis |
| `crypto_link` | Crypto correlation: hooks crypto APIs, time-window matches (±3s default) hits against network requests → outputs candidate signing functions per endpoint | **Signature algorithm hunting — the core reverse workflow** |
| `snapshot` | Runtime capture: while paused, grabs call stack + locals into evidence, builds frame-chain graph edges | At any breakpoint hit |

### 3.3 Workspaces & Files

`workspace.*` tools persist findings/notes/analyses/targets as structured case files; `re.export_case` bundles workspace + page source + network chain into a Markdown report + JSON evidence pack on disk. `file.*` tools operate on the device working directory (`file.workdir`) — download big scripts/HARs there, then read/search them offline with `file.read` / `file.search` instead of pulling megabytes through tool results.

---

## 4. Standard Playbooks

### 4.1 First contact with a page

```
browser.open <url>  →  browser.wait  →  pipeline.run recon  →  graph.stats
```

Then branch: obfuscated? → §4.5. Signature on an API? → §4.2. WASM module? → §4.6.

### 4.2 Signature / crypto algorithm hunting (the core workflow)

1. `network.enable` + trigger the target action (login, submit) → `network.list` / `network.search` to find the request carrying `sign`/`token` params
2. `pipeline.run crypto_link` — time-window correlation outputs candidate signing functions per endpoint
3. Confirm dynamically WITHOUT pausing: `dynamic.trace_function <candidate>` — records args/return per call. For encryption objects: `dynamic.monitor_object` (who reads/writes the key) and `debugger.query_objects` (find all instances of the crypto class, dump their internal state)
4. Need the exact algorithm? `debugger.set_xhr_breakpoint url=<endpoint>` → trigger → `debugger.wait_breakpoint` returns the full paused snapshot; the bottom of the call stack is the signing function. `debugger.snapshot` gets stack + locals + this in one call
5. Verify: `network.intercept` → alter the `sign` param via `network.resume_request` rewrite, observe server response (validates whether the signature covers specific fields)

### 4.3 Breakpoint debugging discipline

```
debugger.attach → debugger.list_scripts → debugger.search_script <keyword>
→ debugger.get_breakable_locations (minified code: align V8 line numbers!)
→ debugger.set_breakpoint / set_source_breakpoint (original source via sourcemap)
→ trigger action → debugger.wait_breakpoint (blocks until hit, returns snapshot)
→ debugger.evaluate_on_call_frame / get_object_properties to inspect
→ debugger.step_* as needed → debugger.resume  →  debugger.detach
```

Key rules:

- **Sourcemapped bundles**: `debugger.set_source_breakpoint` accepts `src/api/sign.ts:87` and resolves through the sourcemap automatically; `debugger.resolve_position` maps runtime positions back to source
- **Minified code**: always `get_breakable_locations` before setting — V8 line numbers align to statement starts
- **Conditional mass-capture**: `set_logpoint` / `set_conditional_breakpoint` record without pausing
- **V8-accurate event/XHR pauses**: prefer `set_listener_breakpoint` / `set_xhr_breakpoint` (CDP-native) over injected equivalents
- **CPU profiling shortcut**: `debugger.cpu_profile` start → run the crypto flow → stop; the selfTime leaderboard is usually the crypto loop (`url:line` is directly breakable)

### 4.4 Network deep inspection

- Baseline capture: `network.enable` → act → `network.list`/`network.search`
- **Upgrade to CDP capture** (`network.attach_cdp`) for: all resource types, cross-origin, response bodies (`network.get_response_body`), WS frames (`network.cdp_ws_frames`), initiators (`network.initiator`), remote IPs
- **Pre-send interception** (`network.intercept`): requests pause BEFORE hitting the server — `network.paused_requests` shows full URL/method/headers/postData earlier than `network.list`; then rewrite-and-release, mock, or abort. This is the sharpest tool for testing server-side validation logic
- Environment spoofing: `network.set_user_agent` (UA override), `network.set_extra_headers` (inject trace/debug headers), `network.set_cache_disabled true` (ensure fresh server data)
- Export: `network.export_har` / `network.copy_curl` / `network.replay`

### 4.5 Obfuscated / packed JS

1. Triage: `js.detect_obfuscation` (score 0-100 + techniques), `re.detect_obfuscator`, `static.complexity` (high complexity + machine names = obfuscated core)
2. String-array obfuscation (javascript-obfuscator style): `static.decrypt_chain` identifies the array+decoder+callsites triad; `static.decrypt_resolve` restores plaintext offline; if the decoder prototype doesn't match, `static.decrypt_execute` re-executes the decoder in a page sandbox (works for RC4/custom decoders); `js.deobfuscate` folds the results back into readable source
3. Read it: `js.beautify` → `js.parse_ast` / `js.analyze_ast` → `static.callgraph` (who calls whom; use callers lookup to find entry points)
4. **JSVMP (virtual-machine obfuscation)**: `debugger.detect_vmp` locates the dispatch loop across all three obfuscator dispatch styles (while+switch / if-else-if decision tree / array-of-handlers `handlers[bc[pc++]]()`) → `debugger.trace_vmp` samples it (zero-pause conditional breakpoints) → `jsvmp.analyze` / `jsvmp.handlers` build the opcode→semantics ISA table (incl. string-op primitives fromCharCode/charCodeAt/atob) → `debugger.diff_vmp_trace` (differential vs baseline isolates the opcodes unique to your target action — fastest method in practice) → `jsvmp.decompile` / `jsvmp.trace_decompile` produce pseudocode → `jsvmp.resolve_vpc` rebuilds control flow if the pc variable is unknown. For a guided end-to-end workflow, run the `analyze_jsvmp` prompt (MCP prompt template) which chains detect→trace→analyze→decompile.
5. **Anti-debugging**: `browser.set_stealth` installs the counter-layer (native-code toString masking, debugger-statement timer filtering) BEFORE other instrumentation

### 4.6 WASM analysis

**Standard crypto flow**: `wasm.list_modules` (auto-captured at document_start) → `wasm.dump_module` (structure-level WAT: imports/exports/name-section/crypto hotspots) → `wasm.recognize_crypto` (algorithm-level identification) → `wasm.disassemble_func` (per-function pseudocode with auto string annotations + wasm-bindgen semantic labels) or `wasm.disassemble` (full wabt-engine WAT) → locate plaintext/ciphertext offsets with `wasm.inspect_memory` → patch keys/constants via `wasm.write_memory` or compile modified WAT back with `wasm.wat2wasm` and replay.

**wasm-bindgen / Rust WASM flow** (e.g. signature modules, API encryption): `wasm.list_modules` → `wasm.dump_module` (check for `__wbindgen_*` / `__wbg_*` imports → confirms wasm-bindgen) → `wasm.bindgen_skeleton` (auto-generate Node.js call skeleton with malloc/free + string helpers + import stubs) → `wasm.disassemble_func` on key exports (string constants auto-annotated, import calls semantically labeled) → use `wasm.data_at` to read any `i32.const` address pointing to data (selectors, URLs, hardcoded keys) → fill in environment stubs and replay with the skeleton.

For a guided workflow, run the `analyze_wasm_crypto` prompt (MCP prompt template).

### 4.7 Cross-session continuity

Before ending any substantial analysis: `evidence.record` your conclusions, `graph.link` your inferred relationships, `workspace.add_finding`/`save_analysis` for the case file, and `re.export_case` for a hand-off package. A fresh session starts from `evidence.stats` + `graph.stats` instead of from zero.

---
## 5. Complete Tool Reference (378 tools / 18 categories)

Risk column: **L** = LOW, **M** = MEDIUM, **H** = HIGH (see Section 2).

### 5.1 Browser (18) & Tab (14) — navigation & page lifecycle

| Tool | Risk | Description |
|---|---|---|
| `browser.open` | L | Open a URL and navigate to the page |
| `browser.go` | L | Navigate to a URL (relative paths supported) |
| `browser.back` | L | Go back in history |
| `browser.forward` | L | Go forward in history |
| `browser.reload` | L | Reload the current page |
| `browser.stop` | L | Stop loading |
| `browser.close` | L | Close the current page |
| `browser.wait` | L | Wait until the page finishes loading |
| `browser.current_url` | L | Get the current page URL |
| `browser.current_title` | L | Get the current page title |
| `browser.fullscreen` | L | Toggle fullscreen mode |
| `browser.source` | L | Get the current page HTML source |
| `browser.screenshot` | M | Capture the page (viewport / full-page / element) |
| `browser.pdf` | M | Export the current page to PDF (paginated full-page render, saved to working dir) |
| `browser.print` | L | Print the current page via the system print service (opens print UI on device) |
| `browser.download` | M | Download a file to the working directory |
| `browser.upload` | M | Inject a file into a page file-input and trigger the upload event |
| `browser.set_stealth` | M | Inject anti-anti-debug layer: masks `Function.toString` as `[native code]`, filters debugger-laden timers/Function-constructor callbacks (counters site anti-debugging). Run BEFORE other instrumentation on protected sites |
| `tab.list` | L | List all tabs |
| `tab.create` | L | Create a new tab |
| `tab.close` | L | Close a tab |
| `tab.activate` | L | Activate a tab |
| `tab.reload` | L | Reload a tab |
| `tab.mute` | L | Mute / unmute a tab |
| `tab.pin` | L | Pin / unpin a tab |
| `tab.move` | L | Move a tab's position |
| `tab.group` | L | Create a tab group |
| `tab.duplicate` | L | Duplicate a tab |
| `tab.recently_closed` | L | List recently closed tabs |
| `tab.restore` | L | Restore a recently closed tab |
| `tab.pin_session` | L | Pin the current MCP session to a tab: all tools' `activeSession()` resolve to this tab afterwards, preventing cross-tab context bleed in multi-agent scenarios (P0 context isolation) |
| `tab.unpin_session` | L | Unpin the session from the tab, resume following the active tab |

### 5.2 DOM (27)

| Tool | Risk | Description |
|---|---|---|
| `dom.query` | L | Query a single element and return its attributes |
| `dom.query_all` | L | Query all matching elements |
| `dom.get_html` | L | Get element outerHTML / innerHTML |
| `dom.get_text` | L | Get element textContent |
| `dom.get_attribute` | L | Get an element attribute |
| `dom.set_attribute` | M | Set an element attribute |
| `dom.remove_attribute` | M | Remove an element attribute |
| `dom.get_style` | L | Get computed style |
| `dom.set_style` | M | Set inline CSS style |
| `dom.get_rect` | L | Get element bounding rect |
| `dom.get_xpath` | L | Get element XPath |
| `dom.get_selector` | L | Get a unique CSS selector for the element |
| `dom.get_events` | L | Get element event listeners |
| `dom.get_box_model` | L | Get element box model |
| `dom.get_css_rules` | L | Get matching CSS rules |
| `dom.get_accessibility` | L | Get the accessibility tree |
| `dom.click` | M | Click an element |
| `dom.focus` | M | Focus an element |
| `dom.type` | M | Type text into an element |
| `dom.scroll` | L | Scroll an element |
| `dom.highlight` | L | Highlight an element (debugging aid) |
| `dom.modify` | H | Replace element outerHTML |
| `dom.remove` | H | Delete an element |
| `dom.clone` | M | Clone an element |
| `dom.document` | L | Get the full DOM document tree |
| `dom.search` | L | Search text within the DOM |
| `dom.export` | L | Export DOM as HTML |

### 5.3 JavaScript (22) — evaluation & static analysis

| Tool | Risk | Description |
|---|---|---|
| `js.evaluate` | H | Execute a JavaScript expression in the current page |
| `js.evaluate_async` | H | Execute JavaScript asynchronously (await supported) |
| `js.call_function` | H | Invoke a function in the page |
| `js.inspect` | H | Inspect an expression's type and structure |
| `js.get_global` | M | Read a global variable |
| `js.get_property` | M | Read an object property |
| `js.set_property` | H | Write an object property |
| `js.delete_property` | H | Delete an object property |
| `js.console` | L | Emit a message to the page console |
| `js.parse_ast` | L | Parse JS source into AST/token structure |
| `js.analyze_ast` | L | Analyze JS source: strings/identifiers/URLs/variables |
| `js.beautify` | L | Pretty-print JS source |
| `js.detect_obfuscation` | L | Detect obfuscation level and output a report (score 0-100) |
| `js.extract_strings` | L | Extract all strings from JS source |
| `js.extract_urls` | L | Extract all URLs from JS source |
| `js.search_source` | L | Search patterns in JS source |
| `js.find_function` | L | Find function definitions in JS source |
| `js.find_symbol` | L | Find identifiers/symbols in JS source |
| `js.detect_patterns` | L | Detect dangerous/dynamic JS patterns (eval / Function / atob ...) |
| `js.get_page_source` | M | Get all script sources of the current page |
| `js.deobfuscate` | M | Dynamic unpacking: invokes the obfuscated script's string-decoder in page context to mass-restore literals (`_0x1234('0x1a')` → `"plaintext"`), folds string concatenation, strips noise |
| `js.ast` | L | Structured AST parsing: recursive-descent parse into an AST (function/variable/if/for/while/switch/return/call/member/assignment/binary), outputting a function inventory and statement tree |

### 5.4 Debugger (59) — CDP-native debugging, dynamic tracing, VMP sampling

**Session & stepping**

| Tool | Risk | Description |
|---|---|---|
| `debugger.attach` | M | Attach the debugger (establishes a CDP session; real V8 breakpoints/stepping/call stacks) |
| `debugger.detach` | M | Detach the debugger (closes the CDP session) |
| `debugger.pause` | M | Pause JavaScript execution |
| `debugger.resume` | M | Resume JavaScript execution |
| `debugger.step_into` | M | Step into |
| `debugger.step_over` | M | Step over |
| `debugger.step_out` | M | Step out |
| `debugger.restart_frame` | M | Restart the current frame |
| `debugger.state` | L | Get debugger state |
| `debugger.get_state` | L | Get debugger state (alias of `debugger.state`) |

**Breakpoints**

| Tool | Risk | Description |
|---|---|---|
| `debugger.set_breakpoint` | M | Set a breakpoint |
| `debugger.set_source_breakpoint` | M | Original-source breakpoint: `src/api/sign.ts:87` → auto-downloads sourcemap, resolves bundle position → V8 `setBreakpointByUrl` (DevTools Sources semantics) |
| `debugger.set_conditional_breakpoint` | M | Set a conditional breakpoint |
| `debugger.set_logpoint` | M | Set a logpoint (records without pausing) |
| `debugger.remove_breakpoint` | M | Remove a breakpoint |
| `debugger.list_breakpoints` | L | List all breakpoints (incl. those set by external debug clients; `source` field distinguishes mcp/devtools) |
| `debugger.set_dom_breakpoint` | M | DOM breakpoint (DevTools Elements semantics): subtree-modified / attribute-modified / node-removed; MutationObserver-based, no CDP needed; records change details + stack, optionally pauses |
| `debugger.get_dom_hits` | L | Retrieve DOM breakpoint hit records (change type/target/attr/old value/stack) |
| `debugger.set_event_breakpoint` | M | Event listener breakpoint (DevTools Event Listener Breakpoints): pause/record before a given event type fires (click/keydown/submit/...; `control` = all control events, `all` = common interactions) |
| `debugger.get_event_hits` | L | Retrieve event breakpoint hit records (event/target/key values/stack) |
| `debugger.set_promise_breakpoint` | M | Promise breakpoint: captures unhandledrejection (reason + stack), optionally pauses |
| `debugger.get_promise_hits` | L | Retrieve Promise breakpoint hit records (reason/stack) |
| `debugger.set_xhr_breakpoint` | M | CDP-native XHR/fetch breakpoint (`DOMDebugger.setXHRBreakpoint`): real pause before the request is sent — bottom of stack is the signing function |
| `debugger.set_listener_breakpoint` | M | CDP-native event listener breakpoint: true pause before listener execution; more accurate than injected breakpoints (covers framework delegation) |
| `debugger.set_script_breakpoint` | M | Pre-execution breakpoint (beforeScriptExecution): pauses before any new script runs — intercepts crypto init / JSVMP loading (enabled=false removes) |
| `debugger.exceptions` | M | Configure exception breakpoints |

**Paused-state inspection**

| Tool | Risk | Description |
|---|---|---|
| `debugger.snapshot` | L | One-shot paused-state snapshot: call stack + per-frame locals + this + hit breakpoints + reason (replaces multiple `call_stack`/`scopes`/`locals` calls) |
| `debugger.wait_breakpoint` | L | Block until a breakpoint hits, then return the paused snapshot directly (= `event.wait debugger.paused` + `snapshot` in one call). Set breakpoints, trigger the action, then call this; returns immediately if already paused |
| `debugger.call_stack` | M | Get the current call stack |
| `debugger.scopes` | M | Get scopes |
| `debugger.locals` | M | Get local variables |
| `debugger.evaluate_on_call_frame` | M | Evaluate on a call frame while paused (reads breakpoint-time locals/closures) |
| `debugger.set_variable` | M | Modify a local variable while paused (CDP `setVariableValue`); step once to observe changed crypto flow |
| `debugger.watch` | M | Add a watch expression |
| `debugger.unwatch` | M | Remove a watch expression |
| `debugger.evaluate_watch` | M | Evaluate watch expressions |

**Scripts & source**

| Tool | Risk | Description |
|---|---|---|
| `debugger.list_scripts` | L | List parsed page scripts (CDP scriptParsed stream; scriptId/url/sourceMapUrl) |
| `debugger.get_script_source` | M | Get script source by scriptId (use with `list_scripts`; find real breakpoint line numbers) |
| `debugger.search_script` | L | Search inside script content (CDP `searchInContent` — no full source pull; returns line numbers + matching lines). Locate crypto functions/keywords fast |
| `debugger.get_breakable_locations` | L | Query breakable positions (CDP `getPossibleBreakpoints`): V8 line numbers aligned to statement starts — query before setting breakpoints on minified code |
| `debugger.list_source_maps` | L | List sourcemapped scripts and their original source files (downloaded & parsed; pick breakpoint targets) |
| `debugger.resolve_position` | L | Bundle position → original source position (sourcemap reverse lookup; maps breakpoint stacks back to source) |

**Runtime objects & evaluation**

| Tool | Risk | Description |
|---|---|---|
| `debugger.runtime_evaluate` | M | CDP `Runtime.evaluate`: await/Promise supported, returns exception details and objectId (DevTools Console semantics) |
| `debugger.get_object_properties` | L | Expand remote object properties by objectId (drill into objects returned by `runtime_evaluate`) |
| `debugger.query_objects` | L | Constructor instance query (CDP `Runtime.queryObjects`): find all live instances of a class (cryptographers/signers), dump each for keys & config |
| `debugger.call_on_object` | M | Call a method on a remote object (CDP `Runtime.callFunctionOn`): read crypto-object internal state / invoke instance methods |
| `debugger.cpu_profile` | L | CPU profile (CDP Profiler): start=true begins sampling; run the crypto flow; start=false stops; returns selfTime hotspot functions (crypto/signing usually tops the list; `url:line` directly breakable) |

**VMP sampling (JSVMP runtime tracing)**

| Tool | Risk | Description |
|---|---|---|
| `debugger.detect_vmp` | L | Static probe for the JSVMP interpreter dispatch loop across all three dispatch styles — while+switch, if-else-if decision tree, and array-of-handlers (`handlers[bc[pc++]]()`); returns candidate lines and suspected opcode/pc variable names |
| `debugger.trace_vmp` | M | Sampled breakpoints on dispatch-loop lines (condition always false → zero pause); each execution logs expression values to a memory buffer. Run the target action, then collect with `get_vmp_trace` |
| `debugger.get_vmp_trace` | L | Retrieve VMP samples as a folded summary (opcode frequency + loop-block detection + RLE sequence) — tens of thousands of samples compress to a few hundred tokens |
| `debugger.diff_vmp_trace` | L | Differential vs baseline snapshot: LCS-aligns current samples against baseline; added/missing opcode blocks are the suspected signature path (fastest locating method in practice) |
| `jsvmp.snapshot` | M | Runtime VM state snapshot: evaluates given expressions (pc variable, ctx array slice, ...); array form samples multiple registers; pair with paused state or standalone observation |

**Dynamic tracing (no-pause instrumentation)**

| Tool | Risk | Description |
|---|---|---|
| `dynamic.trace_function` | M | Trace a function without pausing: wraps the target and records args/return/duration/optional stack per call. First choice for input-output analysis of signing/crypto functions |
| `dynamic.untrace_function` | M | Stop tracing (restore original function) |
| `dynamic.monitor_object` | M | Object property monitor: Proxy-wraps the target; property reads/writes record value + call stack ("who mutated this data") |
| `dynamic.profile_object` | M | Method timing profile: wraps all methods of a target object; counts calls/total/avg duration (find crypto loops and perf hotspots) |
| `dynamic.collect_profile` | L | Retrieve method timing stats (sorted by total time) |
| `dynamic.collect_trace` | L | Retrieve the dynamic trace timeline (function calls / property events; filterable by target) |
| `dynamic.clear_trace` | L | Clear the dynamic trace buffer |

---
### 5.5 Network (32)

**Capture**

| Tool | Risk | Description |
|---|---|---|
| `network.enable` | L | Enable network monitoring (injected layer) |
| `network.disable` | L | Disable network monitoring |
| `network.list` | L | List captured network requests |
| `network.get` | M | Get details of a single request |
| `network.search` | L | Search network requests |
| `network.filter` | L | Filter requests by conditions |
| `network.headers` | M | Get request/response headers |
| `network.cookies` | H | Get cookies involved in a request |
| `network.timing` | L | Get request timing |
| `network.initiator` | L | Get request initiator (call site) |
| `network.websocket` | L | List WebSocket connections |
| `network.clear` | L | Clear network log |
| `network.attach_cdp` | M | Enable CDP-grade capture (DevTools Network panel parity: all resource types, cross-origin, response bodies retrievable) |
| `network.cdp_requests` | L | List CDP-captured requests (requires `network.attach_cdp`; includes resource type/cache source/remote IP) |
| `network.get_response_body` | M | Retrieve response body: prefers CDP (incl. cross-origin); falls back to injected-hook captured bodies (fetch/XHR text) when CDP unavailable |
| `network.cdp_ws_frames` | M | List CDP-captured WebSocket frames (requires `network.attach_cdp`; text frames verbatim, binary base64-prefixed — the reverse channel for realtime signing/push APIs) |

**Manipulation & interception**

| Tool | Risk | Description |
|---|---|---|
| `network.intercept` | H | Toggle request interception (CDP Fetch domain): matched requests pause BEFORE reaching the server; inspect full params, then rewrite-and-release / mock / abort. Prime tool for signature APIs — alter `sign` and replay to probe server validation. Auto-attaches CDP if needed |
| `network.paused_requests` | M | List paused (intercepted) requests — visible pre-send: full URL/method/headers/postData, one step earlier than `network.list`; captures every signature parameter |
| `network.resume_request` | H | Release an intercepted request (optionally rewriting url/method/headers/postData first — e.g. swap the `sign` param to test server validation; headers replace wholesale as a full JSON object) |
| `network.mock_response` | H | Answer an intercepted request with a custom response without touching the server (mock semantics): fake API returns to test frontend logic, bypass validation, force error branches |
| `network.abort_request` | M | Abort an intercepted request (page sees a network error) — test frontend fallback/degradation logic |
| `network.replay` | M | Replay a request |
| `network.block` | H | Block requests matching a URL |
| `network.mock` | H | Mock responses matching a URL |
| `network.throttle` | M | Set network throttling |
| `network.set_user_agent` | M | UA override (CDP `Emulation.setUserAgentOverride`): changes navigator.userAgent and subsequent request headers; bypass UA risk-control / spoof device (effective via the CDP session, visible to all hub clients; full effect after reload) |
| `network.set_extra_headers` | H | Attach global extra request headers (CDP `Network.setExtraHTTPHeaders`): all subsequent requests carry them; common for signed-API testing (inject trace/debug headers, observe server behavior diffs); pass empty object to clear |
| `network.set_cache_disabled` | L | Disable/enable cache (CDP `Network.setCacheDisabled`): true forces all requests to the network (prevents cache from polluting analysis — responses are real server data) |

**Export/import**

| Tool | Risk | Description |
|---|---|---|
| `network.export_har` | L | Export a HAR file |
| `network.import_har` | L | Import a HAR file |
| `network.copy_curl` | L | Generate a cURL command |
| `network.inspect` | L | Composite tool: deep-dive a network request in one call (search → detail → initiator → calling function → signature correlation), returning full context to the LLM |

### 5.6 Hook (23) — runtime instrumentation

| Tool | Risk | Description |
|---|---|---|
| `hook.create` | H | Create a hook rule (network-level: match URL/host/path/method/header/body/regex; actions log/modify/block/redirect/delay/mock) |
| `hook.enable` | M | Enable a hook rule |
| `hook.disable` | M | Disable a hook rule |
| `hook.remove` | H | Delete a hook rule |
| `hook.reset` | H | Reset all hooks |
| `hook.list` | L | List all hook rules |
| `hook.export` | L | Export hook rules |
| `hook.import` | H | Import hook rules |
| `hook.events` | L | List hook trigger records |
| `hook.runtime_list` | L | List runtime-installed hooks |
| `hook.runtime_remove` | H | Remove a runtime hook |
| `hook.function` | H | Hook a page function |
| `hook.method` | H | Hook an object method |
| `hook.property` | H | Hook an object property |
| `hook.fetch` | H | Hook `window.fetch` |
| `hook.xhr` | H | Hook `XMLHttpRequest` |
| `hook.websocket` | H | Hook `WebSocket` |
| `hook.storage` | H | Hook the Storage API |
| `hook.event` | H | Hook DOM events |
| `hook.timer` | H | Hook timers (setTimeout/setInterval) |
| `hook.console` | H | Hook the console API |
| `hook.crypto` | H | Hook the Web Crypto API |
| `hook.dom` | H | Hook DOM mutations (MutationObserver) |

### 5.7 Storage (11)

| Tool | Risk | Description |
|---|---|---|
| `storage.cookies` | H | Read page cookies |
| `storage.local` | M | Read localStorage |
| `storage.session` | M | Read sessionStorage |
| `storage.set_local` | H | Write a localStorage entry |
| `storage.delete_local` | H | Delete a localStorage entry |
| `storage.indexeddb` | M | List IndexedDB databases |
| `storage.cache` | M | List Cache Storage |
| `storage.service_workers` | M | List Service Workers |
| `storage.search` | M | Search across all storages |
| `storage.clear` | H | Clear storage |
| `storage.export` | H | Export all storage |

### 5.8 Page (13)

| Tool | Risk | Description |
|---|---|---|
| `page.inspect` | L | Comprehensive inspection of the current page |
| `page.environment` | L | Analyze the page runtime environment |
| `page.framework_detect` | L | Detect frameworks / build tools / obfuscators in use |
| `page.api_list` | L | List the page's API inventory |
| `page.script_list` | L | List page scripts |
| `page.source_list` | L | List all page resources (link/script/img) |
| `page.worker_list` | L | List page workers |
| `page.service_worker_list` | L | List Service Workers |
| `page.permissions` | L | Query page permission states |
| `page.security` | L | Analyze page security properties |
| `page.performance` | L | Get page performance data |
| `page.memory` | L | Get page memory info |
| `page.cookies` | H | Read current page cookies |

### 5.9 Performance (8)

| Tool | Risk | Description |
|---|---|---|
| `performance.navigation_timing` | L | Navigation timing |
| `performance.resource_timing` | L | Resource timing |
| `performance.paint_timing` | L | Paint timing (FP/FCP) |
| `performance.long_tasks` | L | Long task list |
| `performance.memory` | L | JS heap memory |
| `performance.fps` | L | Measure page FPS |
| `performance.waterfall` | L | Network waterfall data |
| `performance.report` | L | Generate a performance report |

### 5.10 Frame (6), Worker (5), Event (6)

| Tool | Risk | Description |
|---|---|---|
| `frame.list` | L | List all frames (incl. iframes) |
| `frame.select` | L | Select the frame to operate on |
| `frame.evaluate` | H | Execute JS in a specific frame |
| `frame.dom` | L | Get a frame's DOM |
| `frame.network` | L | Get a frame's network requests |
| `frame.debug` | M | Set breakpoints inside a specific frame |
| `worker.list` | L | List all workers |
| `worker.inspect` | L | Inspect Service Worker status |
| `worker.evaluate` | H | Execute in worker context (restricted) |
| `worker.network` | L | Get worker-related network requests |
| `worker.sources` | L | Get worker script sources |
| `event.list` | L | List available event types |
| `event.subscribe` | L | Subscribe to the event stream |
| `event.unsubscribe` | L | Unsubscribe |
| `event.wait` | L | Block until a specific event occurs (or timeout) — e.g. `debugger.paused`, page lifecycle, network, console |
| `event.wait_network` | L | Wait for a new network request |
| `event.wait_console` | L | Wait for console output |

Event families available for `event.wait` / `event.subscribe`: browser page lifecycle (`PageStarted`/`PageFinished`/`PageError`/`DomReady`), navigation (`UrlChanged`/`TitleChanged`), tab lifecycle, network (`RequestStarted`/`ResponseReceived`/`RequestCompleted`/`RequestFailed`/`WebSocketFrame`), console messages, and debugger state.

---
### 5.11 Reverse Engineering (29) — re.* static discovery + reverse.* capability discovery

| Tool | Risk | Description |
|---|---|---|
| `re.analyze_page` | L | Full-page reverse panorama in one call: tech stack + API endpoints + crypto function candidates + sensitive storage + network summary + CDP script inventory + recommended next steps. **The first call on any new page** |
| `re.search` | L | Search keywords across page sources |
| `re.find_api` | L | Discover all API endpoints |
| `re.find_fetch` | L | Find fetch calls |
| `re.find_xhr` | L | Find XHR calls |
| `re.find_websocket` | L | Find WebSocket usage |
| `re.find_crypto` | L | Find crypto-related code |
| `re.find_token` | L | Find token generation/storage code |
| `re.find_auth_flow` | L | Analyze the authentication flow |
| `re.find_login_flow` | L | Analyze the login flow (button → function → request) |
| `re.find_sensitive_api` | L | Find sensitive APIs (payments / user data) |
| `re.find_strings` | L | Extract all strings from the page |
| `re.find_endpoints` | L | Find all URL endpoints |
| `re.find_interesting_functions` | L | Find functions worth attention |
| `re.detect_framework` | L | Detect the page framework |
| `re.detect_bundler` | L | Detect the build tool |
| `re.detect_obfuscator` | L | Detect the obfuscator |
| `re.trace_function` | L | Trace a function call chain |
| `re.trace_network` | L | Trace network request call chains |
| `re.trace_event` | L | Trace DOM event call chains |
| `re.trace_dom` | L | Trace DOM mutations |
| `re.compare_sources` | L | Diff two sources |
| `re.diff_runtime` | L | Diff runtime state |
| `re.generate_report` | L | Generate a reverse-engineering report |
| `re.sourcemap` | L | Parse a source map to locate original source |
| `re.export_case` | L | Export the reverse evidence-chain bundle: workspace findings/analysis/notes + current page source + network chain packed into a Markdown report + JSON evidence pack on disk, for archiving/hand-off/reproduction |
| `reverse.capabilities` | L | Query the platform's reverse-engineering capability overview + per-capability backend readiness (probe first when opening a session) |
| `reverse.toolbox` | L | Reverse toolbox: a JSON description of which tools to combine for common tasks (quick-start examples) |
| `reverse.tools` | L | View high-value tool entries under a capability namespace (network/debugger/hook/static/wasm/vmp/evidence/graph/pipeline/investigation...) |

### 5.12 Reverse Engineering — static.* (9) (static analysis suite)

| Tool | Risk | Description |
|---|---|---|
| `static.analyze` | L | Full static profile in one call: function-level call graph + cyclomatic complexity ranking + string-decrypt chain detection + sensitive data flow locations |
| `static.callgraph` | L | Function call graph: caller → callees adjacency + call hotspots + orphan functions; reverse lookup "who calls the target function" |
| `static.complexity` | L | Cyclomatic complexity ranking: high complexity + machine-generated names = obfuscated core logic; branch stats for top functions |
| `static.decrypt_chain` | L | String-decrypt chain analysis: identifies the "string array + decoder + reference sites" triad (javascript-obfuscator standard layout); outputs restorable plaintext per reference site |
| `static.decrypt_resolve` | L | Offline decrypt-chain restoration: recognizes decoder prototypes (index offset / base64 / constant XOR / shift) and restores plaintext at every call site — offline, zero page dependency; suggests `decrypt_execute` fallback when no prototype matches |
| `static.decrypt_execute` | M | Decrypt-chain sandbox re-execution: replays the original string array + decoder inside a page IIFE sandbox, evaluating each call site for true plaintext — ultimate fallback for arbitrary decoders (RC4 / custom) |
| `static.sensitive_flow` | M | Sensitive data-flow location: read/write sites of cookie/token/localStorage/password (line numbers + context); pair with dynamic hooks for verification |
| `static.cfg` | L | Control-flow graph analysis: build basic blocks + directed edges per function from the recursive-descent AST, compute dominators, loop back-edges and cyclomatic complexity — locate obfuscated control-flow flattening / switch dispatchers |
| `static.flow` | M | Data-flow analysis: def-use pairs per function + sensitive-data taint propagation (cookie/localStorage/token/password/atob → eval/fetch/XHR/innerHTML) |

### 5.13 Reverse Engineering — jsvmp.* (9) (VM-obfuscated code; `jsvmp.snapshot` lives under 5.4 Debugger)

| Tool | Risk | Description |
|---|---|---|
| `jsvmp.analyze` | M | Deep JSVMP analysis: handler semantic classification (rebuilds the VM ISA table) + VM state-variable identification (pc/sp/ctx/bytecode array) + instruction-carrier extraction + entry hints — the full static intelligence package in one call |
| `jsvmp.handlers` | M | Lightweight opcode → semantics mapping table (LOAD/STORE/ARITH/BRANCH/CALL/RETURN classes), LLM-friendly format |
| `jsvmp.decompile` | M | JSVMP decompilation: translates the bytecode carrier (array/hex/base64) into pseudocode via the ISA mapping — basic-block labels + loop back-edges + CALL hotspot locations; operand widths refinable iteratively via `arityOverride`; the final step to rebuild VM logic |
| `jsvmp.resolve_vpc` | M | VPC slot scoring: scores multi-variable object samples from `trace_vmp` (e.g. `{op:x,pc:y,sp:z}`) to auto-identify the virtual pc variable and rebuild the control-flow transfer graph (jump targets / hot pcs / transfer edges) — runtime fallback when static identification fails |
| `jsvmp.trace_decompile` | M | Trace symbolization: translates a runtime opcode sequence into symbolic pseudocode (arity-aware splitting + loop folding + block-level repeat recognition) — the decompilation path when bytecode is decrypted at runtime and no static carrier exists; cross-validates `jsvmp.decompile` results |
| `jsvmp.ir` | M | Generic anti-VM IR translation: normalize JSVMP opcodes by handler semantics into platform-independent IR mnemonics (LD_*/ST_*/ADD/SUB/XOR/MOV/JMP/CJMP/CALL/RET/PUSH/POP/STR2CHAR...), outputting a normalized instruction stream + opcode→IR equivalence table + dispatch matrix — the standard interface for comparing VM logic across obfuscators |
| `jsvmp.semantics` | M | JSVMP semantics recovery engine: per-handler-case program-slice micro-analysis — simulate VM stack effects (push/pop/stack-top read/write) + register read/write (ctx[i]) + pc delta, tri-source fusion to infer arity + direct operator reading to build semantic signatures (e.g. `XOR(stack[-2], stack[-1]) -> stack[-1]`), one order of magnitude finer than `jsvmp.analyze`'s HandlerKind coarse classification |
| `jsvmp.validate` | M | JSVMP opcode semantic-hypothesis validation: when static analysis yields multiple candidates (ADD? XOR? SUB?), feed runtime (input a, input b, output out) samples to auto-adjudicate — evaluate each candidate against the samples and eliminate, outputting the sole winner + confidence + per-item evidence; pairs with `debugger.trace_vmp` sampled stack values for a static-hypothesis → dynamic-validation loop |
| `jsvmp.symbolic` | M | JSVMP symbolic-stack dataflow graph: AST-based semantic slicing + symbolic-stack evaluation per handler case — inputs/outputs expressed as symbolic expressions rather than counters (e.g. `S0=[A,B]; C = A XOR B; S1=[C]`), plus operand-field quadruples (operandCount/operandWidth/operandEncoding/pcDelta); the AST-semantics upgrade of `jsvmp.semantics` |

### 5.14 Reverse Engineering — wasm.* (13) (WebAssembly)

| Tool | Risk | Description |
|---|---|---|
| `wasm.list_modules` | L | List WASM modules captured on the page (size/source URL/imports/exports; auto-captured by an early document_start hook, incl. export-call observation) |
| `wasm.dump_module` | M | Parse a WASM module into structure-level WAT (imports/exports/function signatures/name-section function names/crypto-hotspot functions/data segments; pure Kotlin parser) |
| `wasm.disassemble` | M | Instruction-level disassembly: full WAT via the offline wabt engine (with name-section names), paged per function; can dump to the working dir for `file.search` |
| `wasm.disassemble_func` | M | Single-function instruction-level disassembly (pure Kotlin, no wabt): wat-style pseudocode by export name or function index — symbolic call targets + structural indentation + memarg offsets; **v1.23.0 enhanced**: auto-annotates `i32.const` with data-section strings (e.g. `i32.const 1055092 ;; str: "link[rel*='icon']"`), detects wasm-bindgen modules, adds semantic labels to `__wbg_*` / `__wbindgen_*` import calls (e.g. `call 35 ;; wbg.__wbg_document_xxx → [DOM] get document`) |
| `wasm.data_at` | L | **v1.23.0** Read WASM data-section bytes at a virtual memory address (hex + utf8 dual view + auto string extraction). When you see an `i32.const` value in disassembly that points to a string/selector/constant, use this directly instead of manually parsing data segments |
| `wasm.bindgen_skeleton` | L | **v1.23.0** Auto-generate a Node.js call skeleton for wasm-bindgen modules: detects wasm-bindgen, categorizes exports (constructor/method/free-function/glue/memory), outputs a complete JS template with malloc/free helpers, string read/write utilities, and import stubs — saves you from hand-writing the glue code |
| `wasm.recognize_crypto` | L | Algorithm-level crypto identification: constant fingerprints + round-structure + rotate-schedule + call_indirect target resolution. Supports AES/SHA-1/SHA-256/SHA-512/MD5/SM3/SM4/ChaCha20/Salsa20/xxHash/MurmurHash/TEA/XTEA/SipHash/DES/CRC32/Base64/HMAC; outputs per-algorithm confidence + function location + evidence chain |
| `wasm.wat2wasm` | H | Compile (modified) WAT back to WASM binary, exposed as page global `__WRMCP_WASM_COMPILED__` for instantiation comparison; for tampering constant tables / inserting trace and replaying |
| `wasm.inspect_memory` | M | Read a WASM linear-memory slice (hex + utf8 dual view; locate plaintext-input/ciphertext-output offsets in memory) |
| `wasm.write_memory` | H | Write WASM linear memory (mirror of `inspect_memory`): patch keys/switches/constants then replay and observe; returns hex/utf8 verification view of the written region |
| `wasm.ssa` | M | WASM Stack-SSA + typed-stack analysis: registerize the stack machine (stack slots → `v{n}` virtual registers) + local versioning + phi nodes at if/else/loop merge points + per-instruction type checking (i32/i64/f32/f64/v128), outputting typed SSA pseudocode + stack-desync warnings — fixes linear versioning losing semantics at control-flow merge points |
| `wasm.cfg_ssa` | M | CFG+SSA+taint analysis (pure Kotlin, no wabt): build a control-flow graph per function (basic blocks + branch edges br/br_if/br_table/if/loop/end), output local-variable SSA versions, and give source (memory load / imported-function return) → sink (store/memory.grow/return) taint paths — for locating sensitive data flow in decrypt/verify functions |
| `wasm.cfgssa` | M | True CFG-SSA: split functions into basic blocks + build CFG edges (br/br_if/br_table/if/loop/end/back-edge) + abstract-interpretation fixed-point convergence (bounded rounds) — generating phi nodes at if/else/loop/br merge points (incl. loop-local self-referential phi) + typed-stack refinement (UNKNOWN_POINTER pointer-arithmetic tracking + memory load/store address clues), fixing old Stack-SSA losing semantics at loop back-edges/br merge points |

### 5.15 Evidence (4) / Graph (3) / Pipeline (2) (session knowledge base)

| Tool | Risk | Description |
|---|---|---|
| `evidence.query` | L | Query the evidence store: auto-deposited network/hook/breakpoint/console/pipeline evidence, filtered by source, keyword, time window |
| `evidence.record` | L | Manually record evidence (AI interim conclusions, human observations, external info — into the graph) |
| `evidence.stats` | L | Evidence store & graph overview: per-source counts, node/edge distribution, time range |
| `graph.query` | L | Query the reverse graph: find nodes by type/keyword, or fetch a node's neighborhood subgraph |
| `graph.link` | L | Manually create a graph relation (record when you infer A relates to B; queryable across sessions) |
| `graph.stats` | L | Graph statistics: node/edge distribution, high-weight hubs (the most valuable entry points), key relations |
| `pipeline.list` | L | List built-in analysis pipelines (end-to-end orchestration) |
| `pipeline.run` | M | Run an analysis pipeline: orchestrates existing capabilities end-to-end (`recon` / `api_trace` / `token_trace` / `crypto_link` / `snapshot`); results auto-write to the evidence store and graph |
| `evidence.correlate` | L | Multi-evidence correlation scoring: score given crypto hits / sensitive functions against network requests by confidence (execCtx / call stack / same-tab / time / value-level hits), outputting SIGNS relations + confidence — replaces pure time-window correlation |

### 5.16 Workspace (12) — persistent case files

| Tool | Risk | Description |
|---|---|---|
| `workspace.list` | L | List all workspaces |
| `workspace.create` | L | Create a workspace |
| `workspace.get` | L | Get workspace details |
| `workspace.delete` | M | Delete a workspace |
| `workspace.add_finding` | L | Add an analysis finding |
| `workspace.list_findings` | L | List workspace findings |
| `workspace.add_note` | L | Add a note |
| `workspace.list_notes` | L | List workspace notes |
| `workspace.save_analysis` | L | Save an analysis result |
| `workspace.list_analysis` | L | List saved analyses |
| `workspace.add_target` | L | Add an analysis target |
| `workspace.list_targets` | L | List analysis targets |

### 5.17 File (19) — device-side file operations

| Tool | Risk | Description |
|---|---|---|
| `file.workdir` | L | Get the current working directory (default location for downloads & analysis artifacts) |
| `file.set_workdir` | M | Set the working directory (requires all-files permission granted) |
| `file.read` | L | Read file content: text returned by lines (line-numbered pagination), binary as base64. Use for offline reading of downloaded JS/HAR files |
| `file.write` | M | Create/overwrite a file (persist reverse-engineering output, Python/JS scripts). Text or base64 binary; auto-creates parent dirs |
| `file.append` | M | Append to a file (creates if absent). Write long scripts in batches |
| `file.list` | L | List directory contents (name/size/mtime) with wildcard filter and recursion |
| `file.tree` | L | Tree view of a directory (depth/entry limited) |
| `file.stat` | L | File/dir metadata (size, mtime, readability, MIME type) |
| `file.exists` | L | Check file/dir existence |
| `file.mkdir` | M | Create directories (multi-level) |
| `file.delete` | H | Delete a file or directory (non-empty dirs need recursive=true) |
| `file.copy` | M | Copy file/directory (recursive for dirs) |
| `file.move` | M | Move or rename |
| `file.search` | L | Text/regex search in files or directories (local grep). Locate `sign`/`md5`/`encrypt` in downloaded JS; auto-extracts a context window around matches in minified single-line files |
| `file.open` | M | Open a file with the system app (browser for HTML, player for audio; launches the app on device) |
| `file.share` | M | Open the system share sheet (WeChat/QQ/email/...) |
| `file.hash` | L | File hash (MD5 / SHA-1 / SHA-256) — verify downloads or compare crypto outputs |
| `file.zip` | M | Zip a file or directory |
| `file.unzip` | M | Unzip into a directory (Zip-Slip protected) |

### 5.18 MCP (5) & System (14) — mcp.* + system.* + terminal.* (Host Tools)

| Tool | Risk | Description |
|---|---|---|
| `mcp.status` | L | Server status: tool count, debugger backend/state, CDP hub sessions & pause state, operational hint |
| `mcp.tools` | L | List all available tools (with metadata) |
| `mcp.tool_schema` | L | Get a tool's JSON schema (by name) — use when unsure about parameters |
| `mcp.sessions` | L | List MCP sessions |
| `mcp.permissions` | L | View current permission configuration |
| `system.info` | L | System information |
| `system.health` | L | Health check |
| `system.logs` | L | Read system logs |
| `system.clear_logs` | L | Clear logs |
| `system.echo` | L | Connectivity test |
| `terminal.status` | L | Get terminal & Host Tools status (installed?, Python/Git paths, architecture, extra packages) |
| `terminal.exec` | L | Execute a shell command on the device terminal and return output + exit code. Runs installed tools (git, python, make...), tests scripts, fixes bugs. Note: runs inside the Android sandbox with restricted permissions |
| `terminal.install` | L | Install tool packages (prebuilt .deb from the Termux official repo). Defaults to git/perl/python/python-pip; extra packages like make, cmake, nodejs, curl can be specified. Afterwards `terminal.exec` works |
| `terminal.list_tools` | L | List installed tools (git/python/perl + extra packages) |
| `terminal.pip_install` | L | Install Python libraries with pip (e.g. requests, cryptography). Requires Host Tools (incl. python-pip) installed first |
| `terminal.run_python` | L | Run Python code and return output + exit code. AI can use it to test Python code and self-verify bug fixes. Code is written to a temp file and run with python3 (requires `terminal.install` first) |
| `terminal.run_script` | L | Run a script file (.py with python3, others with sh). Suited for running scripts persisted via `file.write` |
| `terminal.env` | L | Get terminal environment variables (PATH, HOME, PYTHONHOME...) to learn which commands are available |
| `terminal.uninstall` | L | Uninstall Host Tools (removes installed git/python/perl + extra tools) |

### 5.19 User Script (6) — user_script.* (page-injection scripts)

| Tool | Risk | Description |
|---|---|---|
| `user_script.create` | L | Create a user script (appears on the App's script page afterwards; injectable into pages per run timing) |
| `user_script.list` | L | List all user scripts (summary, no code) |
| `user_script.get` | L | Get a user script's details (incl. code) |
| `user_script.update` | L | Update a user script (only the passed fields; others unchanged) |
| `user_script.delete` | L | Delete a user script |
| `user_script.set_enabled` | L | Enable / disable a user script |

### 5.20 Investigation (9) — investigation.* (reverse-investigation engine)

| Tool | Risk | Description |
|---|---|---|
| `investigation.start` | L | Start a reverse investigation (investigationId is the primary key; multiple investigations can run in parallel per session): given goal+target, auto-generate a stage plan and auto-advance to the first human stage |
| `investigation.status` | L | View investigation progress: current stage / confidence / candidate functions / requiredAction / next-step suggestion |
| `investigation.plan` | L | View a investigation's stage plan (without executing) |
| `investigation.next` | L | Advance to the next stage (manual force): runs the corresponding pipeline; when hitting a human stage, set WAITING_INPUT and return the todo |
| `investigation.action_done` | L | Mark a WAITING_INPUT/WAITING_EVENT human stage as done (e.g. Hook installed / breakpoint set); the system then auto-advances subsequent stages |
| `investigation.list` | L | List all investigations (investigationId / goal / status / confidence / session ownership) |
| `investigation.history` | L | View persisted investigation history (from Room, survives App restart): pairs with `investigation.resume` |
| `investigation.resume` | L | Restore a persisted investigation into current memory (stage plan + human todos), enabling restart recovery / cross-session continuation |
| `investigation.reproduce` | L | Extract reproduction elements for a completed signature-located investigation (candidate sign functions / confidence / request elements), for generating Python/curl reproduction code |

---

## 6. Decision Quick Reference

| Question | Fastest path |
|---|---|
| "What is this page?" | `re.analyze_page` → `pipeline.run recon` → `graph.stats` |
| "How is this request signed?" | `pipeline.run crypto_link` → `dynamic.trace_function` on candidates → `debugger.set_xhr_breakpoint` + `wait_breakpoint` to confirm |
| "Where is this token generated?" | `pipeline.run token_trace` → `dynamic.monitor_object` on the storage key |
| "What does this minified function do?" | `debugger.search_script` → `js.beautify` / `js.parse_ast` → `static.callgraph` |
| "String array obfuscation" | `static.decrypt_chain` → `static.decrypt_resolve` → `static.decrypt_execute` (fallback) → `js.deobfuscate` |
| "VM-packed (JSVMP) code" | `debugger.detect_vmp` → `debugger.trace_vmp` + `get_vmp_trace` → `debugger.diff_vmp_trace` → `jsvmp.analyze`/`decompile` |
| "Crypto inside WASM" | `wasm.list_modules` → `wasm.dump_module` (cryptoHotspots) → `wasm.recognize_crypto` (algorithm ID) → `wasm.disassemble_func` → `wasm.inspect_memory` |
| "wasm-bindgen signature / API token" | `wasm.list_modules` → `wasm.dump_module` (check `__wbindgen_*` imports) → `wasm.bindgen_skeleton` (generate Node.js stub) → `wasm.disassemble_func` (strings auto-annotated, imports labeled) → `wasm.data_at` (read hardcoded selectors/URLs/keys) → replay with skeleton |
| "Test server-side validation" | `network.intercept` → `paused_requests` → rewrite via `resume_request` / `mock_response` |
| "What did I already find?" | `evidence.stats` → `graph.query` → `workspace.list_findings` |
| "Wrap up the case" | `evidence.record` conclusions → `workspace.save_analysis` → `re.export_case` |

## 7. Common Pitfalls

1. **Forgetting to resume**: a paused page freezes timers, XHRs, and every subsequent evaluate. After any breakpoint work: `debugger.resume` (or `snapshot` → analyze → `resume`). If a tool result mentions paused state, resolve it before proceeding.
2. **Breakpoints on minified code misaligning**: query `debugger.get_breakable_locations` first; V8 line numbers point at statement starts, not raw column positions.
3. **Interception deadlock**: every `network.intercept` match pauses at the network boundary. Always resolve via `resume_request` / `mock_response` / `abort_request`; disable interception (`network.intercept enabled=false`) when finished.
4. **Cache pollution**: enable `network.set_cache_disabled true` before capture rounds, or response bodies may come from cache instead of the server.
5. **Hook contamination**: long-lived hooks alter behavior. Remove temporary hooks (`hook.runtime_remove`, `dynamic.untrace_function`) before capturing "clean" baselines — and capture the baseline BEFORE adding instrumentation when diffing.
6. **Anti-debugging sites**: run `browser.set_stealth` before `debugger.attach` on protected targets; some sites detect CDP attach itself — prefer no-pause tools (`dynamic.trace_function`, logpoints) there.
7. **Huge payloads through tool results**: don't `get_script_source` a multi-MB bundle into context. `browser.download` it to the working dir, then `file.search` with keywords and read only the context windows.
8. **Re-deriving known facts**: the Evidence Graph persists across the session. `evidence.query` / `graph.query` before collecting — especially after context compaction.

## 8. Output Conventions

- Report file paths relative to `file.workdir`
- Reference scripts as `url:line` (breakable format) and functions by name + script
- Redact secret VALUES (tokens, cookies, keys) in reports; record key names and locations, not live credentials
- For hand-off, always produce: findings summary (from `workspace.list_findings`), the evidence-chain bundle (`re.export_case`), and the graph hub list (`graph.stats`)
