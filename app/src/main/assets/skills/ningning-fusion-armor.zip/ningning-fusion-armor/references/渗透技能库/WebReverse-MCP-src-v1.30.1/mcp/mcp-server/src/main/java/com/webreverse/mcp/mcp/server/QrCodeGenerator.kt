package com.webreverse.mcp.mcp.server

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.webreverse.mcp.core.common.model.McpServerConfig

/**
 * 二维码生成器：生成 MCP 配对二维码。
 * 二维码内容包含 server/host/port/token/transport，AI 客户端可扫描配置。
 */
object QrCodeGenerator {

    fun generate(config: McpServerConfig, token: String, size: Int = 512): Bitmap? {
        val content = buildJson(config, token)
        return try {
            val hints = mapOf(
                EncodeHintType.CHARACTER_SET to "UTF-8",
                EncodeHintType.MARGIN to 2,
            )
            val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size, hints)
            val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            for (x in 0 until size) {
                for (y in 0 until size) {
                    bitmap.setPixel(x, y, if (matrix.get(x, y)) Color.BLACK else Color.WHITE)
                }
            }
            bitmap
        } catch (e: Exception) {
            null
        }
    }

    /** 生成配对配置文本（JSON） */
    fun buildJson(config: McpServerConfig, token: String): String {
        val sb = StringBuilder()
        sb.append("{")
        sb.append("\"server\":\"WebReverseMCP\",")
        sb.append("\"host\":\"${config.host}\",")
        sb.append("\"port\":${config.port},")
        sb.append("\"token\":\"$token\",")
        sb.append("\"transport\":\"${if (config.transportWebSocket) "websocket" else "http"}\",")
        sb.append("\"protocol\":\"mcp\",")
        sb.append("\"version\":\"1.0.0\"")
        sb.append("}")
        return sb.toString()
    }
}
