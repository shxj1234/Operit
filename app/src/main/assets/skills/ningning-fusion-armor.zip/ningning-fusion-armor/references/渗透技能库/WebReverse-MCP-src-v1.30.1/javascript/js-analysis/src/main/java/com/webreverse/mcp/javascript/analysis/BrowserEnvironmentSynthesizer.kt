package com.webreverse.mcp.javascript.analysis

import kotlinx.serialization.Serializable

/**
 * 浏览器环境能力项（报告 §21/§23）。
 */
@Serializable
data class EnvironmentCapability(
    val path: String = "",
    val present: Boolean = false,
    val capturedValue: String? = null,
)

/**
 * 浏览器环境依赖扫描结果（报告 §21）。
 *
 * 对一段要在 Node 中复现的脚本做静态预扫描，找出其依赖的浏览器全局/能力，
 * 供 BrowserEnvironmentSynthesizer 生成 shim。
 */
@Serializable
data class EnvironmentInferenceResult(
    val requiredGlobals: List<String> = emptyList(),
    val requiredPaths: List<String> = emptyList(),   // 如 window.crypto.subtle
    val capabilities: Map<String, Boolean> = emptyMap(),
    val networkUsage: NetworkUsageKind = NetworkUsageKind.CAPTURED_ONLY,
    val timeline: HashMap<String, Int> = HashMap(),
) {
    companion object {
        val empty = EnvironmentInferenceResult()
    }
}

/** 脚本网络能力使用范围（报告 §43） */
@Serializable
enum class NetworkUsageKind {
    NONE,          // 无网络使用
    CAPTURED_ONLY, // 仅回放已捕获的请求/响应（检测到敏感认证信息时强制，最安全）
    TARGET_ONLY,   // 仅允许访问目标站点（有网络依赖但无敏感认证信息）
    FULL,          // 完全放开网络（不推荐默认启用，需人工确认）
}

/** shim 语法校验结果（v1.28.0：定界符配平 + 结构检查） */
@Serializable
data class ShimValidation(
    val valid: Boolean = true,
    val issues: List<String> = emptyList(),
)

/**
 * 浏览器环境合成器（BrowserEnvironmentSynthesizer，报告 ④ / §17~§24）。
 *
 * 目标：把"从网页提取的 JS"自动放到一个最接近目标浏览器的 Node 运行环境中复现，
 * 替代手工逐项补 window/document/navigator ...。
 *
 * 当前实现提供两个核心能力：
 * 1. [infer]：静态预扫描脚本，列出其依赖的浏览器全局与嵌套路径（错误驱动+静态双通道中的"静态通道"）。
 * 2. [buildShim]：基于推断结果 + 真实浏览器捕获值，生成可注入 Node 的 shim JS 代码骨架。
 *
 * 设计要点（对齐报告 §18/§20/§22）：
 *  - 不把浏览器全局盲目塞进 Node global（报告 §18 明确反对 Object.assign(global, dom.window)）。
 *  - 生成独立的隔离上下文引导代码，让脚本运行在被 shim 补全的 window 代理上。
 *  - 路径用法（如 window.crypto.subtle）递归补全，dotted path 拆成嵌套对象。
 *  - 网络默认 [NetworkUsageKind.CAPTURED_ONLY]。
 *
 * v1.28.0 改进：
 *  - 静态扫描升级为 AST 通道（[BrowserEnvAstScanner]）：识别 `.prop` 与 `['str']` 两种
 *    成员访问、连续链式访问，且不命中注释/字符串伪代码；解析失败时回退正则通道。
 *  - 修复 atob/btoa 分支缺少闭合大括号导致的 shim 语法错误。
 *  - 网络推断去冗余：无网络→NONE；有网络且含敏感认证信息→CAPTURED_ONLY；
 *    有网络且无敏感信息→TARGET_ONLY（FULL 永不自动推断）。
 *  - 新增 [validateShim]：对生成的 shim 做定界符配平校验，提前暴露语法问题。
 */
class BrowserEnvironmentSynthesizer {

    /** 常用浏览器全局（报告 §2/§21），扫描命中即标记需要补齐 */
    private val knownGlobals = listOf(
        "window", "document", "navigator", "location", "history", "screen",
        "performance", "crypto", "localStorage", "sessionStorage", "indexedDB",
        "fetch", "XMLHttpRequest", "WebSocket", "Worker", "Blob", "File",
        "FormData", "URL", "URLSearchParams", "DOMParser", "MutationObserver",
        "IntersectionObserver", "ResizeObserver", "TextEncoder", "TextDecoder",
        "atob", "btoa", "AudioContext", "CanvasRenderingContext2D", "Notification",
        "Permissions", "customElements", "matchMedia",
    )

    /** window 子路径（嵌套能力，如 crypto.subtle） */
    private val knownSubpaths = listOf(
        "window.crypto.subtle",
        "window.chrome",
        "window.chrome.runtime",
        "navigator.userAgent",
        "navigator.platform",
        "navigator.language",
        "navigator.languages",
        "navigator.hardwareConcurrency",
        "navigator.deviceMemory",
        "location.href",
        "location.origin",
        "location.protocol",
        "location.host",
        "location.search",
        "document.cookie",
        "screen.width",
        "screen.height",
        "window.outerWidth",
        "window.outerHeight",
        "window.innerWidth",
        "window.innerHeight",
        "performance.now",
        "window.__ABC__",
    )

    /** 网络调用根标识符（AST 通道） */
    private val networkCallRoots = setOf("fetch", "XMLHttpRequest", "WebSocket")

    private val networkIndicator = Regex(
        """\b(?:fetch|XMLHttpRequest|WebSocket|navigator\.sendBeacon)\s*\(""",
    )
    private val fullNetworkBlockers = listOf(
        "cookie", "authorization", "x-token", "sign", "apikey", "api_key",
    )

    private val astScanner = BrowserEnvAstScanner()

    /**
     * 静态预扫描：找出脚本依赖的浏览器全局与路径。
     * 同时按脚本使用网络的方式推断默认网络策略。
     *
     * 优先 AST 通道（精确、无注释/字符串误报、支持括号访问）；
     * AST 无信号（解析失败或确无浏览器依赖）时回退正则通道。
     */
    fun infer(source: String): EnvironmentInferenceResult {
        val scan = astScanner.scan(source)

        val globals: List<String>
        val paths: List<String>
        val usesNetwork: Boolean
        if (scan.parsed) {
            // AST 通道：精确识别，不命中注释/字符串伪代码，支持括号访问。
            // 全局判定：根标识符命中；或成员链根为已知全局且链中含该全局（如 window.crypto.subtle → crypto）。
            globals = knownGlobals.filter { g ->
                g in scan.rootIdentifiers || scan.memberPaths.any { p ->
                    val segs = p.split('.')
                    segs.first() == g || (segs.first() in knownGlobals && g in segs)
                }
            }
            paths = knownSubpaths.filter { sp ->
                scan.memberPaths.any { it == sp || it.startsWith("$sp.") }
            }
            usesNetwork = scan.callRoots.any { it in networkCallRoots } ||
                scan.memberPaths.any { it == "navigator.sendBeacon" } ||
                networkIndicator.containsMatchIn(source)
        } else {
            // 回退：token/正则通道（仅当 AST 整体解析失败时）
            globals = knownGlobals.filter { tokenUsed(source, it) }
            paths = knownSubpaths.filter { source.contains(it) || pathUsedVariants(source, it) }
            usesNetwork = networkIndicator.containsMatchIn(source)
        }

        val capabilities = LinkedHashMap<String, Boolean>()
        globals.forEach { capabilities[it] = true }
        paths.forEach { capabilities[it] = true }

        // 网络推断（v1.28.0 去冗余）：
        //  - 无网络调用 → NONE
        //  - 有网络调用且含敏感认证信息（cookie/token/sign 等）→ CAPTURED_ONLY（防泄漏，最安全）
        //  - 有网络调用且无敏感信息 → TARGET_ONLY（受限目标域放行）
        //  - FULL 永不自动推断，需人工确认
        val network = when {
            !usesNetwork -> NetworkUsageKind.NONE
            fullNetworkBlockers.any { source.lowercase().contains(it) } -> NetworkUsageKind.CAPTURED_ONLY
            else -> NetworkUsageKind.TARGET_ONLY
        }

        return EnvironmentInferenceResult(
            requiredGlobals = globals,
            requiredPaths = paths,
            capabilities = capabilities,
            networkUsage = network,
        )
    }

    /** 浏览器能力表（导航场景直接返回可捕获项清单，供 MCP 工具生成采集指令） */
    fun captureableKeys(): List<String> = knownGlobals + knownSubpaths

    /**
     * 生成可注入 Node 隔离上下文的 shim 引导 JS（报告 §24/§34 的统一格式）。
     *
     * @param captured 真实浏览器捕获到的值（key -> JSON 字符串或原始值）
     * @param includeWindow 是否创建 window 根对象
     */
    fun buildShim(capabilities: Map<String, Boolean>, captured: Map<String, String> = emptyMap(), includeWindow: Boolean = true): String {
        val sb = StringBuilder()
        sb.append("(function(global){\n")
        sb.append("// BrowserEnvironmentSynthesizer 生成的浏览器环境 shim（v1.28.0）\n")
        sb.append("global.__WRMCP_BROWSER_ENV__ = {};\n")
        if (includeWindow) {
            sb.append("var __win = global.__WRMCP_BROWSER_ENV__.window = {};\n")
        } else {
            sb.append("var __win = global;\n")
        }
        sb.append("var __captured = ${quoteMap(captured)};\n")
        sb.append("var __set = function(obj,path,val){ var parts=String(path).split('.'); var cur=obj; for(var i=0;i<parts.length-1;i++){ var p=parts[i]; if(cur[p]===undefined||cur[p]===null||typeof cur[p]!=='object'){ try{cur[p]={};}catch(e){return;} } cur=cur[p]; } try{cur[parts[parts.length-1]]=val;}catch(e){} };\n")
        sb.append("var __val = function(k){ return Object.prototype.hasOwnProperty.call(__captured,k) ? __captured[k] : undefined; };\n")
        // v1.30.1 增强：通用方法桩/一致性字段安装器（对齐真实浏览器行为）
        sb.append("var __stubFn=function(){return function(){return undefined;};};\n")
        sb.append("var __installCommon=function(o){ if(!o||typeof o!=='object'&&typeof o!=='function') return o; ['addEventListener','removeEventListener','dispatchEvent'].forEach(function(m){ if(typeof o[m]!=='function'){ try{o[m]=__stubFn();}catch(e){} } }); return o; };\n")
        sb.append("var __nodeStub=function(){ return {children:[],childNodes:[],nodeType:9,nodeName:'#document',ownerDocument:null,textContent:'',innerHTML:'',style:{},classList:{add:__stubFn(),remove:__stubFn(),toggle:__stubFn(),contains:function(){return false;}},appendChild:function(){return this;},removeChild:function(){return this;},addEventListener:__stubFn(),removeEventListener:__stubFn(),dispatchEvent:__stubFn(),getAttribute:function(){return null;},setAttribute:__stubFn(),removeAttribute:__stubFn(),querySelector:function(){return null;},querySelectorAll:function(){return[];},getElementById:function(){return null;},getElementsByClassName:function(){return[];},getElementsByTagName:function(){return[];},cloneNode:function(){return this;},contains:function(){return false;},insertBefore:function(){return this;},replaceChild:function(){return this;},insertAdjacentHTML:__stubFn(),getBoundingClientRect:function(){return{top:0,left:0,width:0,height:0,right:0,bottom:0};}}; };\n")
        sb.append("var __initNavigator=function(n){ if(!n) return; if(n.webdriver===undefined){ try{Object.defineProperty(n,'webdriver',{value:false,configurable:true});}catch(e){n.webdriver=false;} } if(n.plugins===undefined){ n.plugins=[]; } if(n.mimeTypes===undefined){ n.mimeTypes=[]; } if(n.maxTouchPoints===undefined){ n.maxTouchPoints=1; } if(typeof n.javaEnabled!=='function'){ n.javaEnabled=function(){return false;}; } return n; };\n")
        sb.append("var __installDocument=function(d){ if(!d||typeof d!=='object') return; __installCommon(d); ['querySelector','querySelectorAll','getElementById','getElementsByClassName','getElementsByTagName','getElementsByName','createElement','createElementNS','createTextNode','createDocumentFragment','importNode','getElementByXpath','adoptNode'].forEach(function(m){ if(typeof d[m]!=='function'){ d[m]=(m==='querySelector'||m==='getElementById')?(function(){return null;}):(m==='querySelectorAll'||m==='getElementsByClassName'||m==='getElementsByTagName'||m==='getElementsByName')?(function(){return[];}):(function(){return __nodeStub();}); } }); if(typeof d.addEventListener!=='function'){ d.addEventListener=__stubFn(); } if(d.head===undefined){ d.head=__nodeStub(); } if(d.body===undefined){ d.body=__nodeStub(); } if(d.documentElement===undefined){ d.documentElement=d; } if(d.readyState===undefined){ d.readyState='complete'; } if(typeof d.createEvent!=='function'){ d.createEvent=function(){return __nodeStub();}; } if(typeof d.write!=='function'){ d.write=__stubFn(); } return d; };\n")
        sb.append("var __installWindow=function(w){ __installCommon(w); if(typeof w.matchMedia!=='function'){ w.matchMedia=function(q){ return {matches:false,media:String(q),addListener:__stubFn(),removeListener:__stubFn(),addEventListener:__stubFn(),removeEventListener:__stubFn(),dispatchEvent:__stubFn(),onchange:null}; }; } if(typeof w.scrollTo!=='function'){ w.scrollTo=__stubFn(); w.scrollBy=__stubFn(); } if(typeof w.requestAnimationFrame!=='function'){ w.requestAnimationFrame=global.requestAnimationFrame||function(cb){ return setTimeout(function(){ cb(Date.now()); },0); }; } if(typeof w.cancelAnimationFrame!=='function'){ w.cancelAnimationFrame=global.cancelAnimationFrame||clearTimeout; } if(w.outerWidth===undefined && w.screen && w.screen.width){ try{Object.defineProperty(w,'outerWidth',{value:Number(w.screen.width),configurable:true});}catch(e){} } return w; };\n")

        val allKeys = LinkedHashSet<String>()
        allKeys.addAll(capabilities.keys)

        for (key in allKeys) {
            val capturedVal = "__val(" + quote(key) + ")"
            when {
                key.equals("window", true) -> sb.append("__set(__win, 'window', __win);\n")
                key.equals("crypto", true) -> sb.append("(function(){var c=(typeof globalThis.crypto==='object'&&globalThis.crypto.getRandomValues)?globalThis.crypto:(typeof require==='function'?(function(){try{return require('crypto').webcrypto;}catch(e){return null;}})():null);if(c){__win.crypto=c;}else{__win.crypto={getRandomValues:function(a){for(var i=0;i<a.length;i++)a[i]=(Math.random()*256)|0;return a;},subtle:{digest:function(){return Promise.resolve(null);}}};} globalThis.crypto=__win.crypto;})();\n")
                key.startsWith("window.") -> sb.append("__set(__win, ").append(quote(key.substring("window.".length))).append(", (__val(").append(quote(key)).append(")!==undefined?__val(").append(quote(key)).append("):{}));\n")
                key.startsWith("navigator.") -> sb.append("if(typeof __win.navigator==='undefined'){__win.navigator={};}\n").append("__set(__win.navigator, ").append(quote(key.substring("navigator.".length))).append(", __val(").append(quote(key)).append("));\n").append("__initNavigator(__win.navigator);\n")
                key.startsWith("location.") -> sb.append("if(typeof __win.location==='undefined'){__win.location={};}\n").append("__set(__win.location, ").append(quote(key.substring("location.".length))).append(", __val(").append(quote(key)).append("));\n").append("if(typeof __win.location.assign!=='function'){__win.location.assign=__stubFn();__win.location.replace=__stubFn();__win.location.reload=__stubFn();__win.location.toString=function(){return String(__win.location.href||'');};}\n")
                key.startsWith("document.") -> sb.append("if(typeof __win.document==='undefined'){__win.document={};}\n").append("__set(__win.document, ").append(quote(key.substring("document.".length))).append(", __val(").append(quote(key)).append("));\n").append("__installDocument(__win.document);\n")
                key.startsWith("screen.") -> sb.append("if(typeof __win.screen==='undefined'){__win.screen={};}\n").append("__set(__win.screen, ").append(quote(key.substring("screen.".length))).append(", __val(").append(quote(key)).append("));\n")
                key.startsWith("performance.") -> sb.append("if(typeof __win.performance==='undefined'){__win.performance={};}\n").append("if(!__win.performance.now){__win.performance.now=function(){return Date.now();};}\n")
                key.equals("navigator", true) -> {
                    sb.append("if(typeof __win.navigator==='undefined'){__win.navigator={};}\n")
                    sb.append("if(__val('navigator.userAgent')!==undefined)__set(__win,'navigator.userAgent',__val('navigator.userAgent'));\n")
                    sb.append("__initNavigator(__win.navigator);\n")
                }
                key.equals("location", true) ||
                    key.equals("history", true) ||
                    key.equals("screen", true) ||
                    key.equals("performance", true) ||
                    key.equals("document", true) -> {
                    sb.append("if(typeof __win.").append(key).append("==='undefined'){__win.").append(key).append("={};}\n")
                    if (key=="document") sb.append("__installDocument(__win.document);\n")
                }
                key.equals("localStorage", true) || key.equals("sessionStorage", true) ->
                    sb.append("if(typeof __win.").append(key).append("==='undefined'){(function(){var m={};__win.").append(key).append("={getItem:function(k){return m[k]!==undefined?m[k]:null;},setItem:function(k,v){m[k]=String(v);},removeItem:function(k){delete m[k];},clear:function(){m={};},key:function(i){return Object.keys(m)[i]||null;},get length(){return Object.keys(m).length;}};})();}\n")
                key.equals("fetch", true) ->
                    sb.append("if(typeof __win.fetch==='undefined'){__win.fetch=function(){return Promise.reject(new Error('网络策略 CAPTURED_ONLY：fetch 由捕获请求回放提供'));};}\n")
                key.equals("XMLHttpRequest", true) ->
                    sb.append("if(typeof __win.XMLHttpRequest==='undefined'){__win.XMLHttpRequest=function(){};__win.XMLHttpRequest.prototype.open=function(){};__win.XMLHttpRequest.prototype.send=function(){};}\n")
                key.equals("atob", true) -> sb.append("if(typeof __win.atob==='undefined'){__win.atob=function(s){return Buffer.from(s,'base64').toString('binary');}}\n")
                key.equals("btoa", true) -> sb.append("if(typeof __win.btoa==='undefined'){__win.btoa=function(s){return Buffer.from(s,'binary').toString('base64');}}\n")
                key.equals("TextEncoder", true) -> sb.append("if(typeof __win.TextEncoder==='undefined'){__win.TextEncoder=global.TextEncoder;}\n")
                key.equals("TextDecoder", true) -> sb.append("if(typeof __win.TextDecoder==='undefined'){__win.TextDecoder=global.TextDecoder;}\n")
                key.equals("URL", true) -> sb.append("if(typeof __win.URL==='undefined'){__win.URL=global.URL;}\n")
                key.equals("URLSearchParams", true) -> sb.append("if(typeof __win.URLSearchParams==='undefined'){__win.URLSearchParams=global.URLSearchParams;}\n")
                else -> {
                    // 通用兜底（v1.28.0）：任意未知全局/路径也能补成空对象或回填捕获值，
                    // 这是错误驱动回填（reverse.backfill_environment）能处理任意缺失全局的基础。
                    if (key.matches(Regex("[A-Za-z_$][A-Za-z0-9_$]*"))) {
                        sb.append("if(typeof __win.").append(key).append("==='undefined'){__win.").append(key).append("={};}\n")
                    } else {
                        sb.append("__set(__win, ").append(quote(key)).append(", (__val(").append(quote(key)).append(")!==undefined?__val(").append(quote(key)).append("):{}));\n")
                    }
                }
            }
        }

        // v1.30.1 增强：统一安装 window/document/navigator 常用方法与一致性字段
        sb.append("__installWindow(__win);\n")
        sb.append("if(__win.document)__installDocument(__win.document);\n")
        sb.append("if(__win.navigator)__initNavigator(__win.navigator);\n")
        sb.append("// 脚本依赖的 window 解析已完成，见 __WRMCP_BROWSER_ENV__\n")
        sb.append("return global.__WRMCP_BROWSER_ENV__;\n").append("})(typeof globalThis!=='undefined'?globalThis:this);")
        return sb.toString()
    }

    /**
     * 错误驱动补环境的静态模拟：输入"缺啥补啥"路径集合，产出合并后的 shim（报告 §22）
     * ——实际 Node 环境下由执行错误驱动，这里给出可读的合并结果供 MCP 返回。
     */
    fun mergeShim(existing: Map<String, Boolean>, newlyRequired: List<String>): Map<String, Boolean> {
        val merged = LinkedHashMap(existing)
        newlyRequired.forEach { merged[it] = true }
        return merged
    }

    /**
     * 对生成的 shim 做定界符配平校验（v1.28.0）。
     *
     * 跳过字符串/注释/模板串，检查 () [] {} 是否成对闭合。
     * 用于在交付给 Node 前提前暴露语法问题（如历史上 atob/btoa 分支缺闭合大括号）。
     */
    fun validateShim(shim: String): ShimValidation {
        val stack = ArrayDeque<Char>()
        val issues = mutableListOf<String>()
        val pairs = mapOf(')' to '(', ']' to '[', '}' to '{')
        var i = 0
        val n = shim.length
        var line = 1
        while (i < n) {
            val c = shim[i]
            when {
                c == '\n' -> line++
                c == '/' && i + 1 < n && shim[i + 1] == '/' -> {
                    while (i < n && shim[i] != '\n') i++
                    continue
                }
                c == '/' && i + 1 < n && shim[i + 1] == '*' -> {
                    i += 2
                    while (i + 1 < n && !(shim[i] == '*' && shim[i + 1] == '/')) {
                        if (shim[i] == '\n') line++
                        i++
                    }
                    i += 2
                    continue
                }
                c == '"' || c == '\'' || c == '`' -> {
                    val q = c
                    i++
                    while (i < n && shim[i] != q) {
                        if (shim[i] == '\\') i++
                        if (shim[i] == '\n') line++
                        i++
                    }
                    i++ // 跳过闭合引号
                    continue
                }
                c == '(' || c == '[' || c == '{' -> stack.addLast(c)
                c == ')' || c == ']' || c == '}' -> {
                    val expect = pairs[c]
                    if (stack.isEmpty() || stack.removeLast() != expect) {
                        issues.add("第 $line 行：多余的 '$c'")
                    }
                }
            }
            i++
        }
        if (stack.isNotEmpty()) {
            issues.add("存在未闭合的定界符：${stack.joinToString("") { it.toString() }}")
        }
        return ShimValidation(valid = issues.isEmpty(), issues = issues)
    }

    // ---- 私有辅助 ----

    private fun tokenUsed(source: String, token: String): Boolean {
        return Regex("""\b${Regex.escape(token)}\b""").containsMatchIn(source)
    }

    /** 匹配变体（如 _0x123['window']['crypto'] 动态访问的静态近似） */
    private fun pathUsedVariants(source: String, path: String): Boolean {
        val leaf = path.substringAfterLast('.')
        return source.contains(path) || Regex("""\b${Regex.escape(leaf)}\b""").containsMatchIn(source)
    }

    private fun quote(s: String): String = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

    private fun quoteMap(map: Map<String, String>): String {
        if (map.isEmpty()) return "{}"
        return map.entries.joinToString(",", "{", "}") { (k, v) -> quote(k) + ":" + v }
    }
}
